# Commit Log

## 2026-01-24
- Editor: реалізовано бокову панель Gutenberg (Проблеми + Чат з ІІ), повна UA локалізація.
- Аналіз: PageAuditSummary тепер рахує й зберігає _seojusai_score та _seojusai_score_updated.
- EditorSidebar: реєстрація meta-полів (show_in_rest) для коректного відображення в редакторі.
