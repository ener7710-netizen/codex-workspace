# SEOJusAI — Стан системи (Health)

## Адмінка
SEOJusAI → **Стан системи**

Показує:
- доступність REST маршрутів SEOJusAI
- наявність таблиць БД
- стан WP-Cron та Action Scheduler
- Safe Mode
- Object Cache (інформативно)

## WP-CLI
```bash
wp seojusai health
```

Команда завершується помилкою, якщо знайдені критичні проблеми (fail).
