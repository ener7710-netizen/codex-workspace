# SEOJusAI — Input / Validation Layer

Мета: єдиний, прогнозований шар валідації/санітизації.

Ключове:
- Input::json_body($request, $maxBytes) — захист від великих payload та некоректного JSON
- Input::int/bool/key/text/textarea/enum/arr
- Validator::require_keys/max_items

Поступово застосовується у всіх REST/Editor/Bulk контролерах.
