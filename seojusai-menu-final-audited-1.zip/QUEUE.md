# SEOJusAI — Черга задач (Action Scheduler / DB)

## Мета
Черга задач використовується Autopilot та Bulk для виконання важких операцій без блокування адмінки.

## Бекенди
- `as` — Action Scheduler (рекомендовано)
- `db` — внутрішня DB-черга + воркер (fallback)

Опція: `seojusai_tasks_backend`.

## Concurrency
Опція: `seojusai_tasks_concurrency` (за замовчуванням 5).

## Retry / Backoff
Помилка → `attempts++` → планування повтору з exponential backoff.
Після `max_attempts` задача переходить у статус `dead` (dead-letter).

## UI
Адмінка: **SEOJusAI → Черга задач**

## CLI
- `wp seojusai queue list [--status=pending] [--limit=20]`
- `wp seojusai queue retry --id=123`
