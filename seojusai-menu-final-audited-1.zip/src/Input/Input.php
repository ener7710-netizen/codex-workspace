<?php
declare(strict_types=1);

namespace SEOJusAI\Input;

defined('ABSPATH') || exit;

final class Input {

	public static function post(string $key, $default = null) {
		if (!isset($_POST[$key])) {
			return $default;
		}
		return wp_unslash($_POST[$key]);
	}

	public static function get(string $key, $default = null) {
		if (!isset($_GET[$key])) {
			return $default;
		}
		return wp_unslash($_GET[$key]);
	}
}
