<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheStats {

	/**
	 * Returns lightweight cache stats based on transient counts.
	 *
	 * @return array<string,array{count:int, ts:string}>
	 */
	public static function all(): array {
		global $wpdb;
		if (!isset($wpdb)) {
			return [];
		}

		$namespaces = ['serp','gsc','site_audit','page_audit','explain','vector'];
		$out = [];

		foreach ($namespaces as $ns) {
			$prefix = '_transient_seojusai_' . $ns . '_';
			$like = $wpdb->esc_like($prefix) . '%';
			$count = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$like
			));

			$out[$ns] = [
				'count' => $count,
				'ts'    => (string) current_time('mysql'),
			];
		}

		return $out;
	}
}
