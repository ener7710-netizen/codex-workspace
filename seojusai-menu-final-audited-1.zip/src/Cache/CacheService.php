<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheService {

	/**
	 * Purge all plugin transients (seojusai_*).
	 */
	public static function purge_all(): int {
		global $wpdb;
		if (!isset($wpdb)) {
			return 0;
		}
		$like1 = $wpdb->esc_like('_transient_seojusai_') . '%';
		$like2 = $wpdb->esc_like('_transient_timeout_seojusai_') . '%';

		$deleted1 = (int) $wpdb->query($wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like1
		));
		$deleted2 = (int) $wpdb->query($wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like2
		));

		return $deleted1 + $deleted2;
	}

	/**
	 * Purge a namespace by prefix, e.g. 'serp' purges seojusai_serp_* transients.
	 */
	public static function purge_namespace(string $namespace): int {
		$namespace = sanitize_key($namespace);
		if ($namespace === '') {
			return 0;
		}
		global $wpdb;
		if (!isset($wpdb)) {
			return 0;
		}

		$prefix = '_transient_seojusai_' . $namespace . '_';
		$prefix_to = '_transient_timeout_seojusai_' . $namespace . '_';

		$like1 = $wpdb->esc_like($prefix) . '%';
		$like2 = $wpdb->esc_like($prefix_to) . '%';

		$deleted1 = (int) $wpdb->query($wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like1
		));
		$deleted2 = (int) $wpdb->query($wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like2
		));

		return $deleted1 + $deleted2;
	}
}
