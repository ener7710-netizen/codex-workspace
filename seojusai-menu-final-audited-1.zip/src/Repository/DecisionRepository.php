<?php
declare(strict_types=1);

namespace SEOJusAI\Repository;

use SEOJusAI\Domain\DecisionRecord;

defined('ABSPATH')||exit;

final class DecisionRepository {

    public static function save(DecisionRecord $d): void {
        global $wpdb;
        $table=$wpdb->prefix.'seojusai_decisions';
        $wpdb->replace($table,[
            'decision_hash'=>$d->decisionHash,
            'post_id'=>$d->postId,
            'score'=>$d->score,
            'summary'=>$d->summary,
            'status'=>$d->status,
            'created_at'=>current_time('mysql',true),
        ],['%s','%d','%f','%s','%s','%s']);
    }

    public static function get_by_post(int $post_id): array {
        global $wpdb;
        $table=$wpdb->prefix.'seojusai_decisions';
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE post_id=%d ORDER BY id DESC",$post_id));
    }

    public static function get(string $decision_hash): ?object {
        global $wpdb;
        $table=$wpdb->prefix.'seojusai_decisions';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE decision_hash=%s",$decision_hash));
    }

public static function mark_executed(string $decision_hash): void {
    global $wpdb;
    $table = $wpdb->prefix . 'seojusai_decisions';
    $wpdb->update(
        $table,
        ['status' => 'executed'],
        ['decision_hash' => $decision_hash],
        ['%s'],
        ['%s']
    );
}

public static function mark_cancelled(string $decision_hash, string $reason = ''): void {
    global $wpdb;
    $table = $wpdb->prefix . 'seojusai_decisions';
    $wpdb->update(
        $table,
        ['status' => 'cancelled', 'summary' => $reason ?: 'Cancelled'],
        ['decision_hash' => $decision_hash],
        ['%s','%s'],
        ['%s']
    );
}
}
