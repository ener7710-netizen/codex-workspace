<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Integrations;

defined('ABSPATH') || exit;

use SEOJusAI\AI\Providers\GeminiClient;

/**
 * GeminiRuntimeBridge
 *
 * Реальна інтеграція Gemini для:
 * - "джерела реальності" (deep analysis для Governance/RealityBoundary)
 * - аналітичного контексту для Стратега (OpenAI)
 *
 * УВАГА: виконання тільки через фільтри/ініціативу коду ядра (не з UI напряму).
 */
final class GeminiRuntimeBridge {

	private const FILTER_RUN_GEMINI = 'seojusai/ai/run_gemini';

	public static function register(): void {

		add_filter(self::FILTER_RUN_GEMINI, [self::class, 'run_gemini'], 10, 2);
	}

	/**
	 * @param mixed $default
	 * @param array<string,mixed> $payload
	 * @return array{ok:bool, decision_hash?:string, explanation?:string, risk?:string, confidence?:float}
	 */
	public static function run_gemini($default, array $payload): array {

		$default_arr = is_array($default) ? $default : ['ok' => false];

		$api_key = (string) apply_filters('seojusai/gemini_key', '');
		$model   = (string) apply_filters('seojusai/gemini_model', 'models/gemini-1.5-pro');

		$client = new GeminiClient($api_key, $model);

		if (!$client->is_ready()) {
			return ['ok' => false];
		}

		$prompt = self::build_reality_prompt($payload);

		$raw = $client->generate($prompt, 'reality');
		if (!is_string($raw) || trim($raw) === '') {
			return ['ok' => false];
		}

		$raw = preg_replace('/^```json|```$/i', '', trim($raw));
		$data = json_decode($raw, true);

		if (!is_array($data)) {
			return ['ok' => false];
		}

		$explanation = isset($data['explanation']) ? (string) $data['explanation'] : '';
		$risk        = isset($data['risk']) ? (string) $data['risk'] : 'low';
		$confidence  = self::clamp_confidence($data['confidence'] ?? null);

		$decision_hash = sha1(wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '|' . $raw);

		if ($explanation === '') {
			$explanation = __('Gemini не повернув пояснення. Перевір ключі та повтори спробу.', 'seojusai');
		}

		if (!in_array($risk, ['low', 'medium', 'high'], true)) {
			$risk = 'low';
		}

		return [
			'ok'           => true,
			'decision_hash' => $decision_hash,
			'explanation'   => $explanation,
			'risk'          => $risk,
			'confidence'    => $confidence,
		];
	}

	/**
	 * Додатковий аналітичний контекст для Стратега.
	 *
	 * @param array<string,mixed> $context
	 * @return array<string,mixed>|null
	 */
	public static function analyze_for_strategy(array $context): ?array {

		$api_key = (string) apply_filters('seojusai/gemini_key', '');
		$model   = (string) apply_filters('seojusai/gemini_model', 'models/gemini-1.5-pro');

		$client = new GeminiClient($api_key, $model);

		if (!$client->is_ready()) {
			return null;
		}

		$prompt = self::build_analyst_prompt($context);

		$raw = $client->generate($prompt, 'analyst');
		if (!is_string($raw) || trim($raw) === '') {
			return null;
		}

		$raw = preg_replace('/^```json|```$/i', '', trim($raw));
		$data = json_decode($raw, true);

		if (!is_array($data)) {
			return null;
		}

		return [
			'meta' => [
				'confidence' => self::clamp_confidence($data['meta']['confidence'] ?? null),
				'risk'       => isset($data['meta']['risk']) ? (string) $data['meta']['risk'] : 'low',
				'summary'    => isset($data['meta']['summary']) ? (string) $data['meta']['summary'] : '',
				'reasoning'  => isset($data['meta']['reasoning']) ? (string) $data['meta']['reasoning'] : '',
			],
			'actions' => isset($data['actions']) && is_array($data['actions']) ? $data['actions'] : [],
		];
	}

	/**
	 * @param array<string,mixed> $payload
	 */
	private static function build_reality_prompt(array $payload): string {

		$contract = <<<JSON
ПОВЕРНИ ТІЛЬКИ JSON (без markdown/тексту).

{
  "confidence": 0.0,
  "risk": "low | medium | high",
  "explanation": "коротке пояснення, що вважаєш джерелом реальності та що підтверджено даними"
}
JSON;

		$json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		return <<<PROMPT
SYSTEM:
Ти Gemini-аналітик SEO (Google SERP/GSC/конкуренти). Твоя роль — перевірити "реальність" даних.
{$contract}

PAYLOAD:
{$json}

ПОВЕРНИ ТІЛЬКИ JSON.
PROMPT;
	}

	/**
	 * @param array<string,mixed> $context
	 */
	private static function build_analyst_prompt(array $context): string {

		$contract = <<<JSON
ПОВЕРНИ ВИКЛЮЧНО JSON.

{
  "meta": {
    "confidence": 0.0,
    "risk": "low | medium | high",
    "summary": "",
    "reasoning": ""
  },
  "actions": [
    { "action": "", "auto": false }
  ]
}
JSON;

		$json = wp_json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		return <<<PROMPT
SYSTEM:
Ти Gemini-аналітик (SERP/GSC/конкуренти). Ти НЕ стратег і НЕ застосовуєш зміни.
Твоя задача — повернути структурований аналіз і можливі дії (без виконання).
{$contract}

CONTEXT:
{$json}

ПОВЕРНИ ЛИШЕ JSON.
PROMPT;
	}

	private static function clamp_confidence($value): float {

		$conf = 0.3;

		if (is_numeric($value)) {
			$conf = (float) $value;
		}

		if ($conf < 0.0) {
			$conf = 0.0;
		}

		if ($conf > 1.0) {
			$conf = 1.0;
		}

		return $conf;
	}
}
