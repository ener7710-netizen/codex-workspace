<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Strategy;

use SEOJusAI\AI\Analyzer\AIReasoner;

defined('ABSPATH') || exit;

final class LegalAIStrategy {

    /**
     * Логічний (rule-based) шар: факти → проблеми/задачі/рекомендації.
     * НЕ "говорить". НЕ чат. НЕ LLM.
     */
    public static function build(array $facts, array $validated): array {

        $tasks = [];
        $schema = [];
        $explain = [];

        $blocks = $facts['blocks'] ?? [];

        if (empty($blocks['prices_table'])) {
            $tasks[] = self::task(
                'Додати таблицю цін на послуги',
                'high',
                'Комерційний блок. Без price-блоку сторінка слабко конвертує і гірше ранжується.'
            );
        }

        if (empty($blocks['steps_list'])) {
            $tasks[] = self::task(
                'Додати покроковий алгоритм дій клієнта',
                'high',
                'How-to блок підвищує довіру, поведінкові фактори та E-E-A-T.'
            );
        }

        if (empty($blocks['faq_block'])) {
            $tasks[] = self::task(
                'Додати FAQ блок (5–7 питань)',
                'high',
                'FAQ дає шанс на розширені сніпети та знімає заперечення клієнта.'
            );
        }

        if (empty($blocks['cases_block'])) {
            $tasks[] = self::task(
                'Додати кейси або судову практику',
                'medium',
                'Для юридичної ніші кейси — сильний фактор довіри та експертності.'
            );
        }

        $schemaData = $facts['schema_data']['Attorney'] ?? [];

        if (empty($schemaData['found'])) {
            $schema[] = self::schema('Attorney', 'Додати базову Schema Attorney + LocalBusiness/LegalService.');
        } else {
            if (empty($schemaData['has_priceRange'])) $schema[] = self::schema('priceRange', 'Вказати діапазон цін у Schema (priceRange).');
            if (empty($schemaData['has_rating']))     $schema[] = self::schema('AggregateRating', 'Додати AggregateRating (якщо є відгуки).');
            if (empty($schemaData['has_telephone']))  $schema[] = self::schema('telephone', 'Додати телефон у Schema (telephone).');
            // has_sameAs у твоєму Engine може не бути — тому не чіпаємо тут жорстко
            if (empty($schemaData['has_address']))    $schema[] = self::schema('address', 'Додати адресу (Local SEO).');
        }

        if (empty($facts['license_found'])) {
            $tasks[] = self::task(
                'Додати номер свідоцтва або посилання на ЄРАУ',
                'high',
                'Для адвокатів це один з найсильніших trust-маркерів (YMYL).'
            );
        }

        if (empty($facts['links']['external_gov'])) {
            $tasks[] = self::task(
                'Додати посилання на zakon.rada.gov.ua або court.gov.ua / судову практику',
                'medium',
                'Посилання на офіційні джерела підсилюють юридичну авторитетність сторінки.'
            );
        }

        if (empty($facts['compliance']['has_cookie_consent'])) {
            $tasks[] = self::task(
                'Додати cookie/consent банер',
                'medium',
                'Підвищує довіру та відповідність вимогам щодо cookies.'
            );
        }

        if (empty($facts['compliance']['data_processing_ag'])) {
            $tasks[] = self::task(
                'Додати згоду на обробку персональних даних у формах',
                'high',
                'Юридично обов’язковий елемент для форм/лід-збору.'
            );
        }

        $explain[] = self::explain(
            'Rule-based шар виявив, що сторінка має потенціал, але стримується відсутністю комерційних блоків, повної Schema та trust-сигналів (YMYL).'
        );

        return [
            'facts' => $facts,
            'tasks' => $tasks,
            'schema' => $schema,
            'explain' => $explain,
        ];
    }

    /**
     * Міст для Engine: повертає AI-поля (генерує AIReasoner).
     * Це саме те, що має наповнювати "Завдання від AI".
     */
    public static function run(array $facts, array $validated): array {

        $score = (int)($validated['score'] ?? 0);
        $analysis = (array)($validated['analysis'] ?? []);
        $base_tasks = (array)($validated['tasks'] ?? []);

        $rule = self::build($facts, $validated);

        // базові задачі з rule-шару + існуючі tasks з validated
        $merged_tasks = array_merge($base_tasks, (array)($rule['tasks'] ?? []));

        // LLM шар
        if (class_exists(AIReasoner::class)) {
            $ai = AIReasoner::enrich_audit(
                $facts,
                $analysis,
                $merged_tasks,
                $score,
                [
                    'title' => (string)($facts['meta']['title'] ?? ''),
                    'url'   => (string)($facts['url'] ?? ''),
                ]
            );

            return [
                'ai_tasks'  => (array)($ai['ai_tasks'] ?? []),
                'ai_explain'=> (string)($ai['ai_explain'] ?? ''),
                'ai_schema' => (array)($ai['ai_schema'] ?? []),
            ];
        }

        // fallback
        return [
            'ai_tasks' => $merged_tasks,
            'ai_explain' => (string)(($rule['explain'][0]['text'] ?? '') ?: ''),
            'ai_schema' => (array)($rule['schema'] ?? []),
        ];
    }

    /**
     * Чат — ЖИВИЙ (LLM) на базі facts/analysis/tasks.
     */
    public static function chat(array $args): array {

        $facts   = (array)($args['facts'] ?? []);
        $analysis= (array)($args['analysis'] ?? []);
        $tasks   = (array)($args['tasks'] ?? []);
        $score   = (int)($args['score'] ?? 0);
        $message = (string)($args['message'] ?? '');

        if ($message === '') {
            return [
                'reply' => 'Напишіть питання — я відповім по цій сторінці, спираючись на її аудит.',
                'suggested_tasks' => [],
                'suggested_schema' => [],
                'confidence' => 'low',
            ];
        }

        if (class_exists(AIReasoner::class)) {
            $ai = AIReasoner::chat_reply(
                $facts,
                $analysis,
                $tasks,
                $score,
                $message,
                [
                    'title' => (string)($facts['meta']['title'] ?? ''),
                    'url'   => (string)($facts['url'] ?? ''),
                ]
            );

            return [
                'reply' => (string)($ai['reply'] ?? ''),
                'suggested_tasks' => (array)($ai['suggested_tasks'] ?? []),
                'suggested_schema' => (array)($ai['suggested_schema'] ?? []),
                'confidence' => (string)($ai['confidence'] ?? 'high'),
            ];
        }

        // fallback (не бот-команди, просто коротка відповідь)
        $title = (string)($facts['meta']['title'] ?? '');
        $h1 = '';
        if (!empty($facts['headings']['h1'][0])) $h1 = (string)$facts['headings']['h1'][0];

        return [
            'reply' => "Я бачу цю сторінку:\nTitle: {$title}\nH1: {$h1}\nScore: {$score}/100\n\nПитання: {$message}\n\nКоротко: треба підсилити структуру, Schema та trust-сигнали.",
            'suggested_tasks' => $tasks,
            'suggested_schema' => [],
            'confidence' => 'low',
        ];
    }

    private static function task(string $action, string $priority, string $why): array {
        return [
            'action' => $action,
            'priority' => $priority,
            'why' => $why,
            'auto' => false,
        ];
    }

    private static function schema(string $field, string $desc): array {
        return [
            'field' => $field,
            'desc' => $desc,
        ];
    }

    private static function explain(string $text): array {
        return [
            'text' => $text,
        ];
    }
}
