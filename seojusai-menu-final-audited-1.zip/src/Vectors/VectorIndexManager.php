<?php
declare(strict_types=1);

namespace SEOJusAI\Vectors;

use SEOJusAI\AI\OpenAIKey;
use SEOJusAI\AI\Providers\OpenAIClient;
use SEOJusAI\Vectors\OpenAIEmbeddingProvider;

defined('ABSPATH') || exit;

final class VectorIndexManager {

    public static function index_post(int $post_id, string $namespace = VectorNamespaces::POSTS, ?int $version = null): array {
        $key = OpenAIKey::get();
        $client = new OpenAIClient($key, 'gpt-4.1');
        $provider = new OpenAIEmbeddingProvider($client);
        $indexer = new VectorIndexer($provider);
        return $indexer->index_post($post_id, $namespace, $version);
    }
}
