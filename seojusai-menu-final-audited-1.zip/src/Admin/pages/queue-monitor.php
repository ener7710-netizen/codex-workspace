<?php
defined('ABSPATH')||exit;
use SEOJusAI\Queue\ЗавданняQueue;

$items = ЗавданняQueue::list(50);
?>
<div class="wrap">
<h1>SEOJusAI — Монітор черги</h1>
<table class="widefat striped">
<thead>
<tr><th>ID</th><th>Завдання</th><th>Статус</th><th>Спроби</th><th>Оновлено</th><th>Дії</th></tr>
</thead>
<tbody>
<?php foreach ($items as $t): ?>
<tr>
<td><?php echo (int)$t->id; ?></td>
<td><?php echo esc_html($t->type); ?></td>
<td><?php echo esc_html($t->status); ?></td>
<td><?php echo esc_html($t->attempts); ?></td>
<td><?php echo esc_html($t->updated_at); ?></td>
<td>
  <?php if ($t->status==='failed'): ?>
    <a href="<?php echo admin_url('admin.php?page=seojusai_queue&action=retry&id='.$t->id); ?>">Повторити</a> |
  <?php endif; ?>
  <a href="<?php echo admin_url('admin.php?page=seojusai_queue&action=cancel&id='.$t->id); ?>">Скасувати</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
