<?php
defined('ABSPATH')||exit;
use SEOJusAI\Repository\DecisionRepository;
use SEOJusAI\Repository\SeoMetaRepository;

$postId = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;
$status = $_GET['status'] ?? '';
$confidence = $_GET['confidence'] ?? '';

$items = DecisionRepository::filter([
  'post_id'=>$postId,
  'status'=>$status,
  'confidence'=>$confidence
]);
?>
<div class="wrap">
<h1>SEOJusAI — Центр рішень</h1>

<form method="get">
  <input type="hidden" name="page" value="seojusai_decisions"/>
  <label>Статус:
    <select name="status">
      <option value="">Будь-який</option>
      <option value="planned">Заплановано</option>
      <option value="approved">Підтверджено</option>
      <option value="rejected">Відхилено</option>
    </select>
  </label>
  <label>Confidence ≥
    <input name="confidence" value="<?php echo esc_attr($confidence); ?>" size="4"/>
  </label>
  <button class="button">Фільтрувати</button>
</form>

<table class="widefat striped">
<thead><tr>
  <th>ID</th><th>Post</th><th>Type</th><th>Confidence</th><th>Status</th><th>Дії</th>
</tr></thead>
<tbody>
<?php foreach ($items as $i): $m = isset($i->decision_hash)? SeoMetaRepository::get_by_decision($i->decision_hash): null; ?>
<tr>
  <td><?php echo (int)$i->id; ?></td>
  <td><?php echo (int)$i->post_id; ?></td>
  <td><?php echo esc_html($i->type); ?></td>
  <td><?php echo esc_html($i->confidence); ?></td>
  <td><?php echo esc_html($i->status); ?></td>
  <td>
    <details><summary>Перегляд змін</summary>
      <div style="background:#f9f9f9;padding:8px;margin:6px 0;">
        <strong>Current:</strong><br/>
        <?php echo esc_html(get_post_meta($i->post_id,'_yoast_wpseo_title',true)); ?><br/>
        <?php echo esc_html(get_post_meta($i->post_id,'_yoast_wpseo_metadesc',true)); ?>
        <hr/>
        <strong>Proposed:</strong><br/>
        <?php echo esc_html($m->seo_title ?? ''); ?><br/>
        <?php echo esc_html($m->meta_description ?? ''); ?>
      </div>
    </details>
    <a href="<?php echo admin_url('admin.php?page=seojusai_decisions&action=approve&id='.$i->id); ?>">Підтвердити</a> |
    <a href="<?php echo admin_url('admin.php?page=seojusai_decisions&action=reject&id='.$i->id); ?>">Відхилити</a> |
    <a href="<?php echo admin_url('admin.php?page=seojusai_decisions&action=apply&id='.$i->id); ?>">Застосувати</a>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
