<?php
declare(strict_types=1);

namespace SEOJusAI\Admin;

use SEOJusAI\Admin\Tasks\TasksPage;

defined('ABSPATH') || exit;

final class Menu {

	public function __construct() {
		add_action('admin_menu', [$this, 'register_menu']);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
	}

	public function register_menu(): void {

		$cap = 'manage_options';
		$icon = 'dashicons-chart-area';

        add_menu_page(
			'SEOJusAI',
			'SEOJusAI',
			$cap,
			'seojusai',
			[$this, 'render_dashboard'],
			$icon,
			30
		);

		add_submenu_page(
            'seojusai', 'Клієнти', 'Клієнти', 'manage_options', 'seojusai_clients', function(){ include __DIR__.'/pages/clients.php'; }
        );
        add_submenu_page('seojusai', __('Огляд', 'seojusai'), __('Огляд', 'seojusai'), $cap, 'seojusai', [$this, 'render_dashboard']);

add_submenu_page('seojusai', __('Центр рішень', 'seojusai'), __('Центр рішень', 'seojusai'), $cap, 'seojusai_decisions', function(){ include __DIR__.'/pages/decision-center.php'; });
add_submenu_page('seojusai', __('Монітор черги', 'seojusai'), __('Монітор черги', 'seojusai'), $cap, 'seojusai_queue', function(){ include __DIR__.'/pages/queue-monitor.php'; });

		add_submenu_page('seojusai', __('Аналітика', 'seojusai'), __('Аналітика', 'seojusai'), $cap, 'seojusai-analytics', [$this, 'render_analytics']);
		add_submenu_page('seojusai', __('Аналітика сторінок', 'seojusai'), __('Аналітика сторінок', 'seojusai'), $cap, 'seojusai-analytics-posts', [$this, 'render_analytics_posts']);

		add_submenu_page('seojusai', __('SERP та конкуренти', 'seojusai'), __('SERP та конкуренти', 'seojusai'), $cap, 'seojusai-serp', [$this, 'render_serp']);
		add_submenu_page('seojusai', __('SEO-пріоритети', 'seojusai'), __('SEO-пріоритети', 'seojusai'), $cap, 'seojusai-opportunity', [$this, 'render_opportunity']);
		add_submenu_page('seojusai', __('Карта сайту', 'seojusai'), __('Карта сайту', 'seojusai'), $cap, 'seojusai-sitemap', [$this, 'render_sitemap']);
		add_submenu_page('seojusai', __('Внутрішні посилання', 'seojusai'), __('Внутрішні посилання', 'seojusai'), $cap, 'seojusai-internal-links', [$this, 'render_internal_links']);

		add_submenu_page('seojusai', __('Інтент', 'seojusai'), __('Інтент', 'seojusai'), $cap, 'seojusai-intent-cannibalization', [$this, 'render_intent_cannibalization']);
		add_submenu_page('seojusai', __('Конфлікти', 'seojusai'), __('Конфлікти', 'seojusai'), $cap, 'seojusai-conflicts', [$this, 'render_conflicts']);

		add_submenu_page('seojusai', __('Редиректи', 'seojusai'), __('Редиректи', 'seojusai'), $cap, 'seojusai-redirects', [$this, 'render_redirects']);
		add_submenu_page('seojusai', __('Schema', 'seojusai'), __('Schema', 'seojusai'), $cap, 'seojusai-schema', [$this, 'render_schema']);

		add_submenu_page('seojusai', __('AI та Дані', 'seojusai'), __('AI та Дані', 'seojusai'), $cap, 'seojusai-ai-data', [$this, 'render_ai_settings']);

		add_submenu_page('seojusai', __('Стратегія', 'seojusai'), __('Стратегія', 'seojusai'), $cap, 'seojusai-strategy', [$this, 'render_strategy']);
		add_submenu_page('seojusai', __('Автопілот', 'seojusai'), __('Автопілот', 'seojusai'), $cap, 'seojusai-autopilot', [$this, 'render_autopilot']);

		add_submenu_page('seojusai', __('Керування', 'seojusai'), __('Керування', 'seojusai'), $cap, 'seojusai-governance', [$this, 'render_governance']);

	}


	/* ==========================================================
	 * RENDERERS
	 * ========================================================== */

	public function render_dashboard(): void {
		$this->safe_require('Admin/pages/dashboard.php');
	}

	public function render_decisions(): void {
		$this->safe_require('Admin/pages/decisions.php');
	}

	public function render_ai_conversions(): void {
		$this->safe_require('Admin/pages/ai-conversions.php');
	}

	public function render_ai_settings(): void {
		$this->safe_require('Admin/pages/ai-settings.php');
	}

	public function render_lead_funnel(): void {
		$this->safe_require('Admin/pages/lead-funnel.php');
	}

	public function render_governance(): void {
		$this->safe_require('Admin/pages/governance.php');
	}

	public function render_conflicts(): void {
		$this->safe_require('Admin/pages/conflicts.php');
	}

	public function render_market_signals(): void {
		$this->safe_require('Admin/pages/market-signals.php');
	}

	public function render_experiments(): void {
		$this->safe_require('Admin/pages/experiments.php');
	}




	public function render_modules(): void {
		$this->safe_require('Admin/pages/modules.php');
	}

	public function render_tasks(): void {
		if (class_exists(TasksPage::class)) {
			(new TasksPage())->render();
			return;
		}

		echo '<div class="notice notice-error"><p>';
		echo esc_html__('SEOJusAI: Модуль задач не завантажено.', 'seojusai');
		echo '</p></div>';
	}

	/* ==========================================================
	 * HELPERS
	 * ========================================================== */

	

	public function render_opportunity(): void {
		$this->safe_require('Admin/pages/opportunity.php');
	}

	public function render_sitemap(): void {
		$this->safe_require('Admin/pages/sitemap.php');
	}

	public function render_redirects(): void {
		$this->safe_require('Admin/pages/redirects.php');
	}

private function safe_require(string $relative_path): void {
		// Використовуємо константу SEOJUSAI_INC, яку ми визначили в головному файлі
		$file = defined('SEOJUSAI_INC')
			? SEOJUSAI_INC . $relative_path
			: plugin_dir_path(__DIR__) . $relative_path;

		if (file_exists($file) && is_readable($file)) {
			require_once $file;
		} else {
			echo '<div class="notice notice-error"><p>';
			echo esc_html__('Помилка: Файл не знайдено за шляхом: ', 'seojusai');
			echo esc_html($file);
			echo '</p></div>';
		}
	}

	// render_page_analysis removed: page analysis is shown in list-table badge and editor sidebar.

	public function enqueue_assets(string $hook): void {
	// Load base admin UI styles only on our plugin screens.
	if (strpos($hook, 'seojusai') === false) {
		return;
	}

	$ver = defined('SEOJUSAI_VERSION') ? SEOJUSAI_VERSION : '1.0.0';

	wp_enqueue_style(
		'seojusai-admin',
		plugins_url('assets/admin/admin-ui.css', SEOJUSAI_FILE),
		[],
		$ver
	);

	// Rank Math-like pattern: enqueue Analytics assets ONLY on Analytics screen.
	$is_analytics = ($hook === 'seojusai_page_seojusai-analytics')
		|| ($hook === 'toplevel_page_seojusai-analytics')
		|| (isset($_GET['page']) && $_GET['page'] === 'seojusai-analytics');

	if (!$is_analytics) {
		return;
	}

	// Styles for Analytics UI shell (PHP-rendered).
	wp_enqueue_style('wp-components');
	$analytics_css = plugins_url('assets/admin/analytics.css', SEOJUSAI_FILE);
	wp_enqueue_style('seojusai-analytics', $analytics_css, ['seojusai-admin', 'wp-components'], $ver);

// Hydrator: fills KPI cards and tables with GA4/GSC stats via REST.
wp_enqueue_script(
    'seojusai-analytics-hydrate',
    plugins_url('assets/js/analytics-hydrate.js', SEOJUSAI_FILE),
    ['wp-api-fetch','wp-i18n','lodash'],
    $ver,
    true
);
wp_localize_script('seojusai-analytics-hydrate', 'SEOJusAIAnalyticsApp', [
    'restRoot' => '/wp-json/seojusai/v1',
    'nonce' => wp_create_nonce('wp_rest'),    'homeUrl' => home_url('/'),
    'siteHost' => (string) wp_parse_url(home_url('/'), PHP_URL_HOST),
    'gscSite' => (string) get_option('seojusai_gsc_site', ''),
]);


	// SPA (React) assets are intentionally NOT enqueued here.
	// This page now renders a stable PHP UI shell (appearance like your UI zip).
}



public function render_serp(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/module-serp.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('SERP', 'seojusai') . '</h1></div>';
}

public function render_autopilot(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/autopilot.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Автопілот', 'seojusai') . '</h1></div>';
}

public function render_strategy(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/strategy.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Стратегія', 'seojusai') . '</h1></div>';
}

public function render_system_health(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/system-health.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Система', 'seojusai') . '</h1></div>';
}

public function render_task_queue(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/task-queue.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Черга завдань', 'seojusai') . '</h1></div>';
}

public function render_explain_director(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/explain-director.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Explain', 'seojusai') . '</h1></div>';
}

public function render_google_search_analytics(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/google-search-analytics.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Google Search Console', 'seojusai') . '</h1></div>';
}

public function render_google_search_history(): void {
    $file = SEOJUSAI_PATH . 'src/Admin/pages/google-search-history.php';
    if (is_readable($file)) {
        require $file;
        return;
    }
    echo '<div class="wrap"><h1>' . esc_html__('Google Search Console', 'seojusai') . '</h1></div>';
}



public function render_schema(): void {
	require SEOJUSAI_PATH . 'src/Admin/pages/schema.php';
}


public function render_internal_links(): void {
	require SEOJUSAI_PATH . 'src/Admin/pages/internal-links.php';
}

	public function render_vector_memory(): void {
		$this->safe_require('Admin/pages/vector-memory.php');
	}

	public function render_learning(): void {
		$this->safe_require('Admin/pages/learning.php');
	}

	public function render_intent_cannibalization(): void {
		$this->safe_require('Admin/pages/intent-cannibalization.php');
	}

    
	public function render_analytics(): void {
		$this->safe_require('Admin/pages/analytics-app.php');
	}

	public function render_analytics_posts(): void {
		$this->safe_require('Admin/pages/analytics-posts.php');
	}

}
