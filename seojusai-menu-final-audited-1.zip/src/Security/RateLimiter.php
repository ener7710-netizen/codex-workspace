<?php
declare(strict_types=1);
namespace SEOJusAI\Security;
defined('ABSPATH')||exit;

final class RateLimiter {

    public static function allow(string $clientKey,int $limitPerMinute): bool {
        $key = 'seojusai_rl_' . md5($clientKey);
        $count = (int) get_transient($key);
        if ($count >= $limitPerMinute) {
            return false;
        }
        set_transient($key, $count + 1, 60);
        return true;
    }
}
