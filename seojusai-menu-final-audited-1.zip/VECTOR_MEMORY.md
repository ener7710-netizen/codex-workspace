# SEOJusAI — Vector Memory (Enterprise)

Що додано:
- namespace + vector_version у таблиці vectors
- version bump rebuild: нова версія стає active, rebuild у фоні через TaskQueue/Action Scheduler
- save_post hook: debounce + авто-індексація опублікованих сторінок
- Admin UI: SEOJusAI → Vector Memory (статус, rebuild, purge)
- REST: /vectors/status, /vectors/rebuild, /vectors/purge, /vectors/index, /vectors/search

Порада:
- після першого встановлення натисніть Rebuild (posts).
