# SEOJusAI — Self-learning loop (v1)

Що робить:
- Після Apply/Approve створює Learning Event (decision_hash)
- Збирає `before_metrics` (post snapshot: modified, word_count, seo_score)
- Планує оцінку через N днів (default 7) через TaskQueue/Action Scheduler
- При оцінці збирає `after_metrics` + `outcome.diff` і зберігає в БД

Таблиця:
- {$wpdb->prefix}seojusai_learning_events

Admin:
- SEOJusAI → Learning

Hooks:
- do_action('seojusai/decision/applied', $ctx)
- do_action('seojusai/learning/observed', $ctx)

Примітка:
- GSC outcome collector буде додано наступним кроком (коли ключ + GSC увімкнено).
