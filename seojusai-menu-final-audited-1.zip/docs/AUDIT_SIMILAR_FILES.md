# Audit: похожие/дублирующиеся файлы
Источник: `seojusai-analytics-fixed-stageA.zip`
Дата: 2026-01-28
## 1) Exact duplicates (по SHA-256)
- Не обнаружено файлов с полностью идентичным содержимым.

## 2) Подозрительные имена (old/copy/backup/legacy/experimental)
- Не обнаружено файлов с такими маркерами в именах.

## 3) Near-duplicates (высокое сходство содержимого)
Найдено несколько почти одинаковых файлов-шаблонов (похоже на 3 экрана с одинаковым “manual disabled” сообщением):
- `src/Admin/pages/bulk-rollback.php` ↔ `src/Admin/pages/bulk-audit.php` — similarity≈0.957, token-jaccard≈0.839
- `src/Admin/pages/bulk-rollback.php` ↔ `src/Admin/pages/bulk-apply.php` — similarity≈0.953, token-jaccard≈0.833
- `src/Admin/pages/bulk-audit.php` ↔ `src/Admin/pages/bulk-apply.php` — similarity≈0.945, token-jaccard≈0.758

Риск: возможное дублирование экранов/шаблонов. Можно унифицировать через один шаблон с параметрами (title/message), чтобы снизить техдолг.

## 4) Одинаковые имена классов в разных namespaces
Найдены классы с одинаковым именем, но в разных namespaces (коллизий нет, но может путать при сопровождении):
- `RateLimiter`:
  - `src/AI/RateLimiter.php` (namespace `SEOJusAI\AI`)
  - `src/AI/Security/RateLimiter.php` (namespace `SEOJusAI\AI\Security`)
  - `src/Security/RateLimiter.php` (namespace `SEOJusAI\Security`)
- `PageVsSerpAnalyzer`:
  - `src/AI/PageVsSerpAnalyzer.php` (namespace `SEOJusAI\AI`)
  - `src/Crawl/PageVsSerpAnalyzer.php` (namespace `SEOJusAI\Crawl`)
- `TaskListTable`:
  - `src/Admin/Tasks/TaskListTable.php` (namespace `SEOJusAI\Admin\Tasks`)
  - `src/Admin/Confirmations/TaskListTable.php` (namespace `SEOJusAI\Admin\Confirmations`)
- `SafeModeController`:
  - `src/Rest/Controllers/SafeModeController.php` (namespace `SEOJusAI\Rest\Controllers`)
  - `src/Safety/SafeModeController.php` (namespace `SEOJusAI\Safety`)

Рекомендация: оставить как есть, если это сознательное разделение слоёв. Если нет — переименовать обёртки/адаптеры более явно (например `*Adapter`, `*Facade`).
