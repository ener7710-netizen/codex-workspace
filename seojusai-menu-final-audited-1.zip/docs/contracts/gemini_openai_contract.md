# Gemini ↔ OpenAI Contract

## Roles

### Gemini: Analytical Engine (Only)
Gemini is an analytical engine. Its responsibility is data extraction, comparison, and pattern detection.

Gemini produces:
- Site structure analysis
- URL and content maps
- Performance and indexing signals
- Competitor comparative data

Gemini must NEVER:
- Decide when to scan
- Decide what actions to take
- Prioritize actions

### OpenAI: Strategic Engine
OpenAI is the strategic engine. Its responsibility is decision-making under uncertainty.

OpenAI consumes:
- Gemini analytical outputs
- Historical decisions
- User feedback

OpenAI produces:
- Strategic decisions
- Priorities
- Confidence levels

## Illustrative JSON Example

### Gemini output
```json
{
  "site_structure": {"pages": 120, "clusters": 8},
  "content_map": {"topical_gaps": ["criminal-defense-faq"], "thin_pages": [42, 77]},
  "external_signals": {"index_coverage_risk": "medium"},
  "competitors": {"delta": {"missing_sections": ["pricing", "case-studies"]}}
}
```

### OpenAI decision input
```json
{
  "gemini_output": { "…": "see above" },
  "historical_decisions": ["dec_2025_11_03_001"],
  "user_feedback": [{"decision_id": "dec_2025_11_03_001", "outcome": "rejected", "reason": "too risky"}]
}
```

### OpenAI decision output
```json
{
  "decision_id": "dec_2026_01_25_001",
  "type": "propose_actions",
  "priority": "high",
  "confidence": 0.74,
  "reason": "Topical gap and competitor structure delta indicate opportunity with controlled risk."
}
```
