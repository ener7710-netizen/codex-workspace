# Strategic Decision Contract

## Definition

A Strategic Decision is a formal, immutable output of the Strategic Loop. It represents the system’s judgment that a specific strategic direction is warranted, based on signals and history.

## What a Strategic Decision is NOT

- Not a task
- Not an execution command
- Not an immediate action

## Required Properties

- type (e.g., scan_site, scan_competitors, propose_actions)
- scope (pages, sections, competitors, time horizon)
- reason (why this decision was made)
- confidence level
- urgency

## Lifecycle

- Created
- Translated into execution intents
- Resolved or invalidated

## Expiration and Supersession

- Strategic Decisions may expire
- Strategic Decisions may be superseded by newer decisions

## Illustrative JSON Example

```json
{
  "decision_id": "dec_2026_01_25_001",
  "type": "scan_competitors",
  "scope": {
    "competitors": ["example-law-firm.com", "defense-pro.ua"],
    "time_horizon": "14d"
  },
  "reason": "Competitor structure delta suggests new intent drift in criminal law queries.",
  "confidence": 0.69,
  "urgency": "medium"
}
```
