# Execution Intent

## Definition

An Execution Intent is a concrete, executable representation derived from a Strategic Decision.  
It expresses what should be executed without redefining why the decision exists.

## Relationship to Strategic Decisions

One Strategic Decision may generate zero, one, or multiple Execution Intents.

Execution Intents are always subordinate to their source Strategic Decision.

## Required Properties

Each Execution Intent must define:

- intent_type (audit_site, audit_competitors, build_strategy, propose_changes, etc.)
- source_decision_id
- scope and targets
- priority
- safety constraints

## Allowed Capabilities

Execution Intents are allowed to:

- be enqueued
- be scheduled
- be executed asynchronously

## Explicit Prohibitions

Execution Intents must NEVER:

- make strategic decisions
- modify content directly without approval, unless explicitly allowed

## Lifecycle

created from decision  
→ queued  
→ executed  
→ completed / failed

## Illustrative Mapping Example

```json
{
  "strategic_decision": {
    "id": "decision_42",
    "type": "scan_competitors"
  },
  "execution_intents": [
    {
      "intent_type": "audit_competitors",
      "source_decision_id": "decision_42",
      "priority": "high"
    },
    {
      "intent_type": "build_strategy",
      "source_decision_id": "decision_42",
      "priority": "normal"
    }
  ]
}
```