# Architecture Contract

## Responsibilities
- **WP (AI Core)**: inference, debias, decisions, audit, human review, apply to SEO plugins.
- **Human**: approves/rejects; decides when to apply.
- **Bitrix**: source content CMS; stores AI suggestions; optional review UI; optional apply to element properties.

## Safety rules
- AI must not apply SEO changes unless:
  - decision is approved by human
  - (optional) SEO meta is approved by human
- Self-training uses only human-approved samples.

## Operational rules
- Rate limits are enforced in WP (Autopilot settings).
- Queue lease prevents double-execution.
- Watchdog recovers stuck tasks.
