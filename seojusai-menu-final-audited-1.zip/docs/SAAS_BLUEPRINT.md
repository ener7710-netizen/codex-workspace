# SaaS Wrapper Blueprint

Goal: run SEOJusAI as a service for multiple client sites.

## Recommended layout
- **Core**: WordPress plugin as AI engine (queue, review UI, apply layer)
- **Gateway**: small reverse proxy (Nginx/Cloudflare) + API key per client
- **Clients**: WP, Bitrix, headless CMS call `/seo/analyze`

## Multi-tenant options
1) One WP per client (simplest; strongest isolation)
2) One WP multi-tenant:
   - store `client_id` with every decision/audit row
   - enforce per-client API key
   - rate limits per client

## Minimum MVP steps
- enforce API key (done)
- add per-client key table (next)
- add billing + usage counters (next)
