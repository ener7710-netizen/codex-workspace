# Automation Boundaries

## Allowed Automation

Allowed Automation defines the actions the system may perform without direct human intervention, strictly within predefined ethical, safety, and operational boundaries.

## What the System May Do Automatically

The system is allowed to:

- Observe signals
- Analyze data
- Propose actions
- Execute actions only when explicitly permitted by policy

## What the System Must NOT Do Automatically

The system is NOT allowed to:

- Create or delete pages without explicit human approval, unless explicitly enabled
- Merge content autonomously
- Change site structure without human confirmation

## Role of Policies and Safety Boundaries

Policies and safety boundaries:

- Constrain Autopilot behavior
- Define what Execution Intents may be executed automatically
- Ensure execution remains within approved scope and risk levels

## Prevention of Violations

Violations are prevented conceptually by:

- Strict separation between decision-making and execution
- Mandatory approval requirements for sensitive actions
- Continuous evaluation of actions against active policies

## Why Full Autonomy Is Intentionally Restricted

Full autonomy is intentionally restricted to preserve trust, prevent irreversible harm, ensure accountability, and maintain human oversight over critical structural and content changes.
