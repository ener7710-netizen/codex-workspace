# System State Machine

## Global System States

### Installed
Allowed:
- Initialize baseline configuration
- Prepare observation mechanisms

Must NOT:
- Execute analysis
- Execute strategies or actions

### Observing
Allowed:
- Collect passive signals
- Update state snapshots

Must NOT:
- Perform strategic decisions
- Execute changes

### Strategizing
Allowed:
- Evaluate accumulated signals
- Consider historical context

Must NOT:
- Execute tasks
- Modify content

### Deciding
Allowed:
- Produce Strategic Decisions
- Assign priorities and confidence

Must NOT:
- Execute tasks
- Interact with UI

### Executing
Allowed:
- Execute approved execution intents

Must NOT:
- Create strategies
- Change priorities

### Awaiting Human Feedback
Allowed:
- Present proposals for approval
- Capture acceptance or rejection

Must NOT:
- Execute unapproved actions
- Trigger scans

### Learning
Allowed:
- Incorporate outcomes and feedback
- Update internal models

Must NOT:
- Execute tasks
- Directly affect content

## Valid State Transitions

- Installed → Observing (system initialization)
- Observing → Strategizing (signal accumulation threshold)
- Strategizing → Deciding (evaluation completed)
- Deciding → Executing (approved intents available)
- Deciding → Awaiting Human Feedback (approval required)
- Awaiting Human Feedback → Executing (approved)
- Awaiting Human Feedback → Learning (rejected)
- Executing → Learning (completion)
- Learning → Observing (updated baseline)

## Invalid Transitions

- Installed → Executing
- Observing → Executing
- Strategizing → Executing
- Executing → Strategizing
- Awaiting Human Feedback → Strategizing

## State Diagram

Installed
 → Observing
   → Strategizing
     → Deciding
       → Executing
       → Awaiting Human Feedback
         → Executing
         → Learning
       → Learning
 → Learning
 → Observing

## Explicit Constraints

- UI exists only in Observing, Awaiting Human Feedback, and Learning states
- Execution occurs only in Executing state
- Learning always feeds back into Strategizing
