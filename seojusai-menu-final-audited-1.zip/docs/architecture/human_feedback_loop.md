# Human Feedback Loop

## Role of the Human

The human participant in the system is defined strictly as:

- **Supervisor**
- **Approver / Rejector**
- **Feedback provider**

The human is NOT an operator or an executor.

## Allowed Human Actions

A human may perform only the following actions:

- Approve a proposal
- Reject a proposal
- Provide a rejection reason
- Adjust high-level safety boundaries

## Prohibited Human Responsibilities

A human must NEVER be required to:

- Decide when to scan the site or competitors
- Trigger analysis manually
- Choose execution order or task priority

## Feedback Capture

Human feedback is captured strictly as:

- Acceptance
- Rejection
- Rejection reason

## Feedback Propagation

Captured feedback is:

- Forwarded to the Strategic Loop
- Incorporated into future strategic decisions and learning

## Feedback Flow

proposal → human decision → feedback → strategic learning
