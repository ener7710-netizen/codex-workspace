# Strategic Loop — SEOJusAI

## Strategic Loop Definition

The Strategic Loop is a first-class runtime component responsible for governing when strategic evaluation occurs.

## Purpose

The Strategic Loop exists to:

- continuously evaluate whether strategic action is needed
- act as the only trigger for analysis, strategy building, and autopilot proposals

No other system component may initiate these processes.

## Wake-Up Conditions

The Strategic Loop wakes up only under the following conditions:

- time-based ticks
- accumulated site changes
- external signal updates

## Inputs

The Strategic Loop consumes strictly:

- site state snapshots
- historical decisions
- user feedback (accept / reject with reason)

## Outputs

The Strategic Loop produces only:

- strategic decisions

It does not produce execution commands.

## Explicit Prohibitions

The Strategic Loop must NEVER:

- execute tasks
- modify content
- interact with the user interface directly

## Runtime Flow

observe  
→ evaluate  
→ decide  
→ enqueue intents  
→ sleep
