# Runtime Model — SEOJusAI

## Authority Model

User interface actions **do NOT** initiate analysis or scanning.

All analysis, scanning, and strategic decision-making are exclusively controlled by the **OpenAI Strategist**.

## OpenAI Strategist Authority

The OpenAI Strategist is the sole authority that decides:

- when the site is scanned
- when competitors are scanned
- when strategies are built

No other component initiates these activities.

## User Role

The user acts strictly as:

- observer
- approver / rejector
- feedback provider for learning

The user does not trigger analysis, scanning, or strategy creation.

## UI Components

All UI components are observational and approval-only.

They present system state, proposed actions, and learning feedback interfaces without initiating execution.

## Lifecycle

install  
→ baseline scan  
→ continuous observation  
→ strategist decisions  
→ autopilot proposals  
→ human feedback  
→ learning
