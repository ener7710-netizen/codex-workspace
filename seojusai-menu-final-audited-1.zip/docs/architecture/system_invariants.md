# System Invariants

## Definition

A System Invariant is a non-negotiable rule that must remain true across all runtime states, features, and future changes. Invariants define the plugin’s lawful behavior. If an invariant is violated, the system’s safety, trust model, and architectural separation are compromised.

## Core Invariants

### 1. Strategy decides; execution does not decide
Why it exists:
- Separates judgment under uncertainty from deterministic execution to preserve accountability and explainability.

What breaks if violated:
- Execution becomes a decision-maker, resulting in unexplainable behavior, unsafe actions, and irreproducible outcomes.

### 2. Analysis does not trigger itself
Why it exists:
- Prevents feedback loops where analysis continuously schedules more analysis without strategic justification.

What breaks if violated:
- Infinite scan storms, resource exhaustion, and analysis noise dominating real signals.

### 3. UI never initiates scanning or strategy
Why it exists:
- UI must remain observational and approval-only to avoid “operator-driven” execution and accidental triggers.

What breaks if violated:
- Admin visits, page loads, or interface interactions become execution triggers, creating unpredictable and unsafe system activation.

### 4. Autopilot never operates outside explicit boundaries
Why it exists:
- Ensures any execution is constrained by policy, scope, and risk limits.

What breaks if violated:
- Unbounded edits, structural site changes, irreversible damage, and loss of user trust.

### 5. Human feedback always feeds learning
Why it exists:
- Rejections and approvals are first-class learning inputs that correct future decisions.

What breaks if violated:
- The system repeats rejected proposals and cannot converge toward safer, more relevant behavior.

### 6. Decisions and execution are separable and traceable
Why it exists:
- Enables auditability: “what was decided” must be distinct from “what was attempted” and “what happened.”

What breaks if violated:
- No clear explain chain, no reliable rollback semantics, and no defensible change history.

## Priority of Invariants

- Invariants override convenience.
- Invariants override performance shortcuts.

If a change would violate an invariant, the change is invalid even if it appears to improve speed or reduce complexity.

## How Future Contributors Should Use This Document

- Treat this document as system law: changes must preserve every invariant.
- If a new feature requires breaking an invariant, the feature must be redesigned.
- When reviewing code, prioritize invariant preservation over style, speed, or feature completeness.
