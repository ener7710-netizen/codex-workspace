# Strategic Signals

## Definition

A Strategic Signal is a discrete, observable change in system state or environment that indicates a potential need for strategic evaluation, without implying or triggering execution.

## Signal Categories

### A) Site-internal signals

**Examples:** content edits, structural changes, taxonomy updates, internal linking changes.  
**Meaning:** the internal state of the site has evolved and may affect positioning or intent alignment.  
**Strength:** usually weak individually, strong when accumulated.

### B) External signals

**Examples:** indexing status changes, SERP feature shifts, performance metrics, competitor movement.  
**Meaning:** the external environment influencing visibility or competitiveness has changed.  
**Strength:** generally strong.

### C) Temporal signals

**Examples:** time since last update, content staleness, decay intervals.  
**Meaning:** existing decisions may no longer be optimal due to age or drift.  
**Strength:** weak alone, strong when combined with other signals.

### D) Feedback signals

**Examples:** user approval or rejection of proposals with stated reasons.  
**Meaning:** human judgment provides corrective or reinforcing input to strategy evaluation.  
**Strength:** strong.

## Constraints

Strategic signals do NOT execute anything.  
Strategic signals only influence whether the Strategic Loop evaluates.

## What is NOT a strategic signal

UI rendering, page loads, admin visits, button visibility, or interface presence.