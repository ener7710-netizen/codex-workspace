# Success Criteria

## System-Level Definition of Success

Success at the system level means the system consistently makes appropriate strategic decisions, maintains safety and trust, adapts over time, and improves its understanding of the site and environment — regardless of short-term metric fluctuations.

## Layers of Success

### Strategic Success
Indicators:
- Decisions are timely, justified, and aligned with long-term goals
- The system knows when to act and when not to act

Failure Looks Like:
- Reactive or excessive decision-making
- Ignoring context, risk, or historical outcomes

### Analytical Success
Indicators:
- Accurate understanding of site state and external environment
- Meaningful signal extraction without noise amplification

Failure Looks Like:
- Missing important changes
- Overreacting to insignificant variations

### Execution Success
Indicators:
- Actions stay within scope and safety boundaries
- Approved actions complete without unintended side effects

Failure Looks Like:
- Scope violations
- Irreversible or unsafe changes

### Learning Success
Indicators:
- Rejections and outcomes influence future decisions
- Reduced repetition of rejected or low-value proposals

Failure Looks Like:
- Ignoring human feedback
- Repeating previously rejected actions

## Explicit Principles

- Not all successful actions improve metrics immediately
- Learning from rejection is a valid and important form of success

## Influence on Future Decisions

Success criteria influence:
- How future strategic decisions are framed
- How priorities and urgency are assigned

## What Is NOT a Success Signal

The following are NOT indicators of success:
- Task volume
- Scan frequency
- UI activity
- Button usage or visibility
