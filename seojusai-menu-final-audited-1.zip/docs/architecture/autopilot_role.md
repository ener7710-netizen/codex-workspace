# Autopilot Role

## Definition

Autopilot is an execution and proposal layer.  
It is not a strategic layer and does not make strategic decisions.

## Responsibilities

Autopilot is responsible for:
- receiving Execution Intents
- translating Execution Intents into concrete proposals or actions
- enforcing safety constraints and scope limitations defined by policy

## Prohibited Responsibilities

Autopilot must NEVER:
- create Strategic Decisions
- change priorities defined by strategy
- trigger scans or analysis on its own

## Approval Modes

Autopilot operates under explicit approval policies:
- require human approval before execution
- auto-execute only when explicitly allowed by policy

## Proposal Handling

- Accepted proposals are executed within defined scope and constraints.
- Rejected proposals are aborted and not executed.
- Rejection reasons are recorded verbatim.

## Learning Feedback

Rejection reasons are captured as feedback signals and forwarded to the learning system.
They do not alter execution behavior directly.

## Execution Flow

execution intent → proposal → approval / rejection → execution / abort → feedback
