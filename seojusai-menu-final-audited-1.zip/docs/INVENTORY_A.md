# Інвентаризація коду (Етап A)

Цей файл — швидка карта плагіна як *source of truth* для подальших змін (інваріанти Master Prompt).

## 1) Точки входу та ініціалізація
- `seojusai.php` — bootstrap, константи, autoloader, init Kernel/Modules, i18n.
- `src/Bootstrap.php`, `src/Installer.php`, `src/Install/*` — інсталяція/міграції.
- `src/Core/Kernel.php`, `src/Core/Plugin.php` — ядро, реєстрація модулів/REST/екзек'юторів.

## 2) AI-шар (Gemini = аналітик, OpenAI = стратег)
- `src/AI/GeminiAnalyzer.php` — запуск аналітики Gemini на основі snapshot'ів + compare (Page vs SERP).
- `src/AI/Providers/GeminiProvider.php`, `src/AI/Providers/GeminiClient.php` — інтеграція Gemini.
- `src/AI/Providers/OpenAIProvider.php`, `src/AI/Providers/OpenAIClient.php` — стратегічні виклики OpenAI.
- `src/AI/DecisionContract.php` — валідація AI-рішень (єдине джерело істини формату).
- `src/AI/AIKernel.php`, `src/AI/AIProviderManager.php`, `src/AI/Engine.php` — оркестрація провайдерів/режимів.
- `src/AI/Integrations/*Gateway.php` — мости даних Gemini↔система (runtime/analytics/serp overlay).

## 3) Дані/профіль сайту (GSC/GA4, crawl, canonical/schema facts)
- `src/GSC/*` — клієнт та snapshot для Google Search Console.
- `src/GA4/*` — клієнт та snapshot для GA4.
- `src/Crawl/*` — HTML snapshot, Site tree, PageVsSerpAnalyzer (порівняння контенту).
- `src/Snapshots/*` — зберігання снапшотів (типи: gsc/ga4/serp/pagespeed тощо).
- `src/Analyze/SchemaFactsProvider.php` — витяг “фактів” для schema/аналізу.

## 4) SERP/конкуренти (ядро)
- `src/SERP/SerpOverlayService.php` — отримання SERP через SerpAPI + snapshot (без AI).
- `src/SERP/SerpApiClient.php`, `src/SERP/SerpClient.php`, `src/SERP/SerpConfig.php` — клієнт/конфіг.
- `src/SERP/FingerprintService.php` — базове “fingerprint” конкурентів (title/h1/meta/links з URL).
- `src/Rest/Controllers/SerpController.php` — REST `/seojusai/v1/serp` (пошук SERP для UI/редактора).
- Адмін запуск снапшоту: `src/SERP/SerpAdminActions.php`.

## 5) Editor/Schema (per page, через approve)
- `src/Schema/*` — побудова/рендер/зберігання schema JSON-LD.
- `src/Rest/Controllers/SchemaController.php` — preview/apply endpoints.
- `src/Executors/SchemaApplyExecutor.php` — застосування schema в meta `_seojusai_schema_jsonld`.
- `src/Executors/SchemaExecutor.php` — генерація задач schema.
- UI (адмін/редактор): див. `src/Admin/pages/*` та `assets/js/*` (Gutenberg sidebar/панелі).

## 6) Redirects (404 → аналіз → пропозиція → підтвердження → лог)
- `src/Redirects/NotFoundLogger.php` — лог 404 у таблицю `wp_seojusai_404`.
- `src/Redirects/RedirectRepository.php` — зберігання redirect'ів `wp_seojusai_redirects`.
- `src/Redirects/RedirectExecutor.php` — виконання редиректів + логування 404.
- `src/Redirects/RankMath404Importer.php` — best-effort імпорт 404 з Rank Math.

## 7) Autopilot / виконання / черги
- `src/Tasks/*`, `src/Execution/*`, `src/Executors/*` — черги задач та виконання.
- `src/Autopilot/*` — автопілот-оркестрація (залежить від approval/safe mode).
- `src/Safety/ApprovalService.php` — approvals (transients, TTL 48h).
- `src/Safety/SafeMode.php` + `src/Core/EmergencyStop.php` — стоп-крани.

## 8) Admin UX (українська, групування reveal)
- `src/Admin/Menu.php` — головне меню та сабменю.
- `src/Admin/pages/*` — сторінки: стратегія, governance, модулі, автопілот, health, analytics app.
- `assets/js/*`, `assets/css/*` — фронт адмінки.

## 9) База даних
- `src/Database/Tables.php`, `src/Install/*` — створення таблиць: snapshots, 404, redirects, queue, logs тощо.

---
> Примітка: цей інвентар — “карта” для етапу B (виправлення інваріантів у правильному порядку).
