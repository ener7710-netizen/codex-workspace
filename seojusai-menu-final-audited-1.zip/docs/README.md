# SEOJusAI — Production Baseline

This repository contains:
- WordPress plugin: AI-driven SEO autopilot (zero-shot + debias + human review + audit + apply)
- Bitrix module: connector that calls WP REST API and stores results (optional HL-block)

## Non-negotiables (Legal-safe)
1) **No silent auto-apply**: AI generates suggestions; a human approves; only then apply.
2) **Manual lock wins**: per-page disable autopilot is respected everywhere.
3) **Explainability always**: decisions and actions are logged (audit trail).

## Data flow
1) Content → analysis (zero-shot prompts)
2) Debias correction
3) DecisionRecord (planned)
4) Human review (approve / reject)
5) Apply (Yoast / RankMath / WP meta)

## REST API (WP)
Base: `/wp-json/seojusai/v1`
- `POST /seo/analyze`
- `GET /seo/health`
- `POST /seo/self-train` (manual review required)

### API Key
If option `seojusai_api_key` is set, clients must send header:
`X-SEOJusAI-Key: <key>`
