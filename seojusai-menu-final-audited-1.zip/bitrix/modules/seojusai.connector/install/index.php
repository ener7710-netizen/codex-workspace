<?php
use Bitrix\Main\ModuleManager;
use Bitrix\Main\EventManager;
use Bitrix\Main\Config\Option;

class seojusai_connector extends CModule {
  public $MODULE_ID="seojusai.connector";
  public function DoInstall(){
    ModuleManager::registerModule($this->MODULE_ID);
    Option::set($this->MODULE_ID,"enabled","Y");
    Option::set($this->MODULE_ID,"endpoint","");
    Option::set($this->MODULE_ID,"api_key","");
    Option::set($this->MODULE_ID,"iblock_id","0");
    Option::set($this->MODULE_ID,"min_text_len","300");
    Option::set($this->MODULE_ID,"write_hl","Y");
    Option::set($this->MODULE_ID,"prop_seo_title","");
    Option::set($this->MODULE_ID,"prop_meta_description","");
    Option::set($this->MODULE_ID,"site_base_url","");
    $em=EventManager::getInstance();
    $em->registerEventHandler("iblock","OnAfterIBlockElementAdd",$this->MODULE_ID,"\\SEOJusAI\\Connector\\Service\\Analyzer","onElementChange");
    $em->registerEventHandler("iblock","OnAfterIBlockElementUpdate",$this->MODULE_ID,"\\SEOJusAI\\Connector\\Service\\Analyzer","onElementChange");
  }
  public function DoUninstall(){
    $em=EventManager::getInstance();
    $em->unRegisterEventHandler("iblock","OnAfterIBlockElementAdd",$this->MODULE_ID,"\\SEOJusAI\\Connector\\Service\\Analyzer","onElementChange");
    $em->unRegisterEventHandler("iblock","OnAfterIBlockElementUpdate",$this->MODULE_ID,"\\SEOJusAI\\Connector\\Service\\Analyzer","onElementChange");
    ModuleManager::unRegisterModule($this->MODULE_ID);
  }
}
