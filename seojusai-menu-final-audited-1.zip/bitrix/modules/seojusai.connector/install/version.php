<?php
$arModuleVersion=["VERSION"=>"1.0.0","VERSION_DATE"=>"2026-01-28"];
