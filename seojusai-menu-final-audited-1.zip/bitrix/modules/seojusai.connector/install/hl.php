<?php
use Bitrix\Main\Loader;
use Bitrix\Main\UserFieldTable;
use Bitrix\Highloadblock\HighloadBlockTable;

if (!Loader::includeModule("highloadblock")) {
    return;
}

// Creates HL-block "SeoAiResults" and user fields if missing.
$hl = HighloadBlockTable::getList(['filter'=>['=NAME'=>'SeoAiResults']])->fetch();
if (!$hl) {
    $add = HighloadBlockTable::add([
        'NAME' => 'SeoAiResults',
        'TABLE_NAME' => 'b_seojusai_results'
    ]);
    if (!$add->isSuccess()) {
        return;
    }
    $hl = HighloadBlockTable::getById($add->getId())->fetch();
}

$entityId = 'HLBLOCK_' . (int)$hl['ID'];

function seojusai_add_uf($entityId, $fieldName, $userType, $label)
{
    $exists = UserFieldTable::getList([
        'filter' => ['=ENTITY_ID'=>$entityId, '=FIELD_NAME'=>$fieldName]
    ])->fetch();

    if ($exists) return;

    UserFieldTable::add([
        'ENTITY_ID' => $entityId,
        'FIELD_NAME' => $fieldName,
        'USER_TYPE_ID' => $userType,
        'XML_ID' => $fieldName,
        'SORT' => 100,
        'MULTIPLE' => 'N',
        'MANDATORY' => 'N',
        'SHOW_FILTER' => 'N',
        'EDIT_FORM_LABEL' => ['ru'=>$label,'en'=>$label],
        'LIST_COLUMN_LABEL' => ['ru'=>$label,'en'=>$label],
        'LIST_FILTER_LABEL' => ['ru'=>$label,'en'=>$label],
    ]);
}

seojusai_add_uf($entityId,'UF_ELEMENT_ID','integer','Element ID');
seojusai_add_uf($entityId,'UF_PAGE_TYPE','string','Page Type');
seojusai_add_uf($entityId,'UF_PRACTICE_AREA','string','Practice Area');
seojusai_add_uf($entityId,'UF_INTENT','string','Intent');
seojusai_add_uf($entityId,'UF_CONFIDENCE','double','Confidence');
seojusai_add_uf($entityId,'UF_SEO_TITLE','string','SEO Title');
seojusai_add_uf($entityId,'UF_META_DESCRIPTION','string','Meta Description');
seojusai_add_uf($entityId,'UF_RAW_JSON','string','Raw JSON');
seojusai_add_uf($entityId,'UF_STATUS','string','Status');
