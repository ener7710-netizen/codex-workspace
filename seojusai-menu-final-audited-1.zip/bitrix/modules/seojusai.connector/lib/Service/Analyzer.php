<?php
namespace SEOJusAI\Connector\Service;
use Bitrix\Main\Config\Option;
final class Analyzer{
 public static function onElementChange(&$f):void{
  if(Option::get("seojusai.connector","enabled","Y")!=="Y") return;
  $txt=trim(strip_tags($f["DETAIL_TEXT"]??""));
  if(mb_strlen($txt)<(int)Option::get("seojusai.connector","min_text_len","300")) return;
  $res = Client::analyze($txt,$f["NAME"]??"", $f["DETAIL_PAGE_URL"]??"");
  if(!Storage::saveToHighload((int)($f['ID']??0), $res)){
    Storage::fallbackLog((int)($f['ID']??0), $res);
  }
 }
}
