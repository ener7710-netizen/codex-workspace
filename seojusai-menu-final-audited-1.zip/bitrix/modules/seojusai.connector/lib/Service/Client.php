<?php
namespace SEOJusAI\Connector\Service;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Config\Option;
final class Client{
 public static function analyze(string $text,string $title,string $url):array{
  $m="seojusai.connector";
  $c=new HttpClient();
  $c->setHeader("Content-Type","application/json");
  $key=Option::get($m,"api_key","");
  if($key) $c->setHeader("X-SEOJusAI-Key",$key);
  $payload=[
   "page"=>["url"=>$url,"title"=>$title,"text"=>$text,"language"=>"ru"],
   "options"=>["bias_safe"=>true,"generate_meta"=>true]
  ];
  $r=$c->post(Option::get($m,"endpoint",""),json_encode($payload,JSON_UNESCAPED_UNICODE));
  return json_decode($r,true)?:[];
 }
}
