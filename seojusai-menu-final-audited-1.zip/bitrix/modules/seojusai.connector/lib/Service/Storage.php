<?php
namespace SEOJusAI\Connector\Service;
use Bitrix\Main\Loader;

final class Storage {
  public static function saveToHighload(int $elementId, array $result): bool {
    if (!Loader::includeModule('highloadblock')) return false;
    $entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity('SeoAiResults');
    $cls = $entity->getDataClass();
    $fields = [
      'UF_ELEMENT_ID'=>$elementId,
      'UF_PAGE_TYPE'=>$result['classification']['page_type'] ?? null,
      'UF_PRACTICE_AREA'=>$result['classification']['practice_area'] ?? null,
      'UF_INTENT'=>$result['intent'] ?? null,
      'UF_CONFIDENCE'=>(float)($result['confidence'] ?? 0),
      'UF_SEO_TITLE'=>$result['seo']['title'] ?? null,
      'UF_META_DESCRIPTION'=>$result['seo']['description'] ?? null,
      'UF_RAW_JSON'=>json_encode($result, JSON_UNESCAPED_UNICODE),
      'UF_STATUS'=>'planned',
    ];
    $r = $cls::add($fields);
    return $r->isSuccess();
  }

  public static function fallbackLog(int $elementId, array $result): void {
    $line = date('c')." element=".$elementId." ".json_encode($result, JSON_UNESCAPED_UNICODE).PHP_EOL;
    @file_put_contents($_SERVER['DOCUMENT_ROOT'].'/bitrix/logs/seojusai_connector.log',$line,FILE_APPEND);
  }
}
