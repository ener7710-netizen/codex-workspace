<?php
use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Highloadblock\HighloadBlockTable;

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

if (!Loader::includeModule("highloadblock")) {
    echo "highloadblock module required";
    require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
    exit;
}

$entity = HighloadBlockTable::compileEntity("SeoAiResults");
$cls = $entity->getDataClass();

// actions: approve/reject/apply
$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($id > 0 && in_array($action, ['approve','reject','apply'], true) && check_bitrix_sessid()) {
    if ($action === 'approve') {
        $cls::update($id, ['UF_STATUS'=>'approved']);
    } elseif ($action === 'reject') {
        $cls::update($id, ['UF_STATUS'=>'rejected']);
    } elseif ($action === 'apply') {
        // Minimal apply: write to element properties if configured
        $row = $cls::getById($id)->fetch();
        if ($row) {
            $iblockId = (int)Option::get('seojusai.connector','iblock_id','0');
            $propTitle = (string)Option::get('seojusai.connector','prop_seo_title','');
            $propDesc  = (string)Option::get('seojusai.connector','prop_meta_description','');
            if (Loader::includeModule("iblock") && $row['UF_ELEMENT_ID'] > 0) {
                $values = [];
                if ($propTitle !== '' && !empty($row['UF_SEO_TITLE'])) $values[$propTitle] = $row['UF_SEO_TITLE'];
                if ($propDesc  !== '' && !empty($row['UF_META_DESCRIPTION'])) $values[$propDesc] = $row['UF_META_DESCRIPTION'];
                if ($values) {
                    \CIBlockElement::SetPropertyValuesEx((int)$row['UF_ELEMENT_ID'], $iblockId ?: false, $values);
                }
            }
        }
        $cls::update($id, ['UF_STATUS'=>'applied']);
    }
    LocalRedirect($APPLICATION->GetCurPageParam("", ["action","id","sessid"]));
}

$rows = $cls::getList(['order'=>['ID'=>'DESC'], 'limit'=>50])->fetchAll();

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
?>
<h2>SEOJusAI Results</h2>
<p>Actions require property codes configured in module options (prop_seo_title / prop_meta_description).</p>

<table class="adm-list-table">
  <tr class="adm-list-table-header">
    <td>ID</td><td>Element</td><td>Status</td><td>Confidence</td><td>Page Type</td><td>Practice</td><td>Intent</td><td>Actions</td>
  </tr>
  <?php foreach ($rows as $r): ?>
  <tr class="adm-list-table-row">
    <td><?= (int)$r['ID'] ?></td>
    <td><?= (int)$r['UF_ELEMENT_ID'] ?></td>
    <td><?= htmlspecialcharsbx($r['UF_STATUS']) ?></td>
    <td><?= htmlspecialcharsbx($r['UF_CONFIDENCE']) ?></td>
    <td><?= htmlspecialcharsbx($r['UF_PAGE_TYPE']) ?></td>
    <td><?= htmlspecialcharsbx($r['UF_PRACTICE_AREA']) ?></td>
    <td><?= htmlspecialcharsbx($r['UF_INTENT']) ?></td>
    <td>
      <a href="<?= $APPLICATION->GetCurPageParam("action=approve&id=".(int)$r['ID']."&sessid=".bitrix_sessid(), []) ?>">Approve</a> |
      <a href="<?= $APPLICATION->GetCurPageParam("action=reject&id=".(int)$r['ID']."&sessid=".bitrix_sessid(), []) ?>">Reject</a> |
      <a href="<?= $APPLICATION->GetCurPageParam("action=apply&id=".(int)$r['ID']."&sessid=".bitrix_sessid(), []) ?>">Apply</a>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
