<?php
use Bitrix\Main\Config\Option;
$moduleId = "seojusai.connector";
if (!$USER->IsAdmin()) return;

if ($_SERVER["REQUEST_METHOD"] === "POST" && check_bitrix_sessid()) {
  Option::set($moduleId, "enabled", ($_POST["enabled"] ?? "N") === "Y" ? "Y" : "N");
  Option::set($moduleId, "endpoint", (string)($_POST["endpoint"] ?? ""));
  Option::set($moduleId, "api_key", (string)($_POST["api_key"] ?? ""));
  Option::set($moduleId, "iblock_id", (string)((int)($_POST["iblock_id"] ?? 0)));
  Option::set($moduleId, "min_text_len", (string)((int)($_POST["min_text_len"] ?? 300)));
  Option::set($moduleId, "write_hl", ($_POST["write_hl"] ?? "N") === "Y" ? "Y" : "N");
  Option::set($moduleId, "site_base_url", (string)($_POST["site_base_url"] ?? ""));
  Option::set($moduleId, "prop_seo_title", (string)($_POST["prop_seo_title"] ?? ""));
  Option::set($moduleId, "prop_meta_description", (string)($_POST["prop_meta_description"] ?? ""));
}

$enabled = Option::get($moduleId, "enabled", "Y");
$endpoint = Option::get($moduleId, "endpoint", "");
$apiKey = Option::get($moduleId, "api_key", "");
$iblockId = Option::get($moduleId, "iblock_id", "0");
$minLen = Option::get($moduleId, "min_text_len", "300");
$writeHl = Option::get($moduleId, "write_hl", "Y");
$baseUrl = Option::get($moduleId, "site_base_url", "");
$propTitle = Option::get($moduleId, "prop_seo_title", "");
$propDesc = Option::get($moduleId, "prop_meta_description", "");
?>
<form method="post">
  <?=bitrix_sessid_post()?>
  <table class="adm-detail-content-table edit-table">
    <tr><td width="40%">Enabled</td><td><input type="checkbox" name="enabled" value="Y" <?=$enabled==="Y"?"checked":""?>></td></tr>
    <tr><td>WP Endpoint</td><td><input style="width:80%" name="endpoint" value="<?=htmlspecialcharsbx($endpoint)?>"></td></tr>
    <tr><td>API Key (X-SEOJusAI-Key)</td><td><input style="width:50%" name="api_key" value="<?=htmlspecialcharsbx($apiKey)?>"></td></tr>
    <tr><td>IBlock ID (0 = all)</td><td><input name="iblock_id" value="<?=htmlspecialcharsbx($iblockId)?>"></td></tr>
    <tr><td>Site Base URL (optional)</td><td><input style="width:50%" name="site_base_url" value="<?=htmlspecialcharsbx($baseUrl)?>"></td></tr>
    <tr><td>Min text length</td><td><input name="min_text_len" value="<?=htmlspecialcharsbx($minLen)?>"></td></tr>
    <tr><td>Write to HL-block SeoAiResults</td><td><input type="checkbox" name="write_hl" value="Y" <?=$writeHl==="Y"?"checked":""?>></td></tr>
    <tr><td>Property code for SEO Title (apply)</td><td><input name="prop_seo_title" value="<?=htmlspecialcharsbx($propTitle)?>"></td></tr>
    <tr><td>Property code for Meta Description (apply)</td><td><input name="prop_meta_description" value="<?=htmlspecialcharsbx($propDesc)?>"></td></tr>
  </table>
  <input type="submit" value="Save" class="adm-btn-save">
</form>
<p><a href="/bitrix/admin/seojusai_connector_results.php">Open results / approve / apply</a></p>
