<?php
\Bitrix\Main\Loader::registerAutoLoadClasses("seojusai.connector",[
 "\\SEOJusAI\\Connector\\Service\\Client"=>"lib/Service/Client.php",
 "\\SEOJusAI\\Connector\\Service\\Analyzer"=>"lib/Service/Analyzer.php",
 "\\SEOJusAI\\Connector\\Service\\Storage"=>"lib/Service/Storage.php",
]);
