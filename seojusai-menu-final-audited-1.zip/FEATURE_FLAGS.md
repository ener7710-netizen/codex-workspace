# SEOJusAI — Feature Flags

Цей файл описує механізм **Feature Flags** у SEOJusAI (v1.2+).

## Навіщо
Feature Flags дозволяють:
- безпечно вмикати/вимикати нову логіку (особливо AI) без ризику для продакшену;
- швидко вимкнути експериментальну функцію у разі проблем;
- поступово розгортати зміни (staging → production).

## Де керувати
Адмінка: **SEOJusAI → AI та Дані → Feature Flags**

## REST API
- `GET /wp-json/seojusai/v1/features`
- `POST /wp-json/seojusai/v1/features` з параметрами `key`, `enabled`, `note`
- `GET /wp-json/seojusai/v1/features/audit`

## Безпека
- Увімкнення/вимкнення вимагає capability `seojusai_manage_features` (fallback: `seojusai_manage_settings`/`manage_options`).
- Усі зміни пишуться в audit log (`seojusai_feature_flags_audit`), з обмеженням 200 записів.

