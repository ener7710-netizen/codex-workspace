# SEOJusAI — Security Changelog (2026)

Дата: 2026-01-22

## P0/P1/P2 Hardening

- Explanations DB: уніфікована схема `seojusai_explanations` та репозиторії (без silent-loss).
- Sitemap: прибрані власні rewrite rules (`sitemap_index.xml` тощо). Використовується WP Core Sitemaps + фільтри (без конфліктів з Yoast/RankMath).
- Robots: модуль приведено до ModuleInterface, sitemap URL → `wp-sitemap.xml`, авто-вимкнення при активному SEO-плагіні.
- Schema JSON-LD: додано JSON_HEX_* флаги при `wp_json_encode` для захисту від XSS у `<script type="application/ld+json">`.
- Redirects: `wp_redirect()` замінено на `wp_safe_redirect()` + `wp_validate_redirect()` + host restriction.
- Apply: усунено подвійне виконання (executor vs legacy). Додано mutex lock на рішення.
- Settings: secrets переведені у `SecretsVault` (шифрування), `gsc_json` — строгий JSON + size limit.
- REST: глобальний payload size guard (512KB) для namespace `/seojusai/v1`.
- SnapshotRepository::exists(): кешування результату (без SHOW TABLES на кожен запит).
- VectorStore search: кешування результатів (10 хв).

