/**
 * SEOJusAI Sidebar for Gutenberg
 * SINGLE SOURCE OF TRUTH
 */
(function (wp) {
	if (!wp || !wp.plugins || !wp.editPost) {
		console.error('SEOJusAI: Gutenberg API not found');
		return;
	}

	console.log('SEOJusAI: Sidebar loaded');

	const { registerPlugin } = wp.plugins;
	const { PluginSidebar, PluginSidebarMoreMenuItem } = wp.editPost;
	const { PanelBody, Button, TextareaControl, TabPanel, Spinner, ToggleControl, Notice } = wp.components;
	const { createElement: el, Fragment, useState } = wp.element;
	const apiFetch = wp.apiFetch;

	/* ===============================
	 * NONCE — ОБЯЗАТЕЛЬНО
	 * =============================== */
	if (typeof SEOJusAIEditor === 'undefined' || !SEOJusAIEditor.nonce) {
		console.error('SEOJusAI: nonce not provided');
		return;
	}

	apiFetch.use(
		wp.apiFetch.createNonceMiddleware(SEOJusAIEditor.nonce)
	);

	/* ===============================
	 * ICON
	 * =============================== */
	const PluginIcon = el('span', {
		className: 'dashicons dashicons-chart-area',
		style: { fontSize: '20px' }
	});

	/* ===============================
	 * HELPERS
	 * =============================== */
	const getPostId = () => {
		const editor = wp.data.select('core/editor');
		return editor ? editor.getCurrentPostId() : 0;
	};

	/* ===============================
	 * SIDEBAR CONTENT
	 * =============================== */
	const SidebarContent = () => {

		const postId = getPostId();

		const [chatMsg, setChatMsg] = useState('');
		const [isLearning, setIsLearning] = useState(false);
		const [response, setResponse] = useState('');
		const [isAnalyzing, setIsAnalyzing] = useState(false);
		const [auditData, setAuditData] = useState(null);
		const [schemaCode, setСхемаCode] = useState('');
		const [schemaPreview, setСхемаPreview] = useState('');
		const [schemaПопередженняs, setСхемаПопередженняs] = useState([]);
		const [isСхемаBusy, setIsСхемаBusy] = useState(false);
		const [error, setError] = useState('');
		const [notice, setNotice] = useState('');

		/* ===============================
		 * AUDIT
		 * =============================== */
		const runAudit = () => {

			if (!postId) {
				setError('Post ID не знайдено. Збережи сторінку.');
				return;
			}

			console.log('SEOJusAI: run audit for post', postId);

			setIsAnalyzing(true);
			setError('');
			setNotice('');
			setResponse('');

			apiFetch({
				path: '/seojusai/v1/page-audit-summary',
				method: 'POST',
				data: { post_id: postId }
			})
				.then(res => {

					console.log('SEOJusAI audit response:', res);

					if (!res || res.ok === false) {
						throw new Error(res?.error || 'Audit failed');
					}

					setAuditData(res);
				})
				.catch(e => {
					console.error('SEOJusAI audit error:', e);
					setError(e.message || 'Помилка аудиту');
				})
				.finally(() => setIsAnalyzing(false));
		};

		/* ===============================
		 * CHAT
		 * =============================== */
		const sendChat = () => {
			if (!chatMsg || !postId) return;

			setResponse('AI відповідає…');
			setError('');
			setNotice('');

			apiFetch({
				path: '/seojusai/v1/chat',
				method: 'POST',
				data: {
					post_id: postId,
					message: chatMsg,
					is_learning: isLearning
				}
			})
				.then(res => {
					if (!res || res.ok === false) {
						throw new Error(res?.reply || 'Chat error');
					}
					setResponse(res.reply || '');
					setChatMsg('');
				})
				.catch(e => {
					console.error('SEOJusAI chat error:', e);
					setError(e.message || 'Помилка чату');
				});
		};

		/* ===============================
		 * SCHEMA: PREVIEW / APPLY
		 * =============================== */
		const previewСхема = () => {

			if (!postId) {
				setError('Post ID не знайдено. Збережи сторінку.');
				return;
			}
			if (!schemaCode.trim()) {
				setError('Схема порожня.');
				return;
			}

			setIsСхемаBusy(true);
			setError('');
			setNotice('');
			setСхемаPreview('');
			setСхемаПопередженняs([]);

			apiFetch({
				path: '/seojusai/v1/schema/preview',
				method: 'POST',
				data: {
					post_id: postId,
					schema: schemaCode
				}
			})
				.then(res => {
					if (!res || res.ok === false) {
						throw new Error(res?.error || 'Preview error');
					}
					setСхемаPreview(res.pretty || '');
					setСхемаПопередженняs(Array.isArray(res.warnings) ? res.warnings : []);
					if (res.pretty) setСхемаCode(res.pretty);
				})
				.catch(e => setError(e.message || 'Помилка preview'))
				.finally(() => setIsСхемаBusy(false));
		};

		const applyСхема = () => {

			if (!postId) {
				setError('Post ID не знайдено. Збережи сторінку.');
				return;
			}
			if (!schemaCode.trim()) {
				setError('Схема порожня.');
				return;
			}

			setIsСхемаBusy(true);
			setError('');
			setNotice('');

			apiFetch({
				path: '/seojusai/v1/schema/apply',
				method: 'POST',
				data: {
					post_id: postId,
					schema: schemaCode
				}
			})
				.then(res => {
					if (!res || res.ok === false) {
						throw new Error(res?.error || 'Apply error');
					}
					setNotice('Схема застосовано. Snapshot: ' + (res.snapshot_id || '—'));
				})
				.catch(e => setError(e.message || 'Помилка apply'))
				.finally(() => setIsСхемаBusy(false));
		};

		const tabs = [
			{ name: 'audit', title: 'Аудит' },
			{ name: 'chat', title: 'AI Чат' },
			{ name: 'schema', title: 'Схема' }
		];

		return el(Fragment, null,

			error && el(Notice, {
				status: 'error',
				isDismissible: true,
				onRemove: () => setError('')
			}, error),

			notice && el(Notice, {
				status: 'success',
				isDismissible: true,
				onRemove: () => setNotice('')
			}, notice),

			el(TabPanel, { tabs }, tab => {

				if (tab.name === 'audit') {
					return el(PanelBody, { title: 'SEO Аудит', initialOpen: true },

						isAnalyzing
							? el(Spinner)
							: el(Button, {
								isPrimary: true,
								style: { width: '100%' },
								onClick: runAudit
							}, 'Запустити аудит'),

						auditData && el('div', { style: { marginTop: '10px' } },
							el('div', { style: { display: 'flex', gap: '8px', marginBottom: '10px', fontSize: '12px' } },
								el('span', null, `Критично: ${(auditData.counts && auditData.counts.critical) || 0}`),
								el('span', null, `Попередження: ${(auditData.counts && auditData.counts.warning) || 0}`),
								el('span', null, `Інформація: ${(auditData.counts && auditData.counts.info) || 0}`)
							),
							Array.isArray(auditData.issues) && auditData.issues.length > 0
								? el('ul', { style: { fontSize: '12px', marginLeft: '18px' } },
									auditData.issues.map((it, i) =>
										el('li', { key: i }, `${it.level}: ${it.message}`)
									)
								)
								: el('p', { style: { fontSize: '12px' } }, 'Проблем не знайдено')
						),

						auditData && el('p', { style: { fontSize: '11px', opacity: 0.7 } },
							auditData.facts && auditData.facts.snapshot_at ? `Snapshot: ${new Date(auditData.facts.snapshot_at * 1000).toLocaleString()}` : ''
						),
					);
				}

				if (tab.name === 'chat') {
					return el(PanelBody, { title: 'AI Чат', initialOpen: true },
						el(ToggleControl, {
							label: 'Навчати систему',
							checked: isLearning,
							onChange: () => setIsLearning(!isLearning)
						}),
						el(TextareaControl, {
							value: chatMsg,
							onChange: setChatMsg,
							placeholder: 'Запитай AI про сторінку…'
						}),
						el(Button, {
							isPrimary: true,
							onClick: sendChat
						}, 'Надіслати'),
						response && el('p', null, response)
					);
				}

				if (tab.name === 'schema') {
					return el(PanelBody, { title: 'Схема', initialOpen: true },

						el(TextareaControl, {
							value: schemaCode,
							onChange: setСхемаCode,
							rows: 12,
							style: { fontFamily: 'monospace', fontSize: '11px' }
						}),

						schemaПопередженняs && schemaПопередженняs.length > 0 && el('div', {
							style: { marginTop: '8px', fontSize: '12px' }
						},
							el('strong', null, 'Попередження:'),
							el('ul', null, schemaПопередженняs.map((w, i) => el('li', { key: i }, w)))
						),

						el('div', { style: { display: 'flex', gap: '8px', marginTop: '10px' } },
							el(Button, { isSecondary: true, onClick: previewСхема, disabled: isСхемаBusy }, isСхемаBusy ? '…' : 'Preview'),
							el(Button, { isPrimary: true, onClick: applyСхема, disabled: isСхемаBusy }, isСхемаBusy ? '…' : 'Apply')
						),

						schemaPreview && el('pre', {
							style: { fontSize: '11px', whiteSpace: 'pre-wrap', marginTop: '10px' }
						}, schemaPreview)
					);
				}
			})
		);
	};

	/* ===============================
	 * REGISTER SIDEBAR — ОДИН РАЗ
	 * =============================== */
	registerPlugin('seojusai-sidebar', {
		render: () => el(Fragment, null,
			el(PluginSidebarMoreMenuItem, {
				target: 'seojusai-sidebar',
				icon: PluginIcon
			}, 'SEOJusAI'),
			el(PluginSidebar, {
				name: 'seojusai-sidebar',
				title: 'SEOJusAI',
				icon: PluginIcon
			}, el(SidebarContent))
		)
	});

})(window.wp);