# SEOJusAI — Central Cache Layer

Namespaces: serp, gsc, site_audit, page_audit, explain, vector.

Адмінка: SEOJusAI → Стан системи → Кеш.

Принцип:
- wp_cache_* (Object Cache) first
- transient fallback
- namespace version tokens для інвалідації наборів ключів.

