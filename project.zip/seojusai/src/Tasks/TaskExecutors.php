<?php
declare(strict_types=1);

namespace SEOJusAI\Tasks;

use SEOJusAI\Core\EmergencyStop;
use SEOJusAI\Impact\ImpactAnalyzer;
use SEOJusAI\Learning\LearningRepository;
use SEOJusAI\Bulk\BulkJobRepository;
use SEOJusAI\Analyze\PageAuditRunner;
use SEOJusAI\Snapshots\SnapshotService;

defined('ABSPATH') || exit;

final class TaskExecutors {

	private static bool $registered = false;

	public static function register(): void {
		if ( self::$registered ) return;
		self::$registered = true;

		add_filter('seojusai/tasks/execute', [ self::class, 'handle' ], 10, 4);
	}

	public static function handle(bool $result, string $type, array $payload, array $task): bool {
		if ( EmergencyStop::is_active() ) return false;

		$post_id = (int) ($payload['post_id'] ?? 0);
		$before = $post_id > 0 ? self::capture_state($post_id) : [];

		$ok = match ($type) {
			'add_section'       => self::add_content_section($payload),
			'add_internal_link' => self::add_internal_link($payload),
			'add_schema'        => self::update_schema($payload),
			'page_audit'        => self::run_page_audit($payload),
			'apply_recommendations' => self::apply_recommendations($payload),
			'rollback_last'     => self::rollback_last($payload),
			default             => false,
		};

		if ($ok && $post_id > 0) {
			$after = self::capture_state($post_id);
			// Impact log
			if (class_exists(ImpactAnalyzer::class)) {
				(new ImpactAnalyzer())->record('apply', 'post', $post_id, $before, $after, [
					'task_id' => (int)($task['id'] ?? 0),
					'task_type' => $type,
					'decision_hash' => (string)($task['decision_hash'] ?? ''),
				]);
			}

			// Learning row (predicted values can be attached by AI/Opportunity)
			if (class_exists(LearningRepository::class)) {
				(new LearningRepository())->insert([
					'entity_type' => 'post',
					'entity_id' => $post_id,
					'decision_hash' => (string)($task['decision_hash'] ?? ''),
					'predicted_impact' => (float)($payload['predicted_impact'] ?? 0),
					'predicted_effort' => (float)($payload['predicted_effort'] ?? 0),
					'observed_clicks_delta' => 0,
					'observed_pos_delta' => 0,
					'observed_impressions_delta' => 0,
					'window_start' => null,
					'window_end' => null,
				]);
			}
		}

		self::maybe_bump_bulk($payload, $ok);
		return $ok;
	}

	/**
	 * Додає новий заголовок (H2-H4) в кінець контенту як плейсхолдер для юриста.
	 */
	private static function add_content_section(array $p): bool {
		$post_id = (int) ($p['post_id'] ?? 0);
		$level   = sanitize_key($p['level'] ?? 'h2');
		$title   = sanitize_text_field($p['title'] ?? '');

		if ( $post_id <= 0 || $title === '' ) return false;

		$content = get_post_field('post_content', $post_id);
		
		// Перевірка на дублікат заголовка
		if ( str_contains($content, $title) ) return true;

		$new_block = "\n\n";
		$new_block .= "<{$level}>" . esc_html($title) . "</{$level}>\n";
		$new_block .= "\n";
		$new_block .= "\n<p>ШІ рекомендує розкрити цю тему для покращення релевантності...</p>\n\n";

		return (bool) wp_update_post([
			'ID'           => $post_id,
			'post_content' => $content . $new_block,
		]);
	}

	private static function add_internal_link(array $p): bool {
		$post_id = (int) ($p['post_id'] ?? 0);
		$anchor  = sanitize_text_field($p['anchor'] ?? '');
		$url     = esc_url_raw($p['url'] ?? '');

		if ( $post_id <= 0 || !$anchor || !$url ) return false;

		$content = get_post_field('post_content', $post_id);
		$link = sprintf('<a href="%s">%s</a>', $url, $anchor);
		
		// Додаємо лінк в перший знайдений параграф
		$updated = preg_replace('/<\/p>/', " {$link}</p>", $content, 1);

		return (bool) wp_update_post(['ID' => $post_id, 'post_content' => $updated]);
	}

	private static function update_schema(array $p): bool {
		$post_id = (int) ($p['post_id'] ?? 0);
		$type    = sanitize_text_field($p['type'] ?? '');
		if ($post_id <= 0 || !$type) return false;

		$current = get_post_meta($post_id, '_seojusai_schema_types', true) ?: [];
		$current[] = $type;
		
		return (bool) update_post_meta($post_id, '_seojusai_schema_types', array_unique($current));
	}

private static function maybe_bump_bulk(array $payload, bool $ok): void {
	$bulk_id = (int)($payload['bulk_job_id'] ?? 0);
	if ($bulk_id <= 0) return;
	try { (new BulkJobRepository())->bump($bulk_id, $ok); } catch (\Throwable $e) {}
}

private static function run_page_audit(array $payload): bool {
	$post_id = (int) ($payload['post_id'] ?? 0);
	if ($post_id <= 0 || !class_exists(PageAuditRunner::class)) return false;
	try {
		(new PageAuditRunner())->run($post_id);
		return true;
	} catch (\Throwable $e) {
		return false;
	}
}

private static function apply_recommendations(array $payload): bool {
	$post_id = (int) ($payload['post_id'] ?? 0);
	if ($post_id <= 0) return false;

	$ok = false;
	$proposals = apply_filters('seojusai/proposals/for_post', [], $post_id);
	if (!is_array($proposals)) $proposals = [];

	foreach ($proposals as $p) {
		if (!is_array($p)) continue;
		$type = (string)($p['type'] ?? '');
		$data = (array)($p['payload'] ?? []);
		$data['post_id'] = $post_id;

		if (!in_array($type, ['add_section','add_internal_link','add_schema'], true)) continue;

		$one = match ($type) {
			'add_section' => self::add_content_section($data),
			'add_internal_link' => self::add_internal_link($data),
			'add_schema' => self::update_schema($data),
			default => false,
		};
		$ok = $ok || (bool) $one;
	}

	return $ok;
}

private static function rollback_last(array $payload): bool {
	$post_id = (int) ($payload['post_id'] ?? 0);
	if ($post_id <= 0 || !class_exists(SnapshotService::class)) return false;
	try {
		$service = new SnapshotService();
		$snapshot_id = $service->repo()->get_latest_post_snapshot_id($post_id);
		if ($snapshot_id <= 0) return false;
		$res = $service->restore_post_snapshot($snapshot_id);
		return !is_wp_error($res);
	} catch (\Throwable $e) {
		return false;
	}
}

}
