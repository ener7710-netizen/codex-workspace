<?php
declare(strict_types=1);

namespace SEOJusAI\Tasks;

use SEOJusAI\Core\EmergencyStop;

defined('ABSPATH') || exit;

final class TaskRunner {

    private TaskQueue $queue;

    public function __construct(?TaskQueue $queue=null) {
        $this->queue = $queue ?? new TaskQueue();
    }

    public function register(): void {
        add_action(ActionSchedulerBridge::HOOK_RUN_TASK, [$this, 'run_action'], 10, 1);
    }

    public function run_action($task_id): void {
        $task_id = (int) $task_id;
        if ($task_id <= 0) return;
        if (EmergencyStop::is_active()) return;

        // Concurrency guard
        $limit = (int) get_option('seojusai_tasks_concurrency', 5);
        if ($limit < 1) $limit = 1;
        if ($this->queue->count_running() >= $limit) {
            // reschedule shortly
            $this->queue->reschedule($task_id, time() + 60, 'concurrency_limit');
            ActionSchedulerBridge::schedule($task_id, time() + 60);
            return;
        }

        // Reserve by id (atomic)
        $task = $this->queue->reserve_by_id($task_id);
        if (!$task) return;

        $ok = false;
        try {
            $ok = (bool) apply_filters('seojusai/tasks/execute', false, (string)$task['action'], (array)$task['payload'], $task);
        } catch (\Throwable $e) {
            $ok = false;
            $this->queue->set_last_error($task_id, $e->getMessage());
        }

        if ($ok) {
            $this->queue->complete($task_id);
            return;
        }

        // Fail + retry or DLQ
        $this->queue->fail_and_maybe_retry($task_id);
    }
}
