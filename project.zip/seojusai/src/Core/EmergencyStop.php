<?php
declare(strict_types=1);

namespace SEOJusAI\Core;

if ( ! defined('ABSPATH') ) {
	exit;
}

/**
 * EmergencyStop
 *
 * Глобальний safety-guard для блокування деструктивних/автоматичних операцій.
 *
 * ВАЖЛИВО:
 * - Kernel/REST/Executors/Autopilot мають перевіряти EmergencyStop::is_active()
 * - Це не SEO-логіка, лише state + guard
 */
final class EmergencyStop {

	private const OPTION_KEY = 'seojusai_emergency_stop';

	private function __construct() {}

	/**
	 * Чи активна аварійна зупинка.
	 */
	public static function is_active(): bool {
		return (bool) get_option(self::OPTION_KEY, false);
	}

	/**
	 * Увімкнути аварійну зупинку.
	 *
	 * @return bool true якщо стан змінився або вже активний
	 */
	public static function activate(): bool {
		if ( self::is_active() ) {
			return true;
		}

		$ok = update_option(self::OPTION_KEY, true, false);

		/**
		 * Подія для UI/логів/monitoring.
		 */
		do_action('seojusai/emergency/changed', [
			'active'    => true,
			'user_id'   => get_current_user_id(),
			'timestamp' => time(),
			'source'    => 'system',
		]);

		return (bool) $ok;
	}

	/**
	 * Вимкнути аварійну зупинку.
	 *
	 * @return bool true якщо стан змінився або вже вимкнений
	 */
	public static function deactivate(): bool {
		if ( ! self::is_active() ) {
			return true;
		}

		$ok = delete_option(self::OPTION_KEY);

		do_action('seojusai/emergency/changed', [
			'active'    => false,
			'user_id'   => get_current_user_id(),
			'timestamp' => time(),
			'source'    => 'system',
		]);

		return (bool) $ok;
	}

	/**
	 * Зручний сеттер (для адмінки/REST).
	 */
	public static function set(bool $active): bool {
		return $active ? self::activate() : self::deactivate();
	}

	/**
	 * Ключ опції (для Settings API/аудиту).
	 */
	public static function option_key(): string {
		return self::OPTION_KEY;
	}
}