<?php
declare(strict_types=1);

namespace SEOJusAI\SERP;

use SEOJusAI\Core\EmergencyStop;

defined('ABSPATH') || exit;

final class SerpApiClient {

	private const API_URL = 'https://serpapi.com/search.json';

	private string $api_key;

	public function __construct() {
		$config = SerpConfig::get();
		$this->api_key = (string) ($config['serpapi_key'] ?? '');
	}

	public function is_ready(): bool {
		return $this->api_key !== '';
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function fetch(string $query, int $limit = 10): array {

		if (EmergencyStop::is_active() || ! $this->is_ready()) {
			return [];
		}

		$url = add_query_arg(
			[
				'q'       => $query,
				'engine'  => 'google',
				'num'     => min(10, max(1, $limit)),
				'api_key' => $this->api_key,
			],
			self::API_URL
		);

		$response = wp_remote_get($url, [
			'timeout'     => 30,
			'httpversion'=> '1.1',
		]);

		if (is_wp_error($response)) {
			return [];
		}

		$data = json_decode((string) wp_remote_retrieve_body($response), true);

		if (!is_array($data['organic_results'] ?? null)) {
			return [];
		}

		$out = [];
		$pos = 1;

		foreach ($data['organic_results'] as $row) {
			$out[] = [
				'position' => $pos++,
				'title'    => (string) ($row['title'] ?? ''),
				'url'      => (string) ($row['link'] ?? ''),
				'domain'   => parse_url((string) ($row['link'] ?? ''), PHP_URL_HOST),
				'snippet'  => (string) ($row['snippet'] ?? ''),
			];
		}

		return $out;
	}
}