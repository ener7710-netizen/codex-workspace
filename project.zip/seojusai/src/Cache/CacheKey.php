<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheKey {

    public static function make(string $ns, string $key): string {
        $ns = sanitize_key($ns);
        $key = preg_replace('/[^a-zA-Z0-9_:\-\.]/', '_', $key) ?? $key;
        return 'seojusai:' . $ns . ':' . $key;
    }
}
