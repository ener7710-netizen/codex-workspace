<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheService {

    /**
     * @return mixed|null
     */
    public static function get(string $ns, string $key) {
        $ttl = CacheTTL::for_namespace($ns);
        $ck = CacheKey::make($ns, $key);

        $val = wp_cache_get($ck, 'seojusai');
        if ($val !== false) {
            CacheStats::hit($ns);
            return $val;
        }

        // transient fallback
        $t = get_transient($ck);
        if ($t !== false) {
            wp_cache_set($ck, $t, 'seojusai', $ttl);
            CacheStats::hit($ns);
            return $t;
        }

        CacheStats::miss($ns);
        return null;
    }

    public static function set(string $ns, string $key, $value, ?int $ttl=null): bool {
        $ttl = $ttl ?? CacheTTL::for_namespace($ns);
        $ck = CacheKey::make($ns, $key);
        wp_cache_set($ck, $value, 'seojusai', $ttl);
        return set_transient($ck, $value, $ttl);
    }

    public static function delete(string $ns, string $key): void {
        $ck = CacheKey::make($ns, $key);
        wp_cache_delete($ck, 'seojusai');
        delete_transient($ck);
    }

    public static function purge_namespace(string $ns): void {
        // Transients are not enumerable reliably; we store a namespace version token.
        $ns = sanitize_key($ns);
        update_option('seojusai_cache_nsver_' . $ns, time(), false);
    }

    public static function nsver(string $ns): int {
        $ns = sanitize_key($ns);
        return (int) get_option('seojusai_cache_nsver_' . $ns, 0);
    }

    public static function keyed(string $ns, string $base): string {
        // include namespace version to invalidate sets
        return $base . ':v' . self::nsver($ns);
    }
}
