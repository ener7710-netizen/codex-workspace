<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheTTL {

    public const SERP      = 6 * HOUR_IN_SECONDS;
    public const GSC       = 30 * MINUTE_IN_SECONDS;
    public const SITE_AUDIT= 2 * HOUR_IN_SECONDS;
    public const PAGE_AUDIT= 2 * HOUR_IN_SECONDS;
    public const EXPLAIN   = 6 * HOUR_IN_SECONDS;
    public const VECTOR    = 10 * MINUTE_IN_SECONDS;

    public static function for_namespace(string $ns): int {
        switch ($ns) {
            case 'serp': return self::SERP;
            case 'gsc': return self::GSC;
            case 'site_audit': return self::SITE_AUDIT;
            case 'page_audit': return self::PAGE_AUDIT;
            case 'explain': return self::EXPLAIN;
            case 'vector': return self::VECTOR;
            default: return HOUR_IN_SECONDS;
        }
    }
}
