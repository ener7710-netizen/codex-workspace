<?php
declare(strict_types=1);

namespace SEOJusAI\Cache;

defined('ABSPATH') || exit;

final class CacheStats {

    private const OPTION_KEY = 'seojusai_cache_stats';

    public static function hit(string $ns): void {
        self::bump($ns, 'hit');
    }

    public static function miss(string $ns): void {
        self::bump($ns, 'miss');
    }

    private static function bump(string $ns, string $field): void {
        $ns = sanitize_key($ns);
        $stats = get_option(self::OPTION_KEY, []);
        if (!is_array($stats)) $stats = [];
        if (!isset($stats[$ns])) $stats[$ns] = ['hit'=>0,'miss'=>0,'ts'=>gmdate('c')];
        $stats[$ns][$field] = (int)($stats[$ns][$field] ?? 0) + 1;
        $stats[$ns]['ts'] = gmdate('c');
        update_option(self::OPTION_KEY, $stats, false);
    }

    /** @return array<string,array<string,mixed>> */
    public static function all(): array {
        $stats = get_option(self::OPTION_KEY, []);
        return is_array($stats) ? $stats : [];
    }

    public static function reset(): void {
        delete_option(self::OPTION_KEY);
    }
}
