<?php
declare(strict_types=1);

namespace SEOJusAI\Security;

defined('ABSPATH') || exit;

/**
 * RateLimiter (2026)
 *
 * Lightweight limiter for REST/apply/bulk/autopilot entrypoints.
 * Storage: transients (object cache friendly).
 */
final class RateLimiter {

    /**
     * @param string $bucket Logical action bucket, e.g. 'rest:apply'
     * @param int $limit Max hits in window
     * @param int $window Window seconds
     * @param int|null $user_id Defaults to current user
     */
    public static function allow(string $bucket, int $limit, int $window, ?int $user_id = null): bool {
        if ($limit <= 0 || $window <= 0) {
            return true;
        }

        $uid = $user_id ?? (function_exists('get_current_user_id') ? (int) get_current_user_id() : 0);
        $uid = max(0, $uid);

        $key = self::key($bucket, $uid);
        $now = time();

        $state = get_transient($key);
        if (!is_array($state)) {
            $state = [
                'count' => 0,
                'reset' => $now + $window,
            ];
        }

        $count = (int) ($state['count'] ?? 0);
        $reset = (int) ($state['reset'] ?? ($now + $window));

        if ($reset <= $now) {
            $count = 0;
            $reset = $now + $window;
        }

        $count++;

        $state = [
            'count' => $count,
            'reset' => $reset,
        ];

        // store until reset (+ small buffer)
        set_transient($key, $state, max(1, $reset - $now + 5));

        return $count <= $limit;
    }

    public static function key(string $bucket, int $user_id): string {
        $site = function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 0;
        return 'seojusai_rl_' . md5($site . '|' . $user_id . '|' . $bucket);
    }

    /**
     * Return seconds until bucket reset (best-effort).
     */
    public static function retry_after(string $bucket, ?int $user_id = null): int {
        $uid = $user_id ?? (function_exists('get_current_user_id') ? (int) get_current_user_id() : 0);
        $state = get_transient(self::key($bucket, $uid));
        if (!is_array($state)) return 0;
        $reset = (int) ($state['reset'] ?? 0);
        $now = time();
        return $reset > $now ? ($reset - $now) : 0;
    }
}
