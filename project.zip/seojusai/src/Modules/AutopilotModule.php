<?php
declare(strict_types=1);

namespace SEOJusAI\Modules;

use SEOJusAI\Core\Contracts\ModuleInterface;
use SEOJusAI\Core\Kernel;
use SEOJusAI\Autopilot\AutopilotEngine;

defined('ABSPATH') || exit;

final class AutopilotModule implements ModuleInterface {

	public function get_slug(): string {
		return 'autopilot';
	}

	public function register(Kernel $kernel): void {
		$kernel->register_module($this->get_slug(), $this);
	}

	public function init(Kernel $kernel): void {
		if (class_exists(AutopilotEngine::class)) {
			(new AutopilotEngine())->register();
		}
	}
}