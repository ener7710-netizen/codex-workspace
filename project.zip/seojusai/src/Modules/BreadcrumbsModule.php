<?php
declare(strict_types=1);

namespace SEOJusAI\Modules;

use SEOJusAI\Core\Contracts\ModuleInterface;
use SEOJusAI\Core\Kernel;
use SEOJusAI\Breadcrumbs\Breadcrumbs;

defined('ABSPATH') || exit;

final class BreadcrumbsModule implements ModuleInterface {

    public function get_slug(): string {
        return 'breadcrumbs';
    }

    public function init(\SEOJusAI\Core\Kernel $kernel): void {
        // Breadcrumbs module bootstrap (hooks registered lazily)
    }
public function id(): string { return 'breadcrumbs'; }

	public function name(): string { return 'Breadcrumbs'; }

	public function description(): string { return 'Хлібні крихти (shortcode [seojusai_breadcrumbs])'; }

	public function register(Kernel $kernel): void {
		add_action('init', function () {
			(new Breadcrumbs())->register();
		});
	}
}
