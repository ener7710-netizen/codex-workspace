<?php
declare(strict_types=1);

namespace SEOJusAI\Modules;

use SEOJusAI\Core\Contracts\ModuleInterface;
use SEOJusAI\Core\Kernel;

defined('ABSPATH') || exit;

final class LearningModule implements ModuleInterface {

    public function get_slug(): string { return 'learning'; }

    public function register(Kernel $kernel): void {
        $kernel->register_module($this->get_slug(), $this);
    }

    public function init(Kernel $kernel): void {
        add_action('rest_api_init', function (): void {
            register_rest_route('seojusai/v1', '/learning/run', [
                'methods'  => 'POST',
                'permission_callback' => ['SEOJusAI\\Rest\\RestKernel', 'can_manage_static'],
                'callback' => function () {
                    (new \SEOJusAI\Learning\LearningLoop())->run_weekly();
                    return rest_ensure_response(['ok' => true]);
                }
            ]);
        }, 20);
    }
}
