<?php
declare(strict_types=1);

namespace SEOJusAI\Modules;

use SEOJusAI\Core\Contracts\ModuleInterface;
use SEOJusAI\Core\Kernel;
use SEOJusAI\AI\AIKernel;

defined('ABSPATH') || exit;

final class AiModule implements ModuleInterface {

	public function get_slug(): string {
		return 'ai';
	}

	public function register(Kernel $kernel): void {
		$kernel->register_module($this->get_slug(), $this);
	}

	public function init(Kernel $kernel): void {
		if (class_exists(AIKernel::class)) {
			(new AIKernel())->register();
		}
	}
}