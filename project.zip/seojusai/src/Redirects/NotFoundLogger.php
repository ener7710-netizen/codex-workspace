<?php
declare(strict_types=1);

namespace SEOJusAI\Redirects;

use wpdb;

defined('ABSPATH') || exit;

final class NotFoundLogger {

	private string $table;

	public function __construct(?wpdb $db = null) {
		global $wpdb;
		$db = $db instanceof wpdb ? $db : $wpdb;
		$this->table = $db->prefix . 'seojusai_404';
	}

	public function exists(): bool {
		global $wpdb;
		return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $this->table)) === $this->table;
	}

	public function log(string $url, string $referrer = ''): void {
		global $wpdb;
		$url = esc_url_raw($url);
		$referrer = esc_url_raw($referrer);
		if ($url === '') return;

		$row = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$this->table} WHERE url=%s", $url), ARRAY_A);
		if ($row) {
			$wpdb->query($wpdb->prepare("UPDATE {$this->table} SET hits = hits + 1, referrer=%s, last_seen=%s WHERE id=%d", $referrer, current_time('mysql'), (int)$row['id']));
			return;
		}
		$wpdb->insert($this->table, [
			'url' => $url,
			'referrer' => $referrer,
			'hits' => 1,
			'first_seen' => current_time('mysql'),
			'last_seen' => current_time('mysql'),
		]);
	}

	public function top(int $limit=100): array {
		global $wpdb;
		return (array) $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table} ORDER BY hits DESC, last_seen DESC LIMIT %d", max(1,$limit)), ARRAY_A);
	}
}
