<?php
declare(strict_types=1);

namespace SEOJusAI\AI;

defined('ABSPATH') || exit;

/**
 * DecisionContract
 * * 🔒 ЄДИНЕ джерело істини для AI-рішень.
 * Жорстко валідує вихідні дані від OpenAI та Gemini перед тим, як вони потраплять у чергу.
 */
final class DecisionContract {

	/**
	 * Головний метод валідації JSON-відповіді.
	 */
	public static function validate(array $decision): bool {

		// 1. Перевірка наявності основних секцій
		if ( empty($decision['meta']) || ! is_array($decision['meta']) ) {
			return false;
		}

		if ( ! isset($decision['actions']) || ! is_array($decision['actions']) ) {
			return false;
		}

		// 2. Детальна валідація мета-даних
		if ( ! self::validate_meta($decision['meta']) ) {
			return false;
		}

		// 3. Валідація кожної дії в масиві
		foreach ( $decision['actions'] as $action ) {
			if ( ! is_array($action) || ! self::validate_action($action) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Валідація секції META.
	 */
	private static function validate_meta(array $meta): bool {
		// Обов'язкові поля
		$required = ['confidence', 'risk', 'summary'];
		foreach ( $required as $key ) {
			if ( ! isset($meta[$key]) ) return false;
		}

		// Confidence має бути від 0 до 1
		if ( ! is_numeric($meta['confidence']) || $meta['confidence'] < 0 || $meta['confidence'] > 1 ) {
			return false;
		}

		// Ризик має бути зі списку
		if ( ! in_array($meta['risk'], ['low', 'medium', 'high'], true) ) {
			return false;
		}

		// Summary та Reasoning мають бути рядками
		if ( ! is_string($meta['summary']) || empty($meta['summary']) ) {
			return false;
		}

		return true;
	}

	/**
	 * Валідація конкретної дії.
	 */
	private static function validate_action(array $action): bool {
		// Обов'язкові поля в кожній дії
		if ( empty($action['action']) || ! is_string($action['action']) ) {
			return false;
		}

		if ( ! array_key_exists('auto', $action) ) {
			return false;
		}

		// Якщо дія помічена як AUTO, вона має бути в списку дозволених для автоматизації
		if ( (bool) $action['auto'] === true ) {
			if ( ! self::is_allowed_auto_action($action['action']) ) {
				return false;
			}
		}

		// Валідація параметрів для специфічних дій
		return self::validate_params($action['action'], $action['params'] ?? []);
	}

	/**
	 * Список дій, яким дозволено виконуватися без підтвердження юристом.
	 */
	private static function is_allowed_auto_action(string $action): bool {
		$allowed = [
			'add_faq_schema',     // Технічна розмітка
			'add_contact_schema', // Технічна розмітка
			'add_internal_link',  // Перелінковка (зазвичай безпечно)
			'cleanup_snapshots',  // Системна гігієна
			'add_schema',         // Додавання типів розмітки (Attorney, і т.д.)
		];

		return in_array($action, $allowed, true);
	}

	/**
	 * Глибока валідація параметрів під кожен тип дії.
	 */
	private static function validate_params(string $type, array $params): bool {
		return match ($type) {
			'add_section' => 
				isset($params['title'], $params['level']) && 
				in_array($params['level'], ['h2', 'h3', 'h4'], true),

			'add_internal_link' => 
				isset($params['from'], $params['to']) && 
				filter_var($params['to'], FILTER_VALIDATE_URL) !== false,

			'add_faq_schema' => 
				isset($params['faq']) && is_array($params['faq']),

			'cleanup_snapshots' => 
				isset($params['keep']) && is_int($params['keep']),

			default => true, // Для інших дій достатньо базової перевірки
		};
	}
}
