<?php
declare(strict_types=1);

namespace SEOJusAI\AI;

use SEOJusAI\Snapshots\SnapshotRepository;
use SEOJusAI\Explain\ExplanationRepository;
use SEOJusAI\Core\EmergencyStop;
use SEOJusAI\Crawl\PageVsSerpAnalyzer;

defined('ABSPATH') || exit;

final class GeminiAnalyzer {

	public static function run(string $site, int $post_id = 0): array {
		if (EmergencyStop::is_active()) return ['ok' => false];

		$site_id = (int) crc32($site);
		$snapshots = new SnapshotRepository();
		$explain   = new ExplanationRepository();
		
		$analyzer = new PageVsSerpAnalyzer();
		$content_compare = $analyzer->compare([
			'post_id' => $post_id,
			'url'     => get_permalink($post_id),
			'query'   => get_post_meta($post_id, '_seojusai_keyword', true) ?: get_the_title($post_id)
		]);

		$kernel = new AIKernel( \SEOJusAI\Core\Plugin::instance() );
		$result = $kernel->run_direct_gemini([
			'mode'    => 'content-expert',
			'compare' => $content_compare,
			'gsc'     => $snapshots->get_latest('gsc', $site_id, 3),
		]);

		if (empty($result['decision_hash'])) return ['ok' => false];

		$explain->save(
			'site',
			$site_id,
			$result['decision_hash'],
			$result['explanation'],
			$result['risk'] ?? 'low'
		);

		return ['ok' => true];
	}
}
