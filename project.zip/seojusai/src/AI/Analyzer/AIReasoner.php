<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Analyzer;

use SEOJusAI\AI\Chat\ChatPromptBuilder;
use SEOJusAI\AI\Client\AIClient;

defined('ABSPATH') || exit;

/**
 * AIReasoner
 * ------------------------------------------------------------
 * ЄДИНЕ місце виклику OpenAI через AIClient.
 *
 * ✔ живий діалог
 * ✔ контроль помилок
 * ✔ стабільна відповідь для UI
 * ✔ підтримка AI-задач (JSON)
 * ✔ підтримка E-E-A-T + KBE через $context
 *
 * ❌ НЕ застосовує зміни
 * ❌ НЕ викликає executors
 */
final class AIReasoner {

	/**
	 * Основний метод чату
	 *
	 * @param array<string,mixed> $context
	 * @return array{ok:bool,reply:string,tasks?:array,error?:string}
	 */
	public static function chat(array $context): array {

		/**
		 * 1️⃣ BUILD PROMPT (SINGLE SOURCE OF TRUTH)
		 */
		$prompt = ChatPromptBuilder::build($context);

		if (!is_string($prompt) || trim($prompt) === '') {
			return self::error('AI prompt is empty');
		}

		/**
		 * 2️⃣ CALL AI CLIENT (Replaced call_openai)
		 */
		try {
			$messages = [
				[
					'role'    => 'system',
					'content' =>
						'Ти досвідчений SEO-консультант і юридичний маркетолог. ' .
						'Ти відповідаєш як жива людина, а не бот. ' .
						'Ти спираєшся ТІЛЬКИ на аудит сторінки, її проблеми та SEO-контекст. ' .
						'Не вигадуй факти. Якщо можливо — формуй SEO-задачі.'
				],
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			];

			// Виклик нового клієнта згідно з вашим запитом
			$response = AIClient::chat([
				'messages' => $messages,
			], 'chat:' . ($context['post_id'] ?? 0));

		} catch (\Throwable $e) {
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[SEOJusAI AIReasoner] ' . $e->getMessage());
			}
			return self::error('AI request failed: ' . $e->getMessage());
		}

		if (!is_string($response) || trim($response) === '') {
			return self::error('Empty response from AI');
		}

		/**
		 * 3️⃣ TRY PARSE JSON (reply + tasks)
		 */
		$json = json_decode($response, true);

		if (is_array($json)) {
			return [
				'ok'    => true,
				'reply' => (string) ($json['reply'] ?? ''),
				'tasks' => is_array($json['tasks'] ?? null) ? $json['tasks'] : [],
			];
		}

		/**
		 * 4️⃣ FALLBACK — plain text
		 */
		return [
			'ok'    => true,
			'reply' => trim($response),
			'tasks' => [],
		];
	}

	/* ============================================================
	 * ERROR
	 * ============================================================ */

	/**
	 * Формування структури помилки
	 *
	 * @param string $msg
	 * @return array{ok:false,error:string}
	 */
	private static function error(string $msg): array {
		return [
			'ok'    => false,
			'error' => $msg,
		];
	}
}
