<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Providers;

defined('ABSPATH') || exit;

/**
 * OpenAIClient
 *
 * НИЗЬКОРІВНЕВИЙ HTTP-клієнт OpenAI.
 *
 * ❌ НЕ провайдер
 * ❌ НЕ стратегія
 *
 * ✔ тільки виклик API
 */
final class OpenAIClient {

	private string $api_key;
	private string $model;

	public function __construct(
		string $api_key,
		string $model = 'gpt-4.1'
	) {
		$this->api_key = trim($api_key);
		$this->model   = $model;
	}

	public function is_ready(): bool {
		return $this->api_key !== '';
	}

	/**
	 * @param string $prompt
	 * @param string $mode
	 * @return string|null
	 */
	public function generate(string $prompt, string $mode = 'full'): ?string {

		if (!$this->is_ready()) {
			return null;
		}

		$endpoint   = 'https://api.openai.com/v1/chat/completions';
		$max_tokens = $mode === 'editor' ? 600 : 1500;

		$response = wp_remote_post($endpoint, [
			'timeout' => 30,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type'  => 'application/json',
			],
			'body' => wp_json_encode([
				'model'       => $this->model,
				'messages'    => [
					[ 'role' => 'system', 'content' => $prompt ],
				],
				'temperature' => 0.2,
				'max_tokens'  => $max_tokens,
			]),
		]);

		if (is_wp_error($response)) {
			return null;
		}

		$data = json_decode(wp_remote_retrieve_body($response), true);

		return $data['choices'][0]['message']['content'] ?? null;
	}
	/**
	 * Embeddings
	 * @return array<float>|null
	 */
	public function embed(string $input, string $embedding_model = 'text-embedding-3-large'): ?array {
		if (!$this->is_ready()) return null;

		$endpoint = 'https://api.openai.com/v1/embeddings';
		$response = wp_remote_post($endpoint, [
			'timeout' => 30,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type'  => 'application/json',
			],
			'body' => wp_json_encode([
				'model' => $embedding_model,
				'input' => $input,
			]),
		]);

		if (is_wp_error($response)) return null;

		$data = json_decode(wp_remote_retrieve_body($response), true);
		$vec = $data['data'][0]['embedding'] ?? null;
		if (!is_array($vec)) return null;

		$out = [];
		foreach ($vec as $v) {
			$out[] = (float) $v;
		}
		return $out;
	}

}
