<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Providers;

defined('ABSPATH') || exit;

/**
 * GeminiClient
 *
 * НИЗЬКОРІВНЕВИЙ HTTP-клієнт Gemini.
 *
 * ❌ НЕ провайдер
 * ❌ НЕ стратегія
 * ❌ НЕ знає про Engine / Manager
 *
 * ✔ тільки API виклик
 */
final class GeminiClient {

	private string $api_key;
	private string $model;

	public function __construct(
		string $api_key,
		string $model = 'models/gemini-1.5-pro'
	) {
		$this->api_key = trim($api_key);
		$this->model   = $model;
	}

	public function is_ready(): bool {
		return $this->api_key !== '';
	}

	/**
	 * @param string $prompt
	 * @param string $mode
	 * @return string|null
	 */
	public function generate(string $prompt, string $mode = 'full'): ?string {

		if (!$this->is_ready()) {
			return null;
		}

		$endpoint = sprintf(
			'https://generativelanguage.googleapis.com/v1beta/%s:generateContent?key=%s',
			rawurlencode($this->model),
			rawurlencode($this->api_key)
		);

		$max_tokens = $mode === 'editor' ? 600 : 1500;

		$response = wp_remote_post($endpoint, [
			'timeout' => 30,
			'headers' => [
				'Content-Type' => 'application/json',
			],
			'body' => wp_json_encode([
				'contents' => [
					[
						'role'  => 'user',
						'parts' => [
							[ 'text' => $prompt ],
						],
					],
				],
				'generationConfig' => [
					'temperature'     => 0.2,
					'maxOutputTokens' => $max_tokens,
				],
			]),
		]);

		if (is_wp_error($response)) {
			return null;
		}

		$data = json_decode(wp_remote_retrieve_body($response), true);

		return $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
	}
}