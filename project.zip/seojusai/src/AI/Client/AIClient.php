<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Client;

use SEOJusAI\AI\Security\RateLimiter;
use SEOJusAI\AI\Proxy\ProxyResolver;
use SEOJusAI\AI\Billing\CreditManager;
use SEOJusAI\AI\Billing\UsageTracker;

defined('ABSPATH') || exit;

/**
 * AIClient
 * * Центральний вузол для виконання запитів до AI.
 * Об'єднує контроль лімітів, білінг, проксі та провайдерів.
 */
final class AIClient {

	/**
	 * Основний метод чату
	 *
	 * @param array<string,mixed> $payload Дані запиту
	 * @param string $scope Контекст запиту (напр. 'chat:123')
	 * @return array{ok:bool,reply?:string,error?:string,tasks?:array}
	 */
	public static function chat(array $payload, string $scope = 'default'): array {

		$user_id = (int) get_current_user_id();

		// 1️⃣ Rate limit (Захист від спаму API)
		$limiter = new RateLimiter(100, 3600);
		if (!$limiter->allow($scope)) {
			return [
				'ok'    => false,
				'error' => 'AI rate limit exceeded',
			];
		}

		// 2️⃣ Billing Check (Перевірка кредитів користувача)
		// Спочатку просто перевіряємо наявність
		if (!CreditManager::has_credits(1, $user_id)) {
			return [
				'ok'    => false,
				'error' => 'AI credits exhausted',
			];
		}

		// 3️⃣ Виконання запиту (Proxy або Local Provider)
		$result = self::execute_request($payload, $scope);

		// 4️⃣ Billing Consumption (Списання при успіху)
		if (!empty($result['ok'])) {
			CreditManager::consume(1, $user_id);
			UsageTracker::log([
				'user_id' => $user_id,
				'scope'   => $scope,
				'ok'      => true,
			]);
		}

		return $result;
	}

	/**
	 * Логіка вибору транспорту (Proxy або Провайдер)
	 */
	private static function execute_request(array $payload, string $scope): array {

		// Варіант А: Через проксі-сервер
		if (ProxyResolver::is_proxy_enabled()) {
			$response = wp_remote_post(
				ProxyResolver::endpoint() . '/chat',
				[
					'timeout' => 45,
					'headers' => array_merge(
						['Content-Type' => 'application/json'],
						ProxyResolver::headers()
					),
					'body' => wp_json_encode($payload),
				]
			);

			if (is_wp_error($response)) {
				return ['ok' => false, 'error' => 'Proxy communication error'];
			}

			$data = json_decode(wp_remote_retrieve_body($response), true);
			return is_array($data) ? $data : ['ok' => false, 'error' => 'Invalid proxy response'];
		}

		// Варіант Б: Прямий виклик локального провайдера
		$requested_provider = $payload['provider'] ?? 'openai';

		// Логіка для Gemini
		if ($requested_provider === 'gemini') {
			if (class_exists(\SEOJusAI\AI\Providers\GeminiClient::class)) {
				$gemini_key = apply_filters('seojusai/gemini_key', get_option('seojusai_gemini_key', ''));
				$client = new \SEOJusAI\AI\Providers\GeminiClient((string)$gemini_key);
				
				$result = $client->analyze($payload, $scope);
				return $result ?? ['ok' => false, 'error' => 'Gemini failed to analyze'];
			}
		}

		// Логіка для OpenAI (за замовчуванням)
		if (class_exists(\SEOJusAI\AI\Providers\OpenAIClient::class)) {
			$client = new \SEOJusAI\AI\Providers\OpenAIClient();
			return $client->chat($payload);
		}

		return [
			'ok'    => false,
			'error' => 'No active AI provider found',
		];
	}
}
