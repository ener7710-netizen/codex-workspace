<?php
declare(strict_types=1);

namespace SEOJusAI\Rest\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use SEOJusAI\Input\Input;
use SEOJusAI\GSC\GSCClient;
use SEOJusAI\Rest\RestKernel;
use SEOJusAI\Rest\AbstractRestController;
use SEOJusAI\Rest\Contracts\RestControllerInterface;

defined('ABSPATH') || exit;

final class GscController extends AbstractRestController implements RestControllerInterface {

	private GSCClient $gsc;

	public function __construct() {
		parent::__construct();
		$this->gsc = new GSCClient();
	}

	public function register_routes(): void {
		register_rest_route('seojusai/v1', '/gsc/properties', [
			'methods'             => 'GET',
			'permission_callback' => [ RestKernel::class, 'can_manage' ],
			'callback'            => [ $this, 'properties' ],
		]);

		register_rest_route('seojusai/v1', '/gsc/analytics', [
			'methods'             => 'POST',
			'permission_callback' => [ RestKernel::class, 'can_manage' ],
			'callback'            => [ $this, 'analytics' ],
		]);
	}

	public function properties(): WP_REST_Response {
		return new WP_REST_Response([
			'connected'  => $this->gsc->is_connected(),
			'properties' => $this->gsc->list_properties(),
		], 200);
	}

	public function analytics(WP_REST_Request $request): WP_REST_Response {
		$site = sanitize_text_field((string) $request->get_param('site'));
		if (empty($site)) {
			return $this->error('Site property required', 'missing_param', 400);
		}

		$data = $this->gsc->get_search_analytics($site, (array) (Input::json_array_strict((string)$request->get_body(), 200000)['data'] ?? []));
		return $this->ok(['rows' => $data]);
	}
}
