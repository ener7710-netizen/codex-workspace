<?php
declare(strict_types=1);

namespace SEOJusAI\Rest\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use SEOJusAI\Analyze\PageAuditSummary;
use SEOJusAI\Input\Input;
use SEOJusAI\Rest\AbstractRestController;
use SEOJusAI\Rest\Contracts\RestControllerInterface;
use SEOJusAI\Rest\RestKernel;

defined('ABSPATH') || exit;

/**
 * PageAuditSummaryController
 * Fast, UI-ready summary for a single post (counts + issues).
 */
final class PageAuditSummaryController extends AbstractRestController implements RestControllerInterface {

    public function register_routes(): void {
        register_rest_route('seojusai/v1', '/page-audit-summary', [
            'methods'             => 'POST',
            'permission_callback' => [ RestKernel::class, 'can_execute' ],
            'callback'            => [ $this, 'handle' ],
        ]);
    }

    public function handle(WP_REST_Request $request): WP_REST_Response {

        $post_id = Input::int($request->get_param('post_id'), 0, 0, PHP_INT_MAX);
        if ($post_id <= 0) {
            return new WP_REST_Response(['ok' => false, 'error' => 'invalid_post_id'], 400);
        }

        $summary = PageAuditSummary::compute($post_id, false);
        if (!empty($summary['ok'])) {
            PageAuditSummary::store($post_id, $summary);
        }

        return new WP_REST_Response($summary, 200);
    }
}
