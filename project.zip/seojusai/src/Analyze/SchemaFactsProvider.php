<?php
declare(strict_types=1);

namespace SEOJusAI\Analyze;

use SEOJusAI\Schema\SchemaExtractor;
use SEOJusAI\Schema\SchemaGapAnalyzer;
use SEOJusAI\Schema\SchemaExpectationMap;

defined('ABSPATH') || exit;

/**
 * SchemaFactsProvider
 *
 * Роль:
 * - витягує JSON-LD зі сторінки (HTML)
 * - рахує GAP відносно очікувань (ExpectationMap)
 * - повертає факти для AI/DecisionPipeline
 */
final class SchemaFactsProvider {

	private SchemaExtractor $extractor;
	private SchemaGapAnalyzer $gap;
	private SchemaExpectationMap $map;

	public function __construct() {
		$this->extractor = new SchemaExtractor();
		$this->gap       = new SchemaGapAnalyzer();
		$this->map       = new SchemaExpectationMap();
	}

	/**
	 * @return array<string,mixed>
	 */
	public function build(int $post_id, string $html, string $page_type = ''): array {

		$page_type = $page_type !== '' ? sanitize_key($page_type) : 'unknown';

		$items = [];
		$error = '';

		try {
			$items = $this->extractor->extract($html); // очікуємо масив JSON-LD
		} catch (\Throwable $e) {
			$error = $e->getMessage();
		}

		$expected = [];
		try {
			$expected = $this->map->get_for($page_type);
		} catch (\Throwable $e) {
			// мапа очікувань може бути порожньою — це не критично
		}

		$gap = [
			'severity' => 'none',
			'missing'  => [],
			'extra'    => [],
			'notes'    => [],
		];

		try {
			$gap = $this->gap->analyze($items, $expected, $page_type);
		} catch (\Throwable $e) {
			$gap['severity'] = 'unknown';
			$gap['notes'][]  = $e->getMessage();
		}

		$has_schema = is_array($items) && ! empty($items);

		return [
			'post_id'       => $post_id,
			'page_type'     => $page_type,

			// поточна схема
			'has_schema'    => $has_schema,
			'jsonld_count'  => is_array($items) ? count($items) : 0,

			// очікування + розрив
			'expected'      => $expected,
			'gap'           => $gap,

			// діагностика
			'error'         => $error,
		];
	}
}