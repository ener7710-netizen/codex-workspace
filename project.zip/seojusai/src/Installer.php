<?php
declare(strict_types=1);

namespace SEOJusAI;

defined('ABSPATH') || exit;

use SEOJusAI\Capabilities\RoleInstaller;

final class Installer {

    public static function install(): void {
        // Capabilities
        if (class_exists('\\SEOJusAI\\Capabilities\\RoleInstaller')) {
            \SEOJusAI\Capabilities\RoleInstaller::install();
        }

        // Єдина точка створення таблиць
        if (class_exists('\\SEOJusAI\\Database\\Tables')) {
            (new \SEOJusAI\Database\Tables())->create();
        }

        // Версія БД
        update_option('seojusai_db_version', '2026.1.1', false);

        // Планувальник фонового воркера
        if (class_exists('\\SEOJusAI\\Background\\Scheduler')) {
            (new \SEOJusAI\Background\Scheduler())->ensure_recurring();
        }
    }
}
