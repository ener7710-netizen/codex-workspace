<?php
declare(strict_types=1);

use SEOJusAI\Capabilities\CapabilityGuard;

defined('ABSPATH') || exit;

$can = CapabilityGuard::can('seojusai_run_analysis');
if (!$can) {
    echo '<div class="wrap"><h1>'.esc_html__('Ринкові сигнали', 'seojusai').'</h1><p>'.esc_html__('Недостатньо прав доступу.', 'seojusai').'</p></div>';
    return;
}

wp_enqueue_style('seojusai-market', SEOJUSAI_URL . 'assets/css/market.css', [], '1.0.0');
wp_enqueue_script('seojusai-market', SEOJUSAI_URL . 'assets/js/market.js', ['wp-api-fetch'], '1.0.0', true);
wp_add_inline_script('seojusai-market', 'window.SEOJusAIMarket = ' . wp_json_encode([
    'nonce' => wp_create_nonce('wp_rest'),
    'restUrl' => esc_url_raw(rest_url('seojusai/v1')),
]) . ';', 'before');

?>

<div class="wrap seojusai-market">
    <h1><?php echo esc_html__('Ринкові сигнали (конкуренти)', 'seojusai'); ?></h1>

    <div class="notice notice-info">
        <p><strong><?php echo esc_html__('Що це робить:', 'seojusai'); ?></strong> <?php echo esc_html__('плагін збирає лише сигнали (наявність soft CTA, позиція, тип сторінки) і НЕ зберігає тексти конкурентів.', 'seojusai'); ?></p>
    </div>

    <div class="card">
        <h2><?php echo esc_html__('Оновити конкурентів з SERP/Gemini', 'seojusai'); ?></h2>
        <p><?php echo esc_html__('Конкуренти визначаються автоматично на основі SERP (через Gemini/SERP-шар). Ручний ввід вимкнено за каноном архітектури.', 'seojusai'); ?></p>
        <p>
            <button class="button button-primary seojusai-market-refresh"><?php echo esc_html__('Оновити та просканувати', 'seojusai'); ?></button>
            <span class="seojusai-market-status"></span>
        </p>
        <p class="description"><?php echo esc_html__('Запити для SERP беруться з GSC snapshot (якщо є) або з ключових слів сторінок як fallback.', 'seojusai'); ?></p>
    </div>

    <h2><?php echo esc_html__('Список конкурентів (read-only)', 'seojusai'); ?></h2>
    <div class="seojusai-market-competitors"></div>

    <h2><?php echo esc_html__('Зведення правил (для Lead Funnel)', 'seojusai'); ?></h2>
    <div class="seojusai-market-summary"></div>
</div>
