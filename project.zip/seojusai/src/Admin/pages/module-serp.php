<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

if ( ! current_user_can('manage_options') ) {
	return;
}

use SEOJusAI\Core\ModuleRegistry;
use SEOJusAI\SERP\SerpConfig;

$modules = ModuleRegistry::instance();
$all     = $modules->all();

$enabled = ! empty($all['serp']['enabled']);

$config = class_exists(SerpConfig::class)
	? SerpConfig::get()
	: [];

$has_serpapi = ! empty($config['serpapi_key'] ?? '');

echo '<div class="wrap seojusai-module serp">';
echo '<h1>Аналіз результатів пошуку (SERP)</h1>';
echo '<p class="description">Дані конкурентів для стратегічного аналізу AI.</p>';

echo '<hr>';

echo '<h2>Статус</h2>';
echo '<ul>';
echo '<li><strong>Модуль SERP:</strong> ' . ($enabled ? '🟢 увімкнено' : '🔴 вимкнено') . '</li>';
echo '<li><strong>SerpAPI:</strong> ' . ($has_serpapi ? '🟢 підключено' : '🟡 не налаштовано') . '</li>';
echo '</ul>';

echo '<hr>';

echo '<h2>Доступні сигнали</h2>';
echo '<table class="widefat striped">';
echo '<thead><tr><th>Сигнал</th><th>Статус</th><th>Призначення</th></tr></thead><tbody>';

echo '<tr>
	<td>SerpAPI (top-10)</td>
	<td>' . ($has_serpapi ? '🟢' : '🟡') . '</td>
	<td>URL, позиції, snippets конкурентів</td>
</tr>';

echo '<tr>
	<td>Fingerprint конкурентів</td>
	<td>🟢</td>
	<td>H1, Title, Canonical, Schema, HTTP</td>
</tr>';

echo '<tr>
	<td>Історія SERP</td>
	<td>🟡</td>
	<td>Накопичується автоматично після рішень AI</td>
</tr>';

echo '</tbody></table>';

echo '<hr>';

echo '<h2>Логіка використання</h2>';
echo '<ul>';
echo '<li>❌ SERP не запускається вручну</li>';
echo '<li>🧠 OpenAI (стратег) вирішує, коли потрібен SERP-аналіз</li>';
echo '<li>📊 Дані використовуються для порівняння з конкурентами</li>';
echo '<li>⚠️ Жодних змін без підтвердження</li>';
echo '</ul>';

echo '</div>';