<?php
declare(strict_types=1);

namespace SEOJusAI\Admin\Pages;

use SEOJusAI\PageSpeed\PageSpeedClient;
use SEOJusAI\Input\Input;

defined('ABSPATH') || exit;

if (!current_user_can('manage_options')) {
	return;
}

$url = (Input::get('url', null) !== null) ? esc_url_raw((string) Input::get('url')) : home_url('/');
$strategy = (Input::get('strategy', null) !== null) ? sanitize_key((string) Input::get('strategy')) : 'mobile';
$strategy = ($strategy === 'desktop') ? 'desktop' : 'mobile';

echo '<div class="wrap">';
echo '<h1>' . esc_html__('Швидкість та показники сторінок', 'seojusai') . '</h1>';

echo '<form method="get" style="margin:12px 0;">';
echo '<input type="hidden" name="page" value="seojusai-pagespeed" />';
echo '<table class="form-table"><tr>';
echo '<th style="width:140px;">URL</th>';
echo '<td><input class="regular-text" type="text" name="url" value="' . esc_attr($url) . '" /></td>';
echo '</tr><tr>';
echo '<th>Стратегія</th><td>';
echo '<select name="strategy">';
echo '<option value="mobile"' . selected($strategy, 'mobile', false) . '>mobile</option>';
echo '<option value="desktop"' . selected($strategy, 'desktop', false) . '>desktop</option>';
echo '</select>';
echo '</td></tr></table>';
echo '<p><button class="button button-primary">' . esc_html__('Запустити перевірку', 'seojusai') . '</button></p>';
echo '</form>';

/* ================= CLIENT ================= */

$client = new PageSpeedClient();
$key = $client->get_api_key();
$masked = ($key !== '') ? ('…' . substr($key, -6)) : '—';

echo '<p><strong>Key loaded:</strong> ' . esc_html($masked) . '</p>';

/* ================= ANALYZE ================= */

$res = $client->analyze($url, $strategy);

if (!$res['ok']) {
	echo '<div class="notice notice-error"><p><strong>' . esc_html__('Запит до PageSpeed API не вдався.', 'seojusai') . '</strong></p>';
	echo '<p><strong>HTTP:</strong> ' . esc_html((string) $res['code']) . '</p>';
	echo '<p><strong>Details:</strong> ' . esc_html($res['error']) . '</p>';
	echo '<p style="margin-top:10px;"><strong>ДІАГНОЗ:</strong><br>'
		. '1) Якщо HTTP 403 → ключ обмежений або API не увімкнено.<br>'
		. '2) Якщо HTTP 400 → неправильний URL або strategy.<br>'
		. '3) Якщо HTTP 0 → блокуються вихідні запити або DNS.'
		. '</p>';
	echo '</div>';
	echo '</div>';
	return;
}

$data = $res['data'];

$perf = $data['lighthouseResult']['categories']['performance']['score'] ?? null;
$perf = is_numeric($perf) ? (int) round(((float) $perf) * 100) : null;

echo '<div class="notice notice-success"><p>✅ OK. Performance: <strong>' . esc_html((string) ($perf ?? '—')) . '</strong></p></div>';

echo '</div>';