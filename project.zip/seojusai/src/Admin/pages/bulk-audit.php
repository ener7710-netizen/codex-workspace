<?php
declare(strict_types=1);

use SEOJusAI\Capabilities\CapabilityGuard;
use SEOJusAI\Safety\SafeMode;
use SEOJusAI\Core\I18n;

defined('ABSPATH') || exit;

$can = CapabilityGuard::can('seojusai_run_analysis');
if (!$can) {
    echo '<div class="wrap"><h1><?php echo esc_html__('Масові операції: Аудит', 'seojusai'); ?></h1>
<p class="seojusai-muted"><?php echo esc_html__('Запуск масового аудиту вибраних записів з безпечними обмеженнями.', 'seojusai'); ?></p><p>'.esc_html(I18n::t('Недостатньо прав доступу.')).'</p></div>';
    return;
}

wp_enqueue_style('seojusai-bulk', SEOJUSAI_URL . 'assets/css/bulk.css', [], '1.0.0');
wp_enqueue_script('seojusai-bulk', SEOJUSAI_URL . 'assets/js/bulk.js', ['wp-api-fetch'], '1.0.0', true);
wp_add_inline_script('seojusai-bulk', 'window.SEOJusAIГрупова обробка = ' . wp_json_encode([
    'mode' => 'audit',
    'nonce' => wp_create_nonce('wp_rest'),
    'restUrl' => esc_url_raw(rest_url('seojusai/v1')),
    'safeMode' => SafeMode::is_active(),
]) . ';', 'before');

?>
<div class="wrap seojusai-bulk">
    <h1><?php echo esc_html__('Масові операції: Аудит', 'seojusai'); ?></h1>
<p class="seojusai-muted"><?php echo esc_html__('Запуск масового аудиту вибраних записів з безпечними обмеженнями.', 'seojusai'); ?></p>

    <?php if (false && SafeMode::is_active()): ?>
        <div class="notice notice-warning"><p><strong><?php echo esc_html__('Увімкнено Безпечний режим.', 'seojusai'); ?></strong> <?php echo esc_html__('Застосування/відкат заблоковано, доки Безпечний режим активний.', 'seojusai'); ?></p></div>
    <?php endif; ?>

    <div class="card">
        <h2><?php echo esc_html__('Фільтри', 'seojusai'); ?></h2>
        <p><?php echo esc_html__('Оберіть типи контенту та ліміт. Операція виконується у фоні через чергу задач.', 'seojusai'); ?></p>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><?php echo esc_html__('Типи записів', 'seojusai'); ?></th>
                <td>
                    <label><input type="checkbox" class="seojusai-bulk-posttype" value="post" checked> post</label>
                    <label style="margin-left:12px;"><input type="checkbox" class="seojusai-bulk-posttype" value="page" checked> page</label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php echo esc_html__('Статуси', 'seojusai'); ?></th>
                <td>
                    <label><input type="checkbox" class="seojusai-bulk-status" value="publish" checked> publish</label>
                    <label style="margin-left:12px;"><input type="checkbox" class="seojusai-bulk-status" value="private"> private</label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php echo esc_html__('Ліміт URL', 'seojusai'); ?></th>
                <td><input type="number" class="small-text seojusai-bulk-limit" value="200" min="1" max="2000"></td>
            </tr>
        </table>

        <p>
            <button class="button button-primary seojusai-bulk-start" data-mode="audit">
                <?php echo esc_html__('Запустити', 'seojusai'); ?>
            </button>
            <span class="seojusai-bulk-start-hint"></span>
        </p>
    </div>

    <h2><?php echo esc_html__('Останні Групова обробка-задачі', 'seojusai'); ?></h2>
    <div class="seojusai-bulk-jobs"></div>
</div>