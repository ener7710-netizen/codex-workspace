<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

use SEOJusAI\Safety\SafeMode;

if (!current_user_can('manage_options')) return;

$safe_mode = SafeMode::is_enabled();

$has_reality_boundary = class_exists('SEOJusAI\\Врядування\\RealityBoundary');
$has_rest_kernel      = class_exists('SEOJusAI\\Core\\RestKernel') || class_exists('SEOJusAI\\Core\\RestKernel'); // compat
$has_explain          = class_exists('SEOJusAI\\Explain\\ExplainService') || class_exists('SEOJusAI\\Explain\\ExplainRepository') || class_exists('SEOJusAI\\Explain\\ExplanationRepository');
$has_conflicts        = file_exists(__DIR__ . '/conflicts.php');

function seojusai_badge(bool $ok, string $okText, string $badText): string {
	$txt = $ok ? $okText : $badText;
	$cls = $ok ? 'seojusai-badge seojusai-badge-ok' : 'seojusai-badge seojusai-badge-bad';
	return '<span class="' . esc_attr($cls) . '">' . esc_html($txt) . '</span>';
}

?>
<div class="wrap seojusai-wrap">
	<h1><?php echo esc_html__('AI Врядування', 'seojusai'); ?></h1>

	<div class="seojusai-cards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;">
		<div class="seojusai-card" style="background:#fff;border:1px solid #e5e5e5;border-radius:12px;padding:16px;">
			<h2 style="margin-top:0;"><?php echo esc_html__('Статус захисту', 'seojusai'); ?></h2>
			<p style="margin:0 0 8px 0;">
				<?php echo seojusai_badge($has_reality_boundary, __('Межа реальності: активний', 'seojusai'), __('Межа реальності: відсутній', 'seojusai')); ?>
			</p>
			<p style="margin:0 0 8px 0;">
				<?php echo seojusai_badge($safe_mode, __('Безпечний режим: увімкнено', 'seojusai'), __('Безпечний режим: вимкнено', 'seojusai')); ?>
			</p>
			<p style="margin:0 0 8px 0;">
				<?php echo seojusai_badge($has_explain, __('Explain: доступно', 'seojusai'), __('Explain: відсутнє', 'seojusai')); ?>
			</p>
			<p style="margin:0;">
				<?php echo seojusai_badge($has_conflicts, __('Центр конфліктів: доступно', 'seojusai'), __('Центр конфліктів: відсутнє', 'seojusai')); ?>
			</p>

			<div style="margin-top:12px;font-size:13px;color:#555;">
				<?php echo esc_html__('Безпека важливіша за швидкість: система блокує будь-які дії без джерела «реальності» (SERP/Gemini/Google).', 'seojusai'); ?>
			</div>
		</div>

		<div class="seojusai-card" style="background:#fff;border:1px solid #e5e5e5;border-radius:12px;padding:16px;">
			<h2 style="margin-top:0;"><?php echo esc_html__('Інваріанти системи (не налаштовуються)', 'seojusai'); ?></h2>
			<ul style="margin:0 0 10px 18px;">
				<li><?php echo esc_html__('Жодних ручних URL конкурентів / правил ринку.', 'seojusai'); ?></li>
				<li><?php echo esc_html__('«Реальність» надходить лише з SERP, Google даних та аналізу Gemini.', 'seojusai'); ?></li>
				<li><?php echo esc_html__('OpenAI формує стратегію, рішення та пояснення (Explain).', 'seojusai'); ?></li>
				<li><?php echo esc_html__('Без Explain/Джерело/Confidence/Risk — застосування заборонено.', 'seojusai'); ?></li>
				<li><?php echo esc_html__('Людина лише затверджує або зупиняє дії (Human‑in‑the‑Loop).', 'seojusai'); ?></li>
			</ul>
			<p style="margin:0;font-size:13px;color:#555;">
				<?php echo esc_html__('Ці правила захищають від деградації плагіна у «налаштовуваний SEO‑конструктор».', 'seojusai'); ?>
			</p>
		</div>

		<div class="seojusai-card" style="background:#fff;border:1px solid #e5e5e5;border-radius:12px;padding:16px;">
			<h2 style="margin-top:0;"><?php echo esc_html__('Шлях до продакшену (рекомендовано)', 'seojusai'); ?></h2>
			<ol style="margin:0 0 10px 18px;">
				<li><?php echo esc_html__('Огляд сигналів: Explain + Conflicts.', 'seojusai'); ?></li>
				<li><?php echo esc_html__('Редактор: Inline Suggestions (low‑risk).', 'seojusai'); ?></li>
				<li><?php echo esc_html__('Групова обробка: Застосувати only low‑risk через Job Summary.', 'seojusai'); ?></li>
				<li><?php echo esc_html__('Autopilot SAFE: 1% → 5% → 25% (лише після стабільності).', 'seojusai'); ?></li>
			</ol>

			<p style="margin:0;">
				<a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=seojusai-explain-director')); ?>">
					<?php echo esc_html__('Відкрити Центр пояснень', 'seojusai'); ?>
				</a>
				<a class="button" style="margin-left:8px;" href="<?php echo esc_url(admin_url('admin.php?page=seojusai-conflicts')); ?>">
					<?php echo esc_html__('Перевірити конфлікти', 'seojusai'); ?>
				</a>
			</p>
		</div>

		<div class="seojusai-card" style="background:#fff;border:1px solid #e5e5e5;border-radius:12px;padding:16px;">
			<h2 style="margin-top:0;"><?php echo esc_html__('Політика для відвідувачів сайту (шаблон)', 'seojusai'); ?></h2>
			<p style="font-size:13px;color:#444;line-height:1.5;margin-top:0;">
				<strong><?php echo esc_html__('Як працює AI на цьому сайті', 'seojusai'); ?></strong><br>
				<?php echo esc_html__('Ми використовуємо AI для аналізу структури та контенту сайту на основі відкритих даних пошуку (SERP) та сервісів Google, а також внутрішніх даних сайту. AI надає рекомендації та пояснює причини. Важливі зміни виконуються лише після підтвердження людиною. Ми не надаємо гарантій результатів і не використовуємо маніпулятивні заклики.', 'seojusai'); ?>
			</p>
			<p style="margin:0;font-size:13px;color:#555;">
				<?php echo esc_html__('Рекомендуємо опублікувати цей текст на окремій сторінці «Політика AI».', 'seojusai'); ?>
			</p>
		</div>
	</div>
</div>
