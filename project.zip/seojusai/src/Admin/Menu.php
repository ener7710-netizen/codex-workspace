<?php
declare(strict_types=1);

namespace SEOJusAI\Admin;

use SEOJusAI\Admin\Tasks\TasksPage;

defined('ABSPATH') || exit;

final class Menu {

	public function __construct() {
		add_action('admin_menu', [$this, 'register_menu']);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
	}

	public function register_menu(): void {
		$icon = 'dashicons-chart-area';

		add_menu_page(
			'SEOJusAI',
			'SEOJusAI',
			'manage_options',
			'seojusai',
			[$this, 'render_dashboard'],
			$icon,
			30
		);

		add_submenu_page(
			'seojusai',
			__('Панель', 'seojusai'),
			__('Панель', 'seojusai'),
			'manage_options',
			'seojusai',
			[$this, 'render_dashboard']
		);


		// Page analysis inspector is intentionally NOT exposed as a standalone menu page.
		// UX: analysis lives in Posts/Pages list table (counter column) and in Gutenberg sidebar.

		add_submenu_page(
	'seojusai',
	__('AI Врядування', 'seojusai'),
	__('Врядування', 'seojusai'),
	'manage_options',
	'seojusai-governance',
	[$this, 'render_governance']
);

add_submenu_page(
	'seojusai',
	__('Конфлікти', 'seojusai'),
	__('Конфлікти', 'seojusai'),
	'manage_options',
	'seojusai-conflicts',
	[$this, 'render_conflicts']
);

		
add_submenu_page(
	'seojusai',
	'AI → Конверсії',
	'AI → Конверсії',
	'manage_options',
	'seojusai-ai-conversions',
	[$this, 'render_ai_conversions']
);


add_submenu_page(
	'seojusai',
	'Рішення та результати',
	'Рішення → Результат',
	'manage_options',
	'seojusai-decisions',
	[$this, 'render_decisions']
);

add_submenu_page(
	'seojusai',
	__('Лід-фанел', 'seojusai'),
	__('Лід-фанел', 'seojusai'),
	'manage_options',
	'seojusai-lead-funnel',
	[$this, 'render_lead_funnel']
);

add_submenu_page(
	'seojusai',
	__('Ринкові сигнали', 'seojusai'),
	__('Ринкові сигнали', 'seojusai'),
	'manage_options',
	'seojusai-market-signals',
	[$this, 'render_market_signals']
);

add_submenu_page(
	'seojusai',
	__('Експерименти (A/B)', 'seojusai'),
	__('Експерименти', 'seojusai'),
	'manage_options',
	'seojusai-experiments',
	[$this, 'render_experiments']
);


add_submenu_page(
			'seojusai',
			'AI та Дані',
			'AI та Дані',
			'manage_options',
			'seojusai-ai',
			[$this, 'render_ai_settings']
		);

		add_submenu_page(
			'seojusai',
			'Модулі',
			'Модулі',
			'manage_options',
			'seojusai-modules',
			[$this, 'render_modules']
		);

		/**
		 * ✅ НОВЕ: Задачі AI / Autopilot
		 */
		add_submenu_page(
			'seojusai',
			'Завдання',
			'Завдання',
			'manage_options',
			'seojusai-tasks',
			[$this, 'render_tasks']
		);


		add_submenu_page(
			'seojusai',
			__('Пріоритети SEO', 'seojusai'),
			__('Пріоритети SEO', 'seojusai'),
			'manage_options',
			'seojusai-opportunity',
			[$this, 'render_opportunity']
		);

		add_submenu_page(
			'seojusai',
			__('Мапа сайту', 'seojusai'),
			__('Мапа сайту', 'seojusai'),
			'manage_options',
			'seojusai-sitemap',
			[$this, 'render_sitemap']
		);

// ✅ Масові операції (Групова обробка)
add_submenu_page(
    'seojusai',
    __('Масові операції', 'seojusai'),
    __('Масові операції', 'seojusai'),
    'manage_options',
    'seojusai-bulk-audit',
    [ $this, 'render_bulk_audit' ]
);

add_submenu_page(
    'seojusai',
    __('Групова обробка: Застосування', 'seojusai'),
    __('Групова обробка: Застосування', 'seojusai'),
    'manage_options',
    'seojusai-bulk-apply',
    [ $this, 'render_bulk_apply' ]
);

add_submenu_page(
    'seojusai',
    __('Групова обробка: Відкат', 'seojusai'),
    __('Групова обробка: Відкат', 'seojusai'),
    'manage_options',
    'seojusai-bulk-rollback',
    [ $this, 'render_bulk_rollback' ]
);


		add_submenu_page(
			'seojusai',
			__('Редиректи та 404', 'seojusai'),
			__('Редиректи', 'seojusai'),
			'manage_options',
			'seojusai-redirects',
			[$this, 'render_redirects']
		);

	}


	/* ==========================================================
	 * RENDERERS
	 * ========================================================== */

	public function render_dashboard(): void {
		$this->safe_require('Admin/pages/dashboard.php');
	}

	public function render_decisions(): void {
		$this->safe_require('Admin/pages/decisions.php');
	}

	public function render_ai_conversions(): void {
		$this->safe_require('Admin/pages/ai-conversions.php');
	}

	public function render_ai_settings(): void {
		$this->safe_require('Admin/pages/ai-settings.php');
	}

	public function render_lead_funnel(): void {
		$this->safe_require('Admin/pages/lead-funnel.php');
	}

	public function render_governance(): void {
		$this->safe_require('Admin/pages/governance.php');
	}

	public function render_conflicts(): void {
		$this->safe_require('Admin/pages/conflicts.php');
	}

	public function render_market_signals(): void {
		$this->safe_require('Admin/pages/market-signals.php');
	}

	public function render_experiments(): void {
		$this->safe_require('Admin/pages/experiments.php');
	}

	public function render_bulk_audit(): void {
		$this->safe_require('Admin/pages/bulk-audit.php');
	}

	public function render_bulk_apply(): void {
		$this->safe_require('Admin/pages/bulk-apply.php');
	}

	public function render_bulk_rollback(): void {
		$this->safe_require('Admin/pages/bulk-rollback.php');
	}

	public function render_modules(): void {
		$this->safe_require('Admin/pages/modules.php');
	}

	public function render_tasks(): void {
		if (class_exists(TasksPage::class)) {
			(new TasksPage())->render();
			return;
		}

		echo '<div class="notice notice-error"><p>';
		echo esc_html__('SEOJusAI: Модуль задач не завантажено.', 'seojusai');
		echo '</p></div>';
	}

	/* ==========================================================
	 * HELPERS
	 * ========================================================== */

	

	public function render_opportunity(): void {
		$this->safe_require('Admin/pages/opportunity.php');
	}

	public function render_sitemap(): void {
		$this->safe_require('Admin/pages/sitemap.php');
	}

	public function render_redirects(): void {
		$this->safe_require('Admin/pages/redirects.php');
	}

private function safe_require(string $relative_path): void {
		// Використовуємо константу SEOJUSAI_INC, яку ми визначили в головному файлі
		$file = defined('SEOJUSAI_INC')
			? SEOJUSAI_INC . $relative_path
			: plugin_dir_path(__DIR__) . $relative_path;

		if (file_exists($file) && is_readable($file)) {
			require_once $file;
		} else {
			echo '<div class="notice notice-error"><p>';
			echo esc_html__('Помилка: Файл не знайдено за шляхом: ', 'seojusai');
			echo esc_html($file);
			echo '</p></div>';
		}
	}

	// render_page_analysis removed: page analysis is shown in list-table badge and editor sidebar.

	public function enqueue_assets(string $hook): void {
		// Підключаємо стилі лише на сторінках плагіна.
		if (strpos($hook, 'seojusai') === false) { return; }
		$ver = defined('SEOJUSAI_VERSION') ? SEOJUSAI_VERSION : '1.0.0';
				wp_enqueue_style('seojusai-admin', plugins_url('assets/admin/admin-ui.css', SEOJUSAI_FILE), [], $ver);
	}
}
