<?php
declare(strict_types=1);

namespace SEOJusAI\Admin\Tasks;

use WP_List_Table;

defined('ABSPATH') || exit;

if ( ! class_exists(WP_List_Table::class) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

final class TaskListTable extends WP_List_Table {

	public function prepare_items(): void {

		$tasks = get_option('seojusai_tasks', []);
		if ( ! is_array($tasks) ) {
			$tasks = [];
		}

		$this->items = $tasks;

		$this->_column_headers = [
			$this->get_columns(),
			[],
			[],
		];
	}

	public function get_columns(): array {
		return [
			'cb'        => '<input type="checkbox" />',
			'action'    => __('Дія', 'seojusai'),
			'post_id'   => __('ID запису', 'seojusai'),
			'status'    => __('Статус', 'seojusai'),
			'source'    => __('Джерело', 'seojusai'),
			'created'   => __('Створено', 'seojusai'),
		];
	}

	protected function column_cb($item): string {
		return sprintf(
			'<input type="checkbox" name="task_ids[]" value="%s" />',
			esc_attr($item['decision_hash'] ?? '')
		);
	}

	protected function column_action($item): string {
		return esc_html($item['action'] ?? '');
	}

	protected function column_post_id($item): string {
		return (string) ((int) ($item['post_id'] ?? 0));
	}

	protected function column_status($item): string {
		$status = (string) ($item['status'] ?? 'unknown');

		$map = [
			'pending'  => '🟡 pending',
			'approved' => '🔵 approved',
			'applied'  => '🟢 applied',
			'failed'   => '🔴 failed',
		];

		return esc_html($map[$status] ?? $status);
	}

	protected function column_source($item): string {
		return esc_html($item['source'] ?? '');
	}

	protected function column_created($item): string {
		$ts = (int) ($item['created_at'] ?? 0);
		return $ts > 0 ? date('Y-m-d H:i', $ts) : '-';
	}

	protected function get_bulk_actions(): array {
		return [
			'approve' => __('Approve', 'seojusai'),
			'apply'   => __('Застосувати', 'seojusai'),
			'delete'  => __('Delete', 'seojusai'),
		];
	}
}