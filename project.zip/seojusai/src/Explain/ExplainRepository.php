<?php
declare(strict_types=1);

namespace SEOJusAI\Explain;

use wpdb;

defined('ABSPATH') || exit;

/**
 * ExplainRepository
 *
 * ЄДИНЕ джерело істини для запису/читання AI-пояснень та трасування рішень.
 * Таблиця: {$wpdb->prefix}seojusai_explanations
 */
final class ExplainRepository {

	private string $table;
	private wpdb $db;

	public function __construct(?wpdb $db = null) {
		global $wpdb;
		$this->db = $db instanceof wpdb ? $db : $wpdb;
		$this->table = $this->db->prefix . 'seojusai_explanations';
	}

	/**
	 * @param array<string,mixed> $explanation_struct
	 */
	public function save(
		string $entity_type,
		int $entity_id,
		string $decision_hash,
		array $explanation_struct,
		string $risk = 'low',
		string $source = 'ai',
		?string $model = null,
		?string $prompt = null,
		?string $response = null,
		int $tokens = 0
	): bool {
		$entity_type = sanitize_key($entity_type);
		$entity_id   = max(0, (int) $entity_id);
		$decision_hash = sanitize_text_field($decision_hash);

		if ($entity_type === '' || $entity_id < 0) {
			return false;
		}

		$explanation_json = wp_json_encode($explanation_struct, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		if ($explanation_json === false) {
			$explanation_json = null;
		}

		$data = [
			'entity_type'   => $entity_type,
			'entity_id'     => $entity_id,
			'decision_hash' => $decision_hash,
			'model'         => $model ? sanitize_text_field($model) : null,
			'prompt'        => is_string($prompt) ? $prompt : null,
			'response'      => is_string($response) ? $response : null,
			'explanation'   => $explanation_json,
			'risk_level'    => sanitize_key($risk ?: 'low'),
			'source'        => sanitize_key($source ?: 'ai'),
			'tokens'        => max(0, (int) $tokens),
			'created_at'    => current_time('mysql', true),
		];

		$formats = ['%s','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s'];

		$res = $this->db->insert($this->table, $data, $formats);

		if ($res !== 1) {
			do_action('seojusai/explain/db_error', [
				'error' => $this->db->last_error,
				'table' => $this->table,
			]);
		}

		return $res === 1;
	}

	/** @return array<int,array<string,mixed>> */
	public function list(string $entity_type, int $entity_id, int $limit = 10): array {
		$entity_type = sanitize_key($entity_type);
		$entity_id   = max(0, (int) $entity_id);
		$limit       = max(1, min(50, (int) $limit));

		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT * FROM {$this->table}
				 WHERE entity_type = %s AND entity_id = %d
				 ORDER BY id DESC LIMIT %d",
				$entity_type,
				$entity_id,
				$limit
			),
			ARRAY_A
		);

		if (!$rows) {
			return [];
		}

		foreach ($rows as &$r) {
			$r['tokens'] = (int) ($r['tokens'] ?? 0);
			$r['explanation'] = isset($r['explanation']) && is_string($r['explanation']) && $r['explanation'] !== ''
				? json_decode((string) $r['explanation'], true)
				: null;
			if (!is_array($r['explanation'])) {
				$r['explanation'] = null;
			}
		}

		return $rows;
	}
}
