<?php
declare(strict_types=1);

namespace SEOJusAI\Governance;

use WP_REST_Request;
use WP_REST_Response;

defined('ABSPATH') || exit;

/**
 * RealityBoundary
 *
 * Канон: реальність (конкуренти/ринок/SERP-контекст) приходить ЛИШЕ з SERP/Gemini/Google.
 * Будь-які ручні "market inputs" заборонені на рівні ядра, незалежно від UI.
 */
final class RealityBoundary {

    /**
     * Keys that indicate manual market input. We block them for all /seojusai/v1 routes.
     * @var string[]
     */
    private static array $forbiddenKeys = [
        'competitors',
        'competitor',
        'competitor_urls',
        'competitor_url',
        'competitorDomains',
        'competitor_domains',
        'manual_competitors',
        'manualCompetitors',
        'market_rules',
        'marketRules',
        'market_inputs',
        'marketInputs',
        'serp_manual',
        'manual_serp',
        'seed_keywords',
        'seedKeywords',
        'manual_urls',
        'manualUrls',
    ];

    /**
     * @param mixed $result
     * @return mixed
     */
    public static function guard($result, $server, $request) {
        $route = is_object($request) && method_exists($request, 'get_route') ? (string) $request->get_route() : '';
        if ($route === '' || strpos($route, '/seojusai/v1') !== 0) {
            return $result;
        }

        if (!is_object($request) || !($request instanceof WP_REST_Request)) {
            return $result;
        }

        $method = strtoupper((string) $request->get_method());
        if (!in_array($method, ['POST','PUT','PATCH'], true)) {
            return $result;
        }

        // Inspect body JSON only (we don't care about normal settings like serp endpoint here)
        $raw = (string) $request->get_body();
        if ($raw === '') {
            return $result;
        }

        // Cheap JSON decode (payload size is already limited in RestKernel guard_payload).
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return $result;
        }

        if (self::containsForbiddenKey($data)) {
            return new WP_REST_Response([
                'success' => false,
                'error'   => 'Manual market input is forbidden. Use SERP/Gemini sources only.',
                'code'    => 'manual_input_forbidden',
            ], 400);
        }

        return $result;
    }

    /**
     * @param array<mixed> $data
     */
    private static function containsForbiddenKey(array $data): bool {
        $stack = [$data];
        while ($stack) {
            $cur = array_pop($stack);
            if (!is_array($cur)) continue;

            foreach ($cur as $k => $v) {
                if (is_string($k)) {
                    foreach (self::$forbiddenKeys as $bad) {
                        if (strcasecmp($k, $bad) === 0) {
                            return true;
                        }
                    }
                }
                if (is_array($v)) {
                    $stack[] = $v;
                }
            }
        }
        return false;
    }
}
