<?php
declare(strict_types=1);

namespace SEOJusAI\Editor;
use SEOJusAI\Input\Input;

defined('ABSPATH') || exit;

/**
 * EditorSidebar
 *
 * ЄДИНА задача:
 * - підключити assets/js/sidebar.js у Gutenberg
 * - передати nonce та базові дані
 *
 * ❌ НЕ містить inline JS
 * ❌ НЕ реєструє PluginSidebar
 * ❌ НЕ викликає registerPlugin
 *
 * Вся логіка sidebar — ТІЛЬКИ в assets/js/sidebar.js
 */
final class EditorSidebar {

	/**
	 * Реєстрація хуків
	 */
	public function register(): void {
		add_action('enqueue_block_editor_assets', [$this, 'enqueue']);
	}

	/**
	 * Підключення sidebar-скрипта
	 */
	public function enqueue(): void {

		wp_enqueue_script(
			'seojusai-editor-sidebar',
			SEOJUSAI_URL . 'assets/js/sidebar.js',
			[
				'wp-plugins',
				'wp-edit-post',
				'wp-element',
				'wp-components',
				'wp-data',
				'wp-api-fetch',
			],
			defined('SEOJUSAI_VERSION') ? SEOJUSAI_VERSION : '1.0.0',
			true
		);

		// Визначення post ID максимально надійно
		$post_id = 0;
		if ((Input::get('post', null) !== null)) {
			$post_id = (int) Input::get('post');
		} elseif ((Input::post('post_ID', null) !== null)) {
			$post_id = (int) Input::post('post_ID');
		}

		wp_localize_script(
			'seojusai-editor-sidebar',
			'SEOJusAIEditor',
			[
				'nonce'   => wp_create_nonce('wp_rest'),
				'postId'  => $post_id,
				'restUrl' => get_rest_url(null, 'seojusai/v1'),
			]
		);
	}
}