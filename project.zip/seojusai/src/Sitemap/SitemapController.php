<?php
declare(strict_types=1);

namespace SEOJusAI\Sitemap;

use SEOJusAI\Compat\SeoEnvironmentDetector;

defined('ABSPATH') || exit;

/**
 * SitemapController (WP Core sitemaps)
 *
 * 2026 правило:
 * - НЕ реєструємо власні sitemap_index.xml URL (конфлікт з Yoast/RankMath)
 * - Використовуємо WP Core sitemaps API та фільтри
 */
final class SitemapController {

	public function register(): void {
		// Якщо активний інший SEO-плагін — не втручаємось
		if (SeoEnvironmentDetector::is_any_seo_active()) {
			return;
		}

		// Фільтр: виключаємо noindex записи з core sitemap
		add_filter('wp_sitemaps_posts_query_args', [$this, 'filter_posts_query'], 10, 2);

		// Фільтр: можна змінити entry (напр., lastmod), але core і так це робить.
	}

	/**
	 * @param array<string,mixed> $args
	 * @param string $post_type
	 * @return array<string,mixed>
	 */
	public function filter_posts_query(array $args, string $post_type): array {
		// Виключаємо контент, який SEOJusAI позначив як noindex
		$args['meta_query'] = $args['meta_query'] ?? [];
		$args['meta_query'][] = [
			'relation' => 'OR',
			[
				'key'     => '_seojusai_robots',
				'compare' => 'NOT EXISTS',
			],
			[
				'key'     => '_seojusai_robots',
				'value'   => 'noindex',
				'compare' => 'NOT LIKE',
			],
		];
		return $args;
	}
}
