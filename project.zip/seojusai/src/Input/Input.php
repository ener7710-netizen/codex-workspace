<?php
declare(strict_types=1);

namespace SEOJusAI\Input;

defined('ABSPATH') || exit;

/**
 * Input (2026)
 * Єдина точка валідації/нормалізації вхідних даних.
 */
final class Input {

    public static function int($v, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int {
        $i = is_numeric($v) ? (int)$v : 0;
        if ($i < $min) $i = $min;
        if ($i > $max) $i = $max;
        return $i;
    }

    public static function bool($v): bool {
        return filter_var($v, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) ?? (bool)$v;
    }

    /** @param string[] $allowed */
    public static function enum($v, array $allowed, string $default = ''): string {
        $s = is_string($v) ? $v : (string)$v;
        $s = sanitize_key($s);
        if (in_array($s, $allowed, true)) return $s;
        return $default !== '' ? $default : (string)($allowed[0] ?? '');
    }

    public static function string($v, int $maxLen = 255, bool $key = false): string {
        $s = is_string($v) ? $v : (string)$v;
        $s = $key ? sanitize_key($s) : sanitize_text_field($s);
        if ($maxLen > 0) $s = substr($s, 0, $maxLen);
        return $s;
    }

    /**
     * @return array<string,mixed>
     */
    public static function json_array($raw, int $maxBytes = 524288): array {
        if (is_array($raw)) return $raw;
        $s = is_string($raw) ? $raw : '';
        if ($s === '') return [];
        if (strlen($s) > $maxBytes) return [];
        $d = json_decode($s, true);
        return is_array($d) ? $d : [];
    }

/**
 * Strict JSON array parse with size limit.
 *
 * @return array{ok:bool,data:array<string,mixed>,error:string}
 */
public static function json_array_strict($raw, int $maxBytes = 524288): array {
    $s = is_string($raw) ? $raw : '';
    if ($s === '') {
        return ['ok' => false, 'data' => [], 'error' => 'empty_json'];
    }
    if (strlen($s) > $maxBytes) {
        return ['ok' => false, 'data' => [], 'error' => 'payload_too_large'];
    }
    $d = json_decode($s, true);
    if (!is_array($d)) {
        return ['ok' => false, 'data' => [], 'error' => 'invalid_json'];
    }
    return ['ok' => true, 'data' => $d, 'error' => ''];
}

    /**
     * POST helpers (avoid direct superglobals usage outside Input)
     */
    public static function post(string $key, $default = null) {
        $key = (string) $key;
        if ($key === '') return $default;
        $src = isset($_POST) && is_array($_POST) ? wp_unslash($_POST) : [];
        return $src[$key] ?? $default;
    }

    public static function post_string(string $key, int $maxLen = 255): string {
        return self::string(self::post($key, ''), $maxLen, false);
    }

    public static function post_int(string $key, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int {
        return self::int(self::post($key, 0), $min, $max);
    }

    /**
     * GET helpers
     */
    public static function get(string $key, $default = null) {
        $key = (string) $key;
        if ($key === '') return $default;
        $src = isset($_GET) && is_array($_GET) ? wp_unslash($_GET) : [];
        return $src[$key] ?? $default;
    }

    public static function get_string(string $key, int $maxLen = 255): string {
        return self::string(self::get($key, ''), $maxLen, false);
    }

    public static function get_int(string $key, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int {
        return self::int(self::get($key, 0), $min, $max);
    }

    /**
     * REST nonce extraction (X-WP-Nonce)
     */
    public static function rest_nonce($req = null): string {
        $nonce = '';
        if (is_object($req) && method_exists($req, 'get_header')) {
            $nonce = (string) $req->get_header('X-WP-Nonce');
        }
        if ($nonce === '' && isset($_SERVER['HTTP_X_WP_NONCE'])) {
            $nonce = (string) $_SERVER['HTTP_X_WP_NONCE'];
        }
        return $nonce;
    }

}
