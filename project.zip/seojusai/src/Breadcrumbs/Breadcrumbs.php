<?php
declare(strict_types=1);

namespace SEOJusAI\Breadcrumbs;

defined('ABSPATH') || exit;

final class Breadcrumbs {

	public function register(): void {
		add_shortcode('seojusai_breadcrumbs', [$this, 'shortcode']);
	}

	public function shortcode(array $atts = []): string {
		if (!is_singular() && !is_page() && !is_single()) {
			return '';
		}
		$enabled = (string) get_option('seojusai_breadcrumbs_enabled', '0');
		if ($enabled !== '1') { return ''; }

		$trail = $this->build_trail();
		$trail = apply_filters('seojusai/breadcrumbs/trail', $trail);

		if (empty($trail)) { return ''; }

		$parts = [];
		foreach ($trail as $t) {
			$title = esc_html((string) ($t['title'] ?? ''));
			$url = (string) ($t['url'] ?? '');
			if ($url !== '') {
				$parts[] = '<a href="' . esc_url($url) . '">' . $title . '</a>';
			} else {
				$parts[] = '<span class="seojusai-bc-current">' . $title . '</span>';
			}
		}
		return '<nav class="seojusai-breadcrumbs" aria-label="breadcrumbs">' . implode(' &raquo; ', $parts) . '</nav>';
	}

	/** @return array<int,array{title:string,url:string}> */
	private function build_trail(): array {
		$trail = [];
		$trail[] = ['title' => __('Головна', 'seojusai'), 'url' => home_url('/')];

		$post = get_queried_object();
		if (!$post || empty($post->ID)) {
			return $trail;
		}

		$parents = [];
		$pid = (int) $post->post_parent;
		while ($pidpid = $pid) {
			$p = get_post($pid);
			if (!$p) { break; }
			$parents[] = ['title' => get_the_title($pid), 'url' => get_permalink($pid)];
			$pid = (int) $p->post_parent;
			if ($pid === 0) { break; }
		}
		$parents = array_reverse($parents);
		foreach ($parents as $p) { $trail[] = $p; }

		$trail[] = ['title' => get_the_title((int)$post->ID), 'url' => ''];

		return $trail;
	}
}
