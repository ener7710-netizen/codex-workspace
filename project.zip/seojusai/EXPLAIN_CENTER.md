# SEOJusAI — Explain Center (Director-grade)

Адмінка: SEOJusAI → Explain

Вкладки:
- Огляд: агрегати за 30 днів (by risk, avg confidence)
- Історія: фільтри risk/entity_type/decision_hash
- Diff: порівняння двох записів Explain (A/B) + простий line-diff JSON

Зберігання:
- {$wpdb->prefix}seojusai_explanations
- Додано колонку confidence (0..1)

