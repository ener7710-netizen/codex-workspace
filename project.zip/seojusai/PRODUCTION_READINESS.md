# SEOJusAI — Production Readiness (2026)

## Мінімальні умови продакшену
- WordPress 6.4+ (рекомендовано 6.9)
- PHP 8.2+
- HTTPS
- WP_DEBUG = false (але логування помилок сервера увімкнене)

## Безпека
- Усі REST виклики в адмінці повинні передавати `X-WP-Nonce` (wp_rest).
- Ключі API та GSC JSON зберігаються через `SecretsVault` (encrypted options).
- Redirects використовують лише safe-redirect (host restricted).

## Сумісність
- При активному Yoast/RankMath/AIOSEO/SEOPress: frontend-emitting модулі SEOJusAI автоматично не ініціалізуються (щоб уникнути дублювання).

## Фонові задачі
- Якщо доступний Action Scheduler — використовується він.
- Інакше — fallback на WP-Cron.

## Оновлення БД
- Таблиці створюються через dbDelta у `SEOJusAI\Database\Tables`.
- Після оновлення — рекомендується один раз відвідати адмінку та зберегти налаштування (щоб прогріти кеш).



## Safe Mode & Approvals (2026)
- Safe Mode blocks apply/redirects/schema writes via option `seojusai_safe_mode`.
- Approvals are stored as transients for 48h and required for high-risk actions unless user has `seojusai_approve_changes`.
