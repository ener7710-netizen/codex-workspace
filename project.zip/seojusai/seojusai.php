<?php
/**
 * Plugin Name: SEOJusAI Autopilot
 * Plugin URI:  https://example.com/seojusai
 * Description: AI-автопілот для юридичного SEO. Аналіз, перелінковка та Schema.org для юристів.
 * Version:     2.5.3
 * Author:      SEOJusAI Team
 * License:     GPL-2.0+
 * Text Domain: seojusai
 * Domain Path: /languages
 */

declare(strict_types=1);

namespace SEOJusAI;

defined('ABSPATH') || exit;



// Load translations early enough to avoid WP 6.7+ _load_textdomain_just_in_time notices.
\add_action('plugins_loaded', static function (): void {
	if (\function_exists('load_plugin_textdomain')) {
		\load_plugin_textdomain(
			'seojusai',
			false,
			\dirname(\plugin_basename(__FILE__)) . '/languages'
		);
	}
}, 1);

/* -------------------------------------------------------------------------
 * 1. КОНСТАНТИ
 * ---------------------------------------------------------------------- */

define('SEOJUSAI_VERSION', '2.5.1');
define('SEOJUSAI_FILE', __FILE__);
define('SEOJUSAI_PATH', plugin_dir_path(__FILE__));
define('SEOJUSAI_URL', plugin_dir_url(__FILE__));
define('SEOJUSAI_SRC', SEOJUSAI_PATH . 'src/');
// Backward compat (legacy constant name)
define('SEOJUSAI_INC', SEOJUSAI_SRC);
// Legacy folder path (should be unused)
define('SEOJUSAI_LEGACY_INC', SEOJUSAI_PATH . 'includes/');

/**
 * Завантаження перекладів (після init, щоб уникнути notice у WP 6.7+).
 */
function seojusai_load_textdomain(): void {
	load_plugin_textdomain('seojusai', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', __NAMESPACE__ . '\seojusai_load_textdomain');

/* -------------------------------------------------------------------------
 * 2. PSR-4 AUTOLOADER
 * ---------------------------------------------------------------------- */

spl_autoload_register(function ($class) {

	$prefix   = 'SEOJusAI\\';
	$base_dir = SEOJUSAI_SRC;

	$len = strlen($prefix);
	if (strncmp($prefix, $class, $len) !== 0) {
		return;
	}

	$relative_class = substr($class, $len);
	$file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

	if (file_exists($file)) {
		require_once $file;
	}
});

/* -------------------------------------------------------------------------
 * 3. АКТИВАЦІЯ ПЛАГІНА
 * ---------------------------------------------------------------------- */

register_activation_hook(__FILE__, function () {

	// 0) Capabilities
	if (class_exists('\\SEOJusAI\\Capabilities\\RoleInstaller')) {
		\SEOJusAI\Capabilities\RoleInstaller::install();
	}


	// 1) Інсталятор (БД + планувальник)
	if (class_exists('\\SEOJusAI\\Installer')) {
		\SEOJusAI\Installer::install();
	}

	// 2) Активатор (кредити/прапори/дефолти)
	if (class_exists('\\SEOJusAI\\Core\\Activator')) {
		\SEOJusAI\Core\Activator::activate();
	}
});


/* -------------------------------------------------------------------------
 * 4. BOOTSTRAP
 * ---------------------------------------------------------------------- */

add_filter('cron_schedules', function (array $schedules): array {
	if (!isset($schedules['seojusai_5min'])) {
		$schedules['seojusai_5min'] = [
			'interval' => 300,
			'display'  => \SEOJusAI\Core\I18n::t('SEOJusAI: кожні 5 хвилин'),
		];
	}
	return $schedules;
}, 20);

add_action('admin_init', function () {
	// Ensure caps installed after updates
	if (!get_option('seojusai_caps_installed')) {
		if (class_exists('\\SEOJusAI\\Capabilities\\RoleInstaller')) {
			\SEOJusAI\Capabilities\RoleInstaller::install();
			update_option('seojusai_caps_installed', 1, false);
		}
	}
}, 1);

add_action('plugins_loaded', function () {

	// 🔧 Upgrade: ensure DB schema stays up to date (dbDelta is idempotent)
	$ver = (string) get_option('seojusai_plugin_version', '');
	$current = '2.2.3';
	if ($ver !== $current) {
		if (class_exists('\\SEOJusAI\\Database\\Tables')) {
			(new \SEOJusAI\Database\Tables())->create();
		}
		update_option('seojusai_plugin_version', $current, false);
	}

	// 🔧 Self-heal: create missing critical tables even if version option is already set
	global $wpdb;
	$kbe_like = $wpdb->esc_like($wpdb->prefix . 'seojusai_kbe');
	$kbe_exists = (string) $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $kbe_like));
	if (!$kbe_exists) {
		if (class_exists('\\SEOJusAI\\Database\\Tables')) {
			(new \SEOJusAI\Database\Tables())->create();
		}
	}

	// 🚀 Запуск ядра
	if (class_exists('\\SEOJusAI\\Core\\Plugin')) {
		\SEOJusAI\Core\Plugin::instance();
	}

}, 5);

/**
 * i18n (WP 6.7+ вимагає init або пізніше).
 */
add_action('init', function () {

	if (function_exists('load_plugin_textdomain')) {
		load_plugin_textdomain(
			'seojusai',
			false,
			dirname(plugin_basename(__FILE__)) . '/languages'
		);
	}

}, 5);
