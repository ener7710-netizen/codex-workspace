<?php
declare(strict_types=1);

namespace SEOJusAI\Rest\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use SEOJusAI\Input\Input;
use SEOJusAI\Core\EmergencyStop;
use SEOJusAI\Rest\RestKernel;
use SEOJusAI\Capabilities\CapabilityGuard;
use SEOJusAI\Capabilities\CapabilityMap;
use SEOJusAI\Safety\SafeMode;
use SEOJusAI\Rest\AbstractRestController;
use SEOJusAI\Rest\Contracts\RestControllerInterface;
use SEOJusAI\Schema\SchemaStorage;
use SEOJusAI\Snapshots\SnapshotService;

defined('ABSPATH') || exit;

/**
 * SchemaController
 *
 * POST /seojusai/v1/schema/preview
 * POST /seojusai/v1/schema/apply
 */
final class SchemaController extends AbstractRestController implements RestControllerInterface {

	public function register_routes(): void {

		register_rest_route('seojusai/v1', '/schema/preview', [
			'methods'             => 'POST',
			'permission_callback' => [ RestKernel::class, 'can_execute' ],
			'callback'            => [ $this, 'preview' ],
		]);

		register_rest_route('seojusai/v1', '/schema/apply', [
			'methods'             => 'POST',
			'permission_callback' => [ RestKernel::class, 'can_execute' ],
			'callback'            => [ $this, 'apply' ],
		]);
	}

	public function preview(WP_REST_Request $request): WP_REST_Response {

		if (EmergencyStop::is_active()) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Emergency Stop активний.'], 423);
		}

		$post_id = (int) $request->get_param('post_id');
		$post_id = Input::int($post_id, 1);
		$raw     = $request->get_param('schema');

		if ($post_id <= 0) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Некоректні дані.'], 422);
		}

		if (!current_user_can('edit_post', $post_id)) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Forbidden'], 403);
		}

		if (is_array($raw)) {
			$decoded = $raw;
		} else {
			$parsed = Input::json_array_strict((string) $raw);
			if (!$parsed['ok']) {
				$code = $parsed['error'] === 'payload_too_large' ? 413 : 422;
				return new WP_REST_Response(['ok' => false, 'error' => 'Schema має бути валідним JSON.'], $code);
			}
			$decoded = $parsed['data'];
		}

		$type = isset($decoded['@type']) ? sanitize_text_field((string) $decoded['@type']) : '';
		$ctx  = isset($decoded['@context']) ? (string) $decoded['@context'] : '';

		if ($type === '' || $ctx === '') {
			return new WP_REST_Response(['ok' => false, 'error' => 'JSON-LD має містити @context та @type'], 422);
		}

		return new WP_REST_Response(['ok' => true, 'schema' => $decoded], 200);
	}

	public function apply(WP_REST_Request $request): WP_REST_Response {

		if (class_exists(SafeMode::class) && SafeMode::is_enabled()) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Safe mode enabled.'], 423);
		}

		if (!CapabilityGuard::can(CapabilityMap::MANAGE_SCHEMA)) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Forbidden'], 403);
		}


		if (EmergencyStop::is_active()) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Emergency Stop активний.'], 423);
		}

		$post_id = Input::int((int) $request->get_param('post_id'), 1);
		$raw     = $request->get_param('schema');

		if ($post_id <= 0) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Некоректні дані.'], 422);
		}

		if (!current_user_can('edit_post', $post_id)) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Forbidden'], 403);
		}

		if (is_array($raw)) {
			$decoded = $raw;
		} else {
			$parsed = Input::json_array_strict((string) $raw);
			if (!$parsed['ok']) {
				$code = $parsed['error'] === 'payload_too_large' ? 413 : 422;
				return new WP_REST_Response(['ok' => false, 'error' => 'Schema має бути валідним JSON.'], $code);
			}
			$decoded = $parsed['data'];
		}

		// snapshot before apply
		$snapshot_id = (new SnapshotService())->capture_post($post_id, 'pre_schema_apply');
		if (!$snapshot_id) {
			return new WP_REST_Response(['ok' => false, 'error' => 'Failed to create snapshot'], 500);
		}

		$storage = new SchemaStorage();
		$ok = $storage->save($post_id, $decoded);

		return new WP_REST_Response([
			'ok' => (bool) $ok,
			'snapshot_id' => $snapshot_id,
		], $ok ? 200 : 500);
	}
}
