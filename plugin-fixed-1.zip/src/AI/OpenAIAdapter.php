<?php
namespace SEOJusAI\AI;
final class OpenAIAdapter implements LLMAdapterInterface {
  public function complete(string $prompt): array {
    return ['raw'=>"Категория: Услуга адвоката\nУверенность: 0.80"];
  }
}
