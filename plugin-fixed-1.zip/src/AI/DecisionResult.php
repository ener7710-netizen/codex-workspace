<?php
declare(strict_types=1);

namespace SEOJusAI\AI;

defined('ABSPATH') || exit;

final class DecisionResult {

	public function __construct(
		public readonly string $type,
		public readonly array $decision,
		public readonly int $post_id,
		public readonly bool $auto,
		public readonly string $source,
		public readonly string $hash,
		public readonly int $created_at
	) {}

	public static function fromTask(array $task): self {
		$decision = $task['decision'] ?? [];

		$hash = hash(
			'sha256',
			(string) wp_json_encode($decision, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
		);

		return new self(
			type: sanitize_key((string) ($task['type'] ?? '')),
			decision: $decision,
			post_id: (int) ($task['post_id'] ?? 0),
			auto: ! empty($task['auto']),
			source: (string) ($task['source'] ?? 'ai'),
			hash: $hash,
			created_at: time()
		);
	}
}
