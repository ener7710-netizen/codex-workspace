<?php
declare(strict_types=1);

namespace SEOJusAI\AI;

defined('ABSPATH') || exit;

/**
 * RateLimiter (RPM)
 * Ліміт на виклики до провайдера (OpenAI/Gemini/Proxy).
 */
final class RateLimiter {

	/**
	 * @return bool true якщо дозволено, false якщо ліміт вичерпано
	 */
	public static function allow(string $bucket, int $limit, int $window_seconds = 60): bool {

		$bucket = sanitize_key($bucket);
		if ($bucket === '') return true;

		$key = 'seojusai_rl_' . $bucket;

		$data = get_transient($key);
		$data = is_array($data) ? $data : ['count' => 0, 'start' => time()];

		$start = (int) ($data['start'] ?? time());
		$count = (int) ($data['count'] ?? 0);

		if ((time() - $start) >= $window_seconds) {
			$start = time();
			$count = 0;
		}

		if ($count >= $limit) {
			set_transient($key, ['count' => $count, 'start' => $start], $window_seconds);
			return false;
		}

		$count++;
		set_transient($key, ['count' => $count, 'start' => $start], $window_seconds);

		return true;
	}
}
