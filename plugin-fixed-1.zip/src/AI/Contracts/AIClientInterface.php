<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Contracts;

defined('ABSPATH') || exit;

interface AIClientInterface {

	/**
	 * @param array<string,mixed> $payload
	 * @return array{ok:bool,reply?:string,tasks?:array,error?:string}
	 */
	public function chat(array $payload): array;
}
