<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Integrations;

defined('ABSPATH') || exit;

use SEOJusAI\AI\Providers\GeminiClient;
use SEOJusAI\Snapshots\SnapshotRepository;

/**
 * GeminiSerpOverlayGateway
 *
 * AI-шар: перетворює SERP (конкуренти) у короткий структурований "overlay".
 *
 * Важливо:
 * - Gemini НЕ має вигадувати: працює лише з наданими SERP-рядками.
 * - Gateway не тягне SERP самостійно (це робить SerpOverlayService).
 */
final class GeminiSerpOverlayGateway {

    /**
     * @param array{keyword:string, serp:array{snapshot_id:int, fetched_at:int, results:array<int,array<string,mixed>>}} $payload
     * @return array<string,mixed>|null
     */
    public static function analyze(array $payload): ?array {

        $api_key = (string) apply_filters('seojusai/gemini_key', '');
        $model   = (string) apply_filters('seojusai/gemini_model', 'models/gemini-1.5-pro');
        $client  = new GeminiClient($api_key, $model);

        if (!$client->is_ready()) {
            return null;
        }

        $keyword = (string) ($payload['keyword'] ?? '');
        $serp    = (array) ($payload['serp'] ?? []);
        $results = (array) ($serp['results'] ?? []);
        $snapshot_id = (int) ($serp['snapshot_id'] ?? 0);

        if ($keyword === '' || $snapshot_id <= 0 || empty($results)) {
            return null;
        }

        // Кеш 12 год по snapshot_id (детерміновано).
        $cache_key = 'seojusai_gemini_serp_overlay_' . $snapshot_id;
        $cached = get_transient($cache_key);
        if (is_array($cached) && isset($cached['meta'])) {
            return $cached;
        }

        $prompt = self::build_prompt([
            'keyword' => $keyword,
            'serp_snapshot_id' => $snapshot_id,
            'serp_fetched_at' => (int) ($serp['fetched_at'] ?? 0),
            'serp_results' => array_slice($results, 0, 10),
        ]);

        $raw = $client->generate($prompt, 'serp_overlay');
        if (!is_string($raw) || trim($raw) === '') {
            return null;
        }

        $raw = preg_replace('/^```json|```$/i', '', trim($raw));
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return null;
        }

        // Мінімальна нормалізація.
        $out = [
            'meta' => [
                'confidence' => self::clamp_confidence($data['meta']['confidence'] ?? null),
                'risk'       => isset($data['meta']['risk']) ? (string) $data['meta']['risk'] : 'low',
                'summary'    => isset($data['meta']['summary']) ? (string) $data['meta']['summary'] : '',
            ],
            'competitors' => isset($data['competitors']) && is_array($data['competitors']) ? $data['competitors'] : [],
            'opportunities' => isset($data['opportunities']) && is_array($data['opportunities']) ? $data['opportunities'] : [],
            'evidence' => [
                'keyword' => $keyword,
                'serp_snapshot_id' => $snapshot_id,
            ],
        ];

        // Фіксуємо в снапшоти (для аудиту/відтворюваності).
        $repo = new SnapshotRepository();
        if ($repo->exists()) {
            $repo->insert('gemini_serp', $snapshot_id, [
                'kind' => 'gemini_serp_overlay',
                'keyword' => $keyword,
                'serp_snapshot_id' => $snapshot_id,
                'data' => $out,
            ]);
        }

        set_transient($cache_key, $out, 12 * HOUR_IN_SECONDS);
        return $out;
    }

    /**
     * @param array<string,mixed> $facts
     */
    private static function build_prompt(array $facts): string {

        $contract = <<<JSON
ПОВЕРНИ ВИКЛЮЧНО JSON.

{
  "meta": {
    "confidence": 0.0,
    "risk": "low | medium | high",
    "summary": "коротко: що видно по SERP і чому"
  },
  "competitors": [
    { "position": 1, "domain": "", "angle": "короткий опис підходу конкурента" }
  ],
  "opportunities": [
    { "type": "", "idea": "", "why": "" }
  ]
}
JSON;

        $json = wp_json_encode($facts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return <<<PROMPT
SYSTEM:
Ти Gemini-аналітик SERP. Ти працюєш ЛИШЕ на наданих фактах (SERP results).
Заборонено додавати конкурентів/дані, яких нема у вхідному JSON.
{$contract}

FACTS_JSON:
{$json}

ПОВЕРНИ ЛИШЕ JSON.
PROMPT;
    }

    private static function clamp_confidence($value): float {
        $conf = 0.3;
        if (is_numeric($value)) {
            $conf = (float) $value;
        }
        if ($conf < 0.0) { $conf = 0.0; }
        if ($conf > 1.0) { $conf = 1.0; }
        return $conf;
    }
}
