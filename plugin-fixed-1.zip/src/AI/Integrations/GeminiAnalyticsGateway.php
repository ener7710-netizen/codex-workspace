<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Integrations;

defined('ABSPATH') || exit;

use SEOJusAI\Analytics\ObjectiveDatasetService;
use SEOJusAI\AI\Providers\GeminiClient;
use SEOJusAI\Snapshots\SnapshotRepository;

/**
 * GeminiAnalyticsGateway
 *
 * Канон 2026: Gemini має отримувати максимально об'єктивні факти.
 *
 * Цей шлюз:
 * - бере ТІЛЬКИ снапшоти (GA4/GSC)
 * - будує компактний датасет
 * - відправляє його в Gemini у строгому JSON контракті
 * - кешує результат (по snapshot id)
 * - зберігає результат як снапшот type='gemini_analytics'
 */
final class GeminiAnalyticsGateway {

    private const TRANSIENT_PREFIX = 'seojusai_gemini_analytics_';

    /**
     * @return array<string,mixed>|null
     */
    public static function get_or_compute(int $topPages = 30, bool $force = false): ?array {

        $dataset = (new ObjectiveDatasetService())->build($topPages);

        $ga4Id = (int) ($dataset['snapshots']['ga4']['id'] ?? 0);
        $gscId = (int) ($dataset['snapshots']['gsc']['id'] ?? 0);

        $cacheKey = self::TRANSIENT_PREFIX . $ga4Id . '_' . $gscId;
        if (!$force) {
            $cached = get_transient($cacheKey);
            if (is_array($cached) && !empty($cached['meta'])) {
                return $cached;
            }
        }

        $api_key = (string) apply_filters('seojusai/gemini_key', '');
        $model   = (string) apply_filters('seojusai/gemini_model', 'models/gemini-1.5-pro');
        $client  = new GeminiClient($api_key, $model);

        if (!$client->is_ready()) {
            return null;
        }

        // Пакуємо датасет, щоб він не був завеликим.
        $payload = [
            'type' => 'analytics_dataset',
            'generated_at' => $dataset['generated_at'] ?? gmdate('c'),
            'snapshots' => $dataset['snapshots'] ?? null,
            'overview'  => $dataset['overview'] ?? null,
            'merged_pages' => $dataset['merged_pages'] ?? null,
        ];

        $prompt = self::build_prompt($payload);

        $raw = $client->generate($prompt, 'analyst');
        if (!is_string($raw) || trim($raw) === '') {
            return null;
        }

        $raw = preg_replace('/^```json|```$/i', '', trim($raw));
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return null;
        }

        $result = [
            'meta' => [
                'confidence' => self::clamp_confidence($data['meta']['confidence'] ?? null),
                'risk'       => isset($data['meta']['risk']) ? (string) $data['meta']['risk'] : 'low',
                'summary'    => isset($data['meta']['summary']) ? (string) $data['meta']['summary'] : '',
                'reasoning'  => isset($data['meta']['reasoning']) ? (string) $data['meta']['reasoning'] : '',
            ],
            'actions' => isset($data['actions']) && is_array($data['actions']) ? $data['actions'] : [],
            'evidence' => isset($data['evidence']) && is_array($data['evidence']) ? $data['evidence'] : [],
            '_snapshots' => [ 'ga4' => $ga4Id, 'gsc' => $gscId ],
            '_generated_at' => gmdate('c'),
        ];

        // Cache for 6 hours.
        set_transient($cacheKey, $result, 6 * HOUR_IN_SECONDS);

        // Persist as a snapshot so OpenAI/Autopilot can reference stable evidence.
        try {
            $repo = new SnapshotRepository();
            $repo->insert('gemini_analytics', (int) crc32((string) home_url('/')), [
                'snapshots' => [ 'ga4' => $ga4Id, 'gsc' => $gscId ],
                'result' => $result,
            ]);
        } catch (\Throwable $e) {
            // best-effort
        }

        return $result;
    }

    /**
     * @param array<string,mixed> $payload
     */
    private static function build_prompt(array $payload): string {

        $contract = <<<JSON
ПОВЕРНИ ВИКЛЮЧНО JSON. БЕЗ markdown.

{
  "meta": {
    "confidence": 0.0,
    "risk": "low | medium | high",
    "summary": "коротке резюме стану трафіку/SEO",
    "reasoning": "2-4 речення: чому та на яких фактах"
  },
  "evidence": [
    {"metric":"", "value":"", "why":""}
  ],
  "actions": [
    {"action":"", "auto": false}
  ]
}
JSON;

        $json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return <<<PROMPT
SYSTEM:
Ти Gemini-аналітик SEO. Ти працюєш ЛИШЕ на фактах (GA4+GSC зі снапшотів).
Не вигадуй дані. Якщо факту немає у payload — напиши, що даних недостатньо.
{$contract}

PAYLOAD:
{$json}

ПОВЕРНИ ЛИШЕ JSON.
PROMPT;
    }

    private static function clamp_confidence($value): float {
        $conf = 0.3;
        if (is_numeric($value)) {
            $conf = (float) $value;
        }
        if ($conf < 0.0) $conf = 0.0;
        if ($conf > 1.0) $conf = 1.0;
        return $conf;
    }
}
