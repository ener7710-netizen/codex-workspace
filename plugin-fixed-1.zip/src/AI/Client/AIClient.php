<?php
declare(strict_types=1);

namespace SEOJusAI\AI\Client;

use SEOJusAI\AI\Billing\CreditManager;
use SEOJusAI\AI\Billing\UsageTracker;
use SEOJusAI\AI\Proxy\ProxyResolver;
use SEOJusAI\AI\Security\RateLimiter;
use SEOJusAI\AI\Providers\GeminiClient;
use SEOJusAI\AI\Providers\OpenAIClient;

defined('ABSPATH') || exit;

/**
 * AIClient
 *
 * Центральний вузол для виконання запитів до AI.
 * Об'єднує контроль лімітів, білінг, проксі та провайдерів.
 */
final class AIClient {

	/**
	 * Основний метод чату.
	 *
	 * @param array<string,mixed> $payload Дані запиту
	 * @param string $scope Контекст запиту (напр. 'chat:123')
	 * @return array{ok:bool,reply?:string,error?:string,tasks?:array}
	 */
	public static function chat(array $payload, string $scope = 'default'): array {

		$user_id = (int) get_current_user_id();

		// 1) Rate limit (захист від спаму)
		$limiter = new RateLimiter(100, 3600);
		if (!$limiter->allow($scope)) {
			return [
				'ok'    => false,
				'error' => 'AI rate limit exceeded',
			];
		}

		// 2) Billing check
		if (!CreditManager::has_credits(1, $user_id)) {
			return [
				'ok'    => false,
				'error' => 'AI credits exhausted',
			];
		}

		// 3) Execute request (proxy або прямий провайдер)
		$result = self::execute_request($payload, $scope);

		// 4) Billing consumption (лише при успіху)
		if (!empty($result['ok'])) {
			CreditManager::consume(1, $user_id);
			UsageTracker::log([
				'user_id' => $user_id,
				'scope'   => $scope,
				'ok'      => true,
			]);
		}

		return $result;
	}

	/**
	 * Вибір транспорту (Proxy або локальний провайдер).
	 *
	 * @param array<string,mixed> $payload
	 * @return array{ok:bool,reply?:string,error?:string,raw?:array<string,mixed>}
	 */
	private static function execute_request(array $payload, string $scope): array {

		// A) Через проксі (якщо увімкнено)
		if (ProxyResolver::is_proxy_enabled()) {
			$response = wp_remote_post(
				ProxyResolver::endpoint() . '/chat',
				[
					'timeout' => 45,
					'headers' => array_merge(
						['Content-Type' => 'application/json'],
						ProxyResolver::headers()
					),
					'body' => wp_json_encode($payload),
				]
			);

			if (is_wp_error($response)) {
				return ['ok' => false, 'error' => 'Proxy communication error: ' . $response->get_error_message()];
			}

			$data = json_decode((string) wp_remote_retrieve_body($response), true);
			return is_array($data) ? $data : ['ok' => false, 'error' => 'Invalid proxy response'];
		}

		// B) Прямий локальний виклик
		$requested_provider = isset($payload['provider']) && is_string($payload['provider']) ? $payload['provider'] : 'openai';

		if ($requested_provider === 'gemini') {
			if (!class_exists(GeminiClient::class)) {
				return ['ok' => false, 'error' => 'Gemini provider is not available'];
			}

			$gemini_key = (string) apply_filters('seojusai/gemini_key', (string) get_option('seojusai_gemini_key', ''));
			$gemini_model = (string) apply_filters('seojusai/gemini_model', (string) get_option('seojusai_gemini_model', 'models/gemini-1.5-pro'));
			$client = new GeminiClient($gemini_key, $gemini_model);

			return $client->analyze($payload, $scope);
		}

		// OpenAI (default)
		if (!class_exists(OpenAIClient::class)) {
			return ['ok' => false, 'error' => 'OpenAI provider is not available'];
		}

		$openai_key = (string) apply_filters('seojusai/openai_key', (string) get_option('seojusai_openai_key', ''));
		$openai_model = (string) apply_filters('seojusai/openai_model', (string) get_option('seojusai_openai_model', 'gpt-4.1'));
		$client = new OpenAIClient($openai_key, $openai_model);

		return $client->chat($payload);
	}
}
