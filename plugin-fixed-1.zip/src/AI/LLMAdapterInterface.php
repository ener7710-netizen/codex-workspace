<?php
namespace SEOJusAI\AI;
interface LLMAdapterInterface { public function complete(string $prompt): array; }
