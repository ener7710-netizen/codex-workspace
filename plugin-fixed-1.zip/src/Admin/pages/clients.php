
<div class="wrap">
<h1>SEOJusAI Clients</h1>
<p>Manage SaaS API clients and limits.</p>
<p><em>Initial version: add rows directly in DB or via phpMyAdmin.</em></p>
</div>
