<?php
declare(strict_types=1);

namespace SEOJusAI\Modules;

use SEOJusAI\Core\Kernel;
use SEOJusAI\Rest\Controllers\BulkController;

defined('ABSPATH') || exit;

final class BulkModule {

    public function register(Kernel $kernel): void {
        // REST
        add_action('rest_api_init', function (): void {
            if (class_exists(BulkController::class)) {
                (new BulkController())->register_routes();
            }
        });
    }
}
