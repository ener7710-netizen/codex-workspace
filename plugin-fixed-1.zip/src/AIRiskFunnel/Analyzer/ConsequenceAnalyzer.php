<?php
declare(strict_types=1);

namespace SEOJusAI\AIRiskFunnel\Analyzer;

defined('ABSPATH') || exit;

final class ConsequenceAnalyzer {

    /** @return array{score:float,terms:array<int,string>} */
    public function analyze(string $text): array {

        $t = mb_strtolower($text);

        $terms = [
            'що буде', 'наслідк', 'ризик', 'типові помилки', 'помилк',
            'може призвести', 'погіршує', 'не робіть', 'важливо', 'увага',
            'якщо нічого не робити', 'можна втратити', 'порада', 'практика',
        ];

        $found = $this->hits($t, $terms);

        // optimal: не "лякати", а пояснити наслідки
        $score = min(1.0, count($found) / 6.0);

        // penalty якщо суцільна реклама
        if (mb_strpos($t, 'зателефонуйте') !== false || mb_strpos($t, 'замовте') !== false) {
            $score = max(0.0, $score - 0.25);
        }

        return [
            'score' => $score,
            'terms' => $found,
        ];
    }

    /** @param array<int,string> $terms @return array<int,string> */
    private function hits(string $text, array $terms): array {
        $found = [];
        foreach ($terms as $term) {
            if ($term === '') continue;
            if (mb_strpos($text, $term) !== false) {
                $found[] = $term;
            }
        }
        return array_values(array_unique($found));
    }
}
