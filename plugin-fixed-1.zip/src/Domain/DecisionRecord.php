<?php
declare(strict_types=1);

namespace SEOJusAI\Domain;

defined('ABSPATH')||exit;

final class DecisionRecord {
    public string $decisionHash;
    public int $postId;
    public float $score;
    public string $summary;
    public string $status;

    public function __construct(string $decisionHash,int $postId,float $score,string $summary,string $status='planned') {
        $this->decisionHash=$decisionHash;
        $this->postId=$postId;
        $this->score=$score;
        $this->summary=$summary;
        $this->status=$status;
    }
}
