<?php
declare(strict_types=1);

namespace SEOJusAI\Decisions;

use SEOJusAI\Executors\ApplyService;

defined('ABSPATH') || exit;

final class DecisionOutcomeManager {

    public static function register(): void {
        add_action('init', [DecisionTables::class, 'ensure'], 9);

        // ApplyService hooks
        add_action('seojusai/apply/before', [self::class, 'on_apply_before'], 10, 1);
        add_action('seojusai/apply/after', [self::class, 'on_apply_after'], 10, 1);
        add_action('seojusai/apply/error', [self::class, 'on_apply_error'], 10, 1);

        // Executor hooks
        add_action('seojusai/executor/success', [self::class, 'on_executor_success'], 10, 1);
        add_action('seojusai/executor/error', [self::class, 'on_executor_error'], 10, 1);
        add_action('seojusai/executor/unsupported', [self::class, 'on_executor_unsupported'], 10, 1);
    }

    /** @param array<string,mixed> $ctx */
    public static function on_apply_before(array $ctx): void {
        // no-op (reserved for timing in future)
    }

    /** @param array<string,mixed> $ctx */
    public static function on_apply_after(array $ctx): void {
        $decision_id = (int)($ctx['decision_record_id'] ?? 0);
        if ($decision_id <= 0) return;

        $out = new OutcomeRepository();
        $out->upsert($decision_id, [
            'status' => 'applied',
            'snapshot_id' => (int)($ctx['snapshot_id'] ?? 0),
            'created_at' => time(),
        ]);
        do_action('seojusai/decision/applied', ['decision_id' => $decision_id] + $ctx);
    }

    /** @param array<string,mixed> $payload */
    public static function on_apply_error(array $payload): void {
        // payload may contain ctx or not
        $decision_id = (int)($payload['decision_record_id'] ?? 0);
        if ($decision_id <= 0) return;

        $out = new OutcomeRepository();
        $out->upsert($decision_id, [
            'status' => 'failed',
            'snapshot_id' => (int)($payload['snapshot_id'] ?? 0),
            'created_at' => time(),
            'meta' => [
                'type' => (string)($payload['type'] ?? ''),
                'error' => (string)($payload['error'] ?? ''),
            ],
        ]);
        do_action('seojusai/decision/failed', ['decision_id' => $decision_id] + $payload);
    }

    /** @param array<string,mixed> $payload */
    public static function on_executor_success(array $payload): void {
        $decision_id = (int)($payload['decision_record_id'] ?? 0);
        if ($decision_id <= 0) return;

        (new OutcomeRepository())->upsert($decision_id, [
            'status' => 'applied',
            'snapshot_id' => (int)($payload['snapshot_id'] ?? 0),
            'created_at' => time(),
        ]);
        do_action('seojusai/decision/applied', ['decision_id' => $decision_id] + $payload);
    }

    /** @param array<string,mixed> $payload */
    public static function on_executor_error(array $payload): void {
        $decision_id = (int)($payload['decision_record_id'] ?? 0);
        if ($decision_id <= 0) return;

        (new OutcomeRepository())->upsert($decision_id, [
            'status' => 'failed',
            'snapshot_id' => (int)($payload['snapshot_id'] ?? 0),
            'created_at' => time(),
            'meta' => [
                'error' => (string)($payload['error'] ?? ''),
            ],
        ]);
        do_action('seojusai/decision/failed', ['decision_id' => $decision_id] + $payload);
    }

    /** @param array<string,mixed> $task */
    public static function on_executor_unsupported(array $task): void {
        $decision_id = (int)($task['decision_record_id'] ?? 0);
        if ($decision_id <= 0) return;

        (new OutcomeRepository())->upsert($decision_id, [
            'status' => 'rejected',
            'snapshot_id' => (int)($task['snapshot_id'] ?? 0),
            'created_at' => time(),
            'meta' => [
                'reason' => 'unsupported_executor',
                'action' => (string)($task['action'] ?? ''),
            ],
        ]);
        do_action('seojusai/decision/rejected', ['decision_id' => $decision_id] + $task);
    }
}
