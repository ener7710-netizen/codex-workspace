<?php
declare(strict_types=1);

namespace SEOJusAI;

defined('ABSPATH') || exit;
use SEOJusAI\API\SeoApiController;

use SEOJusAI\Schema\SchemaRenderer;
use SEOJusAI\Input\Input;
use SEOJusAI\Utils\Logger;

final class Bootstrap {

	public static function init(): void {

		// AI module enabled?
		$is_ai_enabled = true;
		if (class_exists('\SEOJusAI\Core\ModuleRegistry')) {
			$is_ai_enabled = \SEOJusAI\Core\ModuleRegistry::instance()->is_enabled('ai');
		}

		// ✅ Schema renderer можно оставить (это не REST)
		if ($is_ai_enabled && class_exists(SchemaRenderer::class)) {
			(new SchemaRenderer())->register();
		}

		// ✅ Toggle modules ajax можно оставить
		add_action('wp_ajax_seojusai_toggle_module', [self::class, 'handle_module_toggle']);

		// ✅ cron audit можно оставить (если используешь PageAuditRunner)
		if ($is_ai_enabled) {
			add_action('save_post', [self::class, 'queue_page_audit'], 20, 3);
			add_action('seojusai/run_page_audit', [self::class, 'run_page_audit_event'], 10, 1);
		}

		// ✅ admin assets можно оставить
		if (is_admin()) {
			add_action('admin_enqueue_scripts', [self::class, 'enqueue_admin_assets']);
		}

		/**
		 * ❌ ВАЖНО:
		 * НИКОГДА НЕ ДЕЛАЕМ REST тут:
		 * - никаких rest_api_init/register_rest_routes
		 * - никаких RestHandler
		 *
		 * REST = только RestKernel внутри Core\Plugin
		 */
	}

	public static function handle_module_toggle(): void {
		check_ajax_referer('seojusai_toggle_module');
		if (!current_user_can('manage_options')) wp_send_json_error('Forbidden', 403);

		$slug    = sanitize_text_field(Input::post('module') ?? '');
		$enabled = (bool) (Input::post('enabled') ?? 0);

		if (class_exists('\SEOJusAI\Core\ModuleRegistry')) {
			\SEOJusAI\Core\ModuleRegistry::instance()->set_enabled($slug, $enabled);
			wp_send_json_success();
		}
		wp_send_json_error('ModuleRegistry not found');
	}

	public static function queue_page_audit(int $post_id, $post, bool $update): void {

		$post_id = (int) $post_id;

		if ($post_id <= 0) {
			return;
		}

		if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
			return;
		}

		if (!\SEOJusAI\seojusai_should_process_post($post_id)) {
			return;
		}

		if (!($post instanceof \WP_Post)) {
			return;
		}

		if (in_array($post->post_status, ['trash', 'auto-draft'], true)) {
			return;
		}

		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		if (class_exists('\SEOJusAI\Tasks\TaskQueue')) {
			$queue = new \SEOJusAI\Tasks\TaskQueue();

			$payload = [
				'post_id' => $post_id,
				'reason'  => 'save_post',
			];

			$modified = (int) get_post_modified_time('U', true, $post_id);
			$key      = sprintf('page_audit_%d_%d', $post_id, $modified > 0 ? $modified : time());

			$queue->enqueue('page_audit', $payload, $key);
			return;
		}

		if (!class_exists('\SEOJusAI\Analyze\PageAuditRunner')) {
			return;
		}

		$hook = 'seojusai/run_page_audit';
		$args = [$post_id];

		if (wp_next_scheduled($hook, $args)) {
			return;
		}

		wp_schedule_single_event(time() + 10, $hook, $args);
	}

	public static function run_page_audit_event(int $post_id): void {

		$post_id = (int)$post_id;
		if ($post_id <= 0) return;

		if (!class_exists('\SEOJusAI\Analyze\PageAuditRunner')) return;

		try {
			\SEOJusAI\Analyze\PageAuditRunner::run($post_id);
		} catch (\Throwable $e) {
			if (defined('WP_DEBUG') && WP_DEBUG) {
				if (class_exists(Logger::class)) {
			Logger::error('bootstrap_error', ['message' => '[SEOJusAI] Audit runner failed: ' . $e->getMessage()]);
		}
			}
		}
	}

	public static function enqueue_admin_assets(string $hook): void {
		if (str_contains($hook, 'seojusai')) {
			wp_enqueue_style('seojusai-admin-css', SEOJUSAI_URL . 'assets/css/admin.css', [], SEOJUSAI_VERSION);
			wp_enqueue_script('seojusai-admin-js', SEOJUSAI_URL . 'assets/js/admin.js', ['jquery'], SEOJUSAI_VERSION, true);

			wp_localize_script('seojusai-admin-js', 'SEOJusAIAdmin', [
				'ajaxurl' => admin_url('admin-ajax.php'),
				'nonce'   => wp_create_nonce('seojusai_toggle_module'),
				'restRoot' => esc_url_raw(rest_url()),
				'restNonce'=> wp_create_nonce('wp_rest')
			]);
		}
	}
}
